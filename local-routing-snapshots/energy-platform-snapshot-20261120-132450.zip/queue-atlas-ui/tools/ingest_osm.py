"""Convert a region-clipped Overpass JSON extract to a map overlay.

The input must already be clipped to the stated grid region and its coverage
must be described accurately. This tool does not infer electrical boundaries.
It never downloads from a public Overpass service.
"""
import argparse
import json
from pathlib import Path


def convert(source, region, coverage):
    if region not in {'MISO', 'NYISO'} or not coverage.strip():
        raise ValueError('A region and an explicit coverage description are required')
    timestamp = source.get('osm3s', {}).get('timestamp_osm_base')
    if not isinstance(timestamp, str) or not timestamp:
        raise ValueError('The extract must include the OSM base timestamp')
    output = []
    for item in source.get('elements', []):
        kind = item.get('tags', {}).get('power')
        if kind not in {'line', 'minor_line', 'substation'}:
            continue
        if item.get('type') == 'node' and kind == 'substation':
            coords = [[item.get('lon'), item.get('lat')]]
        elif item.get('type') == 'way':
            coords = [[p.get('lon'), p.get('lat')] for p in item.get('geometry', [])]
        else:
            # Relations can contain multiple outer and inner rings; leaving
            # them out is safer than drawing an incorrect connection.
            continue
        if not coords or any(not isinstance(x, (int, float)) or not isinstance(y, (int, float)) or not (-180 <= x <= 180 and -85 <= y <= 85) for x, y in coords):
            continue
        if kind != 'substation' and len(coords) < 2:
            continue
        output.append({'id': f"{item['type']}/{item['id']}", 'kind':kind, 'coordinates':coords})
    return {'region':region, 'source':'OpenStreetMap contributors', 'license':'https://www.openstreetmap.org/copyright', 'as_of':timestamp, 'coverage':coverage, 'features':output}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--region', choices=['MISO','NYISO'], required=True)
    parser.add_argument('--coverage', required=True, help='Accurate geographic coverage and known gaps')
    args = parser.parse_args()
    data = convert(json.loads(args.input.read_text(encoding='utf-8')), args.region, args.coverage)
    args.output.write_text(json.dumps(data, separators=(',', ':')), encoding='utf-8')
    print(f"{len(data['features'])} features; snapshot {data['as_of']}")


if __name__ == '__main__':
    main()
