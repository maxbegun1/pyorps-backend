import unittest
from ingest_osm import convert


class IngestTests(unittest.TestCase):
    def test_only_supported_features_with_valid_geometry(self):
        src = {'osm3s':{'timestamp_osm_base':'2025-01-01T00:00:00Z'}, 'elements':[
            {'type':'node','id':1,'lon':-74,'lat':42,'tags':{'power':'substation'}},
            {'type':'way','id':2,'geometry':[{'lon':-74,'lat':42},{'lon':-73,'lat':42}], 'tags':{'power':'line'}},
            {'type':'relation','id':3,'tags':{'power':'substation'}},
            {'type':'way','id':4,'geometry':[{'lon':400,'lat':0}], 'tags':{'power':'line'}},
        ]}
        result = convert(src,'NYISO','Selected area only')
        self.assertEqual([f['id'] for f in result['features']], ['node/1','way/2'])
        self.assertEqual(result['coverage'], 'Selected area only')

    def test_snapshot_and_coverage_are_required(self):
        with self.assertRaises(ValueError): convert({},'MISO','Some coverage')
        with self.assertRaises(ValueError): convert({'osm3s':{'timestamp_osm_base':'x'}},'MISO','')
        with self.assertRaises(ValueError): convert({'osm3s':{'timestamp_osm_base':'x'}},'CAISO','Some coverage')


if __name__ == '__main__': unittest.main()
