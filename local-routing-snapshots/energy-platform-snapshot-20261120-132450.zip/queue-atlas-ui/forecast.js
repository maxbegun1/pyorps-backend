(function (root) {
  'use strict';
  // Values are existing model outputs, not new or backdated model runs.
  function archivedForecast(project) {
    const forecast = project && project.forecast;
    if (!forecast || !forecast.horizons || typeof forecast.as_of !== 'string') return null;
    const results = [4, 12, 20].map(quarters => {
      const row = forecast.horizons[String(quarters)];
      if (!row) return { years: quarters / 4, available: false };
      const keys = ['agreement_or_operation', 'withdrawal', 'unresolved'];
      if (!keys.every(key => Number.isFinite(row[key]) && row[key] >= 0 && row[key] <= 1) ||
          Math.abs(keys.reduce((sum, key) => sum + row[key], 0) - 1) > 0.002) {
        return { years: quarters / 4, available: false };
      }
      return { years: quarters / 4, available: true, agreement: row.agreement_or_operation,
        withdrawal: row.withdrawal, unresolved: row.unresolved };
    });
    return { asOf: forecast.as_of, results };
  }
  const api = { archivedForecast };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.QueueForecast = api;
})(typeof globalThis === 'undefined' ? this : globalThis);
