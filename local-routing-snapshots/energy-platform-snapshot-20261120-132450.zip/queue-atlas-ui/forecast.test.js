const { test } = require('node:test');
const assert = require('node:assert/strict');
const { archivedForecast } = require('./forecast.js');
test('reports stored one, three, and five year outcomes without fabricating missing horizons', () => {
  const row = { agreement_or_operation: .1, withdrawal: .3, unresolved: .6 };
  const output = archivedForecast({ forecast: { as_of: '2025Q4', horizons: { 4: row, 20: row } } });
  assert.deepEqual(output.results.map(x => [x.years, x.available]), [[1, true], [3, false], [5, true]]);
  assert.equal(output.results[0].agreement, .1);
});
test('rejects invalid probabilities and absent forecasts', () => {
  assert.equal(archivedForecast({}), null);
  const result = archivedForecast({ forecast: { as_of: '2025Q4', horizons: { 4: { agreement_or_operation: .7, withdrawal: .7, unresolved: 0 } } } });
  assert.equal(result.results[0].available, false);
});
