#!/usr/bin/env python3
"""NYISO queue-time estimator, v2: better-ranked withdrawal and IA timing.

Builds on ``nyiso_competing_risks.py`` (same panel, features, CIF forecasting and
active-project scoring) and changes three things:

1. Censored training.  The v1 project-pure split drops every project still active
   at the training cutoff, so the recent cohorts left in training are only the
   fast exits.  That inflates withdrawal hazards for new entries (v1 predicted a
   33.6% mean quarterly withdrawal rate vs 17.6% observed).  v2 trains on every
   project-quarter up to the cutoff and treats still-active projects as
   right-censored there.  Test rows are unchanged: the same project-pure
   2023-2025 rows as v1.
2. Cause-specific hazards.  IA comes from a more regularized calibrated
   LightGBM.  Withdrawal comes from a 50/50 blend of that LightGBM and the
   age-only hazard, which ranks short-horizon withdrawal better under the
   2024-2025 regime shift.
3. Corrected horizon AUC.  v1's landmark AUC drops projects still queued at the
   end of the window (an off-by-one against the panel cutoff), so its 12-quarter
   withdrawal AUC is mostly "withdrew vs reached IA".  v2 reports both
   definitions; the corrected one counts projects known to be queued at the
   horizon as controls.

Choices were selected on an inner out-of-time validation (train <= 2019Q4,
validate 2020-2022) before looking at the 2023-2025 test.

Run:
    python nyiso_queue_time_v2.py --input data/NYISO_panel_model_ready.csv --output results_v2
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("MPLBACKEND", "Agg")

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

import nyiso_competing_risks as v1
from queue_time_models import AgeOnlyHazard, BlendedHazard, CauseSpecificHazard

SEED = v1.SEED
VALID_CUTOFF = pd.Timestamp("2019-10-01")
TEST_CUTOFF = pd.Timestamp("2022-10-01")
QUARTER = pd.offsets.QuarterBegin(startingMonth=1)
HORIZONS = [4, 8, 12]
AGE_MARKERS = [4, 8, 12]
# v1 selected hyperparameters (results/selected_hyperparameters.json).
V1_LGBM = {"n_estimators": 180, "learning_rate": 0.03, "num_leaves": 11, "max_depth": 4,
           "min_child_samples": 120}
V1_LOGIT_C = 0.1
# Shallower, slower-learning trees with larger leaves; chosen on the inner validation.
V2_LGBM = {"n_estimators": 300, "learning_rate": 0.02, "num_leaves": 7, "max_depth": 3,
           "min_child_samples": 200}
WITHDRAW_BLEND_WEIGHT = 0.5  # weight on the age-only hazard
N_BOOTSTRAP = 300


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", default=Path("results_v2"), type=Path)
    return parser.parse_args()


def tree_preprocessor() -> ColumnTransformer:
    """Like v1's preprocessor, but trees get raw age (no spline, no linear extrapolation)."""
    return ColumnTransformer(
        transformers=[
            ("num", Pipeline([
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
            ]), ["age_quarters"] + v1.BASE_NUMERIC),
            ("cat", Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore", drop="first",
                                         sparse_output=False)),
            ]), v1.BASE_CATEGORICAL),
        ],
        remainder="drop",
        verbose_feature_names_out=True,
    )


def fit_lgbm(train: pd.DataFrame, params: dict[str, Any]) -> v1.FittedModel:
    weights = v1.class_weights_sqrt(train["y"])
    pre = tree_preprocessor()
    model = v1.lgbm_from_params(params, weights)
    model.fit(pre.fit_transform(train), train["y"])

    oof = np.zeros((len(train), 3))
    for tr, va in GroupKFold(n_splits=3).split(train, train["y"], train["project_id"]):
        fold_pre = tree_preprocessor()
        fold_model = v1.lgbm_from_params(params, weights)
        fold_model.fit(fold_pre.fit_transform(train.iloc[tr]), train.iloc[tr]["y"])
        oof[va] = np.clip(fold_model.predict_proba(fold_pre.transform(train.iloc[va])), 1e-9, 1.0)
    calibrator = LogisticRegression(C=1.0, max_iter=2000, solver="lbfgs", random_state=SEED)
    calibrator.fit(np.log(oof), train["y"])
    return v1.FittedModel(pre, model, calibrator, "LightGBM calibrated (regularized)")


def fit_queue_time_model(train: pd.DataFrame) -> dict[str, Any]:
    age = AgeOnlyHazard.fit(train)
    lgbm = fit_lgbm(train, V2_LGBM)
    withdraw = BlendedHazard(age, lgbm, WITHDRAW_BLEND_WEIGHT, "Age-only/LightGBM blend")
    final = CauseSpecificHazard(lgbm, withdraw, "Queue-time v2 (cause-specific)")
    return {"age": age, "lgbm": lgbm, "final": final}


def censored_split(frame: pd.DataFrame, cutoff: pd.Timestamp) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Train on every row up to the cutoff; test on the v1 project-pure post-cutoff rows."""
    test_projects = set(frame.loc[frame["quarter_start"] > cutoff, "project_id"])
    pure_train = frame[(frame["quarter_start"] <= cutoff) & ~frame["project_id"].isin(test_projects)]
    censored_train = frame[frame["quarter_start"] <= cutoff]
    test = frame[(frame["quarter_start"] > cutoff) & frame["project_id"].isin(test_projects)]
    return pure_train.copy(), censored_train.copy(), test.copy()


def followed_until(test: pd.DataFrame, active: pd.DataFrame | None) -> pd.Series:
    """Date through which an event-free project is known to still be queued."""
    last = test.sort_values("quarter_start").groupby("project_id").tail(1).set_index("project_id")
    known = (last["quarter_start"] + QUARTER).where(last["y"] == 0)
    if active is not None:  # final censored row: still queued at the panel cutoff
        at_cutoff = active.groupby("project_id")["quarter_start"].max() + QUARTER
        known = at_cutoff.combine_first(known)
    return known


def landmark_predictions(test: pd.DataFrame, model: Any, known_until: pd.Series,
                         horizon: int) -> dict[str, dict[str, np.ndarray]]:
    """Horizon CIFs from each project's first test quarter, under both AUC definitions."""
    landmark = test.sort_values(["project_id", "quarter_start"]).groupby("project_id").head(1)
    terminal = test[test["y"].isin([1, 2])].drop_duplicates("project_id").set_index("project_id")
    event = landmark["project_id"].map(terminal["y"])
    event_date = landmark["project_id"].map(terminal["quarter_start"])
    horizon_end = landmark["quarter_start"] + QUARTER * horizon
    masks = {
        "v1": ((horizon_end <= test["quarter_start"].max())
               | (event_date.notna() & (event_date < horizon_end))).to_numpy(),
        "corrected": (event_date.notna()
                      | (landmark["project_id"].map(known_until) >= horizon_end)).to_numpy(),
    }
    p_wd, p_ia, _ = v1.forecast_cif(model, landmark, horizon)
    out: dict[str, dict[str, np.ndarray]] = {}
    for code, label, pred in [(1, "withdraw", p_wd), (2, "IA/operational", p_ia)]:
        y = ((event == code) & (event_date < horizon_end)).astype(int).to_numpy()
        for definition, mask in masks.items():
            out[f"{definition}|{label}"] = {"y": y[mask], "p": pred[mask]}
    return out


def safe_auc(y: np.ndarray, p: np.ndarray) -> float:
    return float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else np.nan


def age_marker_metrics(split: str, sample: str, name: str, model: Any,
                       frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Row-level one-vs-rest AUC and log loss for projects at each queue-age marker."""
    rows = []
    for age in AGE_MARKERS:
        at_age = frame[frame["age_quarters"] == age]
        pa = np.clip(model.predict_proba(at_age), 1e-9, 1.0)
        for code, label in [(1, "withdraw"), (2, "IA/operational")]:
            y = (at_age["y"] == code).to_numpy(int)
            base = {"split": split, "sample": sample, "model": name, "event": label,
                    "age_quarters": age, "rows": len(y), "events": int(y.sum())}
            rows.append({**base, "metric": "queue_age_marker_auc", "value": safe_auc(y, pa[:, code])})
            rows.append({**base, "metric": "queue_age_marker_logloss",
                         "value": float(log_loss(y, pa[:, code], labels=[0, 1]))})
    return rows


def evaluate(split: str, test: pd.DataFrame, models: dict[str, Any],
             known_until: pd.Series, rng: np.random.Generator) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows, deltas = [], []
    preds = {name: {h: landmark_predictions(test, model, known_until, h) for h in HORIZONS}
             for name, model in models.items()}
    for name, model in models.items():
        p = model.predict_proba(test)
        rows.append({"split": split, "model": name, "metric": "multiclass_log_loss",
                     "value": log_loss(test["y"], p, labels=[0, 1, 2])})
        rows.append({"split": split, "model": name, "metric": "multiclass_brier",
                     "value": v1.brier_multiclass(test["y"].to_numpy(int), p)})
        rows.append({"split": split, "model": name, "metric": "mean_pred_withdraw", "value": p[:, 1].mean()})
        rows.append({"split": split, "model": name, "metric": "observed_withdraw",
                     "value": (test["y"] == 1).mean()})
        rows.append({"split": split, "model": name, "metric": "mean_pred_ia", "value": p[:, 2].mean()})
        rows.append({"split": split, "model": name, "metric": "observed_ia", "value": (test["y"] == 2).mean()})
        rows.extend(age_marker_metrics(split, "test", name, model, test))
        for h in HORIZONS:
            for key, d in preds[name][h].items():
                definition, label = key.split("|")
                rows.append({"split": split, "model": name, "event": label, "horizon_quarters": h,
                             "metric": f"horizon_auc_{definition}", "value": safe_auc(d["y"], d["p"]),
                             "evaluable_projects": len(d["y"]), "events": int(d["y"].sum())})

    base_name = next(iter(models))
    for name in list(models)[1:]:
        for h in HORIZONS:
            for label in ["withdraw", "IA/operational"]:
                key = f"corrected|{label}"
                y, p0 = preds[base_name][h][key]["y"], preds[base_name][h][key]["p"]
                p1 = preds[name][h][key]["p"]
                draws = []
                for _ in range(N_BOOTSTRAP):
                    i = rng.integers(0, len(y), len(y))
                    if y[i].min() != y[i].max():
                        draws.append(roc_auc_score(y[i], p1[i]) - roc_auc_score(y[i], p0[i]))
                deltas.append({"split": split, "model": name, "versus": base_name, "event": label,
                               "horizon_quarters": h, "auc_delta": safe_auc(y, p1) - safe_auc(y, p0),
                               "ci95_low": float(np.quantile(draws, 0.025)),
                               "ci95_high": float(np.quantile(draws, 0.975)),
                               "bootstrap_replicates": len(draws)})
    return pd.DataFrame(rows), pd.DataFrame(deltas)


def run_split(split: str, frame: pd.DataFrame, cutoff: pd.Timestamp, active: pd.DataFrame | None,
              rng: np.random.Generator) -> tuple[pd.DataFrame, pd.DataFrame]:
    pure_raw, censored_raw, test_raw = censored_split(frame, cutoff)
    pure_maps = v1.fit_category_maps(pure_raw)
    pure, test_pure = v1.apply_category_maps(pure_raw, pure_maps), v1.apply_category_maps(test_raw, pure_maps)
    _, v1_lgbm = v1.fit_models(pure, V1_LOGIT_C, V1_LGBM)
    maps = v1.fit_category_maps(censored_raw)
    train, test = v1.apply_category_maps(censored_raw, maps), v1.apply_category_maps(test_raw, maps)
    v2 = fit_queue_time_model(train)

    known = followed_until(test, active)
    # v1 and v2 share test rows; only their category maps differ, so wrap v1 to use its own.
    class _V1:
        name = "v1 LightGBM calibrated (project-pure)"
        def predict_proba(self, f: pd.DataFrame) -> np.ndarray:
            return v1_lgbm.predict_proba(v1.apply_category_maps(f, pure_maps))
    models = {"v1 LightGBM calibrated (project-pure)": _V1(),
              "Age-only (censored)": v2["age"],
              "v2 LightGBM calibrated (censored)": v2["lgbm"],
              "v2 queue-time model": v2["final"]}
    metrics, deltas = evaluate(split, test, models, known, rng)
    # In-sample age-marker fit, each model on its own training rows.
    train_rows = (age_marker_metrics(split, "train", "v1 LightGBM calibrated (project-pure)", _V1(), pure)
                  + age_marker_metrics(split, "train", "v2 queue-time model", v2["final"], train))
    return pd.concat([metrics, pd.DataFrame(train_rows)], ignore_index=True), deltas


def expected_time_in_queue(model: Any, frame: pd.DataFrame, horizon: int = 40) -> np.ndarray:
    """Restricted mean quarters until any exit (withdrawal or IA), truncated at the horizon."""
    survival = np.ones(len(frame))
    total = np.zeros(len(frame))
    for t in range(1, horizon + 1):
        future = frame.copy()
        future["age_quarters"] = frame["age_quarters"].to_numpy() + t - 1
        total += survival
        survival *= model.predict_proba(future)[:, 0]
    return total


def plot_age_markers(metrics: pd.DataFrame, out: Path) -> None:
    """Train vs recent-test charts at queue-age markers, in the style of the team's v1 charts."""
    styles = {"v1 LightGBM calibrated (project-pure)": ("#808080", "v1 LightGBM (project-pure)"),
              "v2 queue-time model": ("#2f6fb0", "v2 queue-time model")}
    events = {"withdraw": ("-", "o", "withdraw"), "IA/operational": ("--", "s", "IA/operational")}
    sub = metrics[(metrics["split"] == "TEST") & metrics["metric"].str.startswith("queue_age_marker")]
    specs = [("queue_age_marker_auc", "AUC at queue-age markers", "AUC (higher is better)",
              "queue_age_marker_auc.png"),
             ("queue_age_marker_logloss", "Log loss at queue-age markers",
              "Binary one-vs-rest log loss (lower is better)", "queue_age_marker_logloss.png")]
    for metric, title, ylabel, filename in specs:
        fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), sharey=True)
        for ax, (sample, panel) in zip(axes, [("train", "Train"), ("test", "Recent test")]):
            for model, (color, label) in styles.items():
                for event, (ls, marker, ev_label) in events.items():
                    g = sub[(sub["metric"] == metric) & (sub["sample"] == sample)
                            & (sub["model"] == model) & (sub["event"] == event)].sort_values("age_quarters")
                    ax.plot(g["age_quarters"], g["value"], linestyle=ls, marker=marker, color=color,
                            linewidth=2, markersize=7, label=f"{label} | {ev_label}")
            if metric.endswith("auc"):
                ax.axhline(0.5, color="grey", linestyle=":", linewidth=1)
            ax.set(title=panel, xlabel="Queue age", xticks=AGE_MARKERS,
                   xticklabels=[f"Quarter {a}" for a in AGE_MARKERS])
            ax.grid(axis="y", alpha=0.3)
        axes[0].set_ylabel(ylabel)
        axes[1].legend(fontsize=9, loc="best")
        fig.suptitle(f"{title}: v1 vs v2 (train <= 2022Q4, recent test 2023-2025)", fontsize=14)
        fig.tight_layout()
        fig.savefig(out / filename, dpi=180)
        plt.close(fig)


def plot_auc(metrics: pd.DataFrame, out: Path) -> None:
    sub = metrics[(metrics["metric"] == "horizon_auc_corrected") & (metrics["split"] == "TEST")]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), sharey=True)
    for ax, event in zip(axes, ["IA/operational", "withdraw"]):
        for model, g in sub[sub["event"] == event].groupby("model", sort=False):
            ax.plot(g["horizon_quarters"], g["value"], marker="o", label=model)
        ax.axhline(0.5, color="grey", linestyle=":", linewidth=1)
        ax.set(title=event, xlabel="Forecast horizon (quarters)", xticks=HORIZONS)
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("Time-dependent AUC (corrected)")
    axes[1].legend(fontsize=8, loc="lower right")
    fig.suptitle("NYISO out-of-time (2023-2025) horizon AUC: v1 vs v2")
    fig.tight_layout()
    fig.savefig(out / "horizon_auc_v1_vs_v2.png", dpi=180)
    plt.close(fig)


def to_markdown(frame: pd.DataFrame) -> str:
    """Minimal markdown table (avoids a tabulate dependency)."""
    cols = [" ".join(map(str, c)) if isinstance(c, tuple) else str(c) for c in frame.columns]
    lines = ["| model | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
    for idx, row in frame.iterrows():
        lines.append(f"| {idx} | " + " | ".join(f"{v:.3f}" for v in row) + " |")
    return "\n".join(lines)


def write_report(metrics: pd.DataFrame, deltas: pd.DataFrame, out: Path) -> None:
    def table(split: str, metric: str, by: str = "horizon_quarters") -> str:
        sub = metrics[(metrics["split"] == split) & (metrics["metric"] == metric)
                      & (metrics["sample"] != "train")]
        piv = sub.pivot_table(index="model", columns=["event", by], values="value", sort=False)
        piv.columns = [f"{event} {int(k)}q" for event, k in piv.columns]
        return to_markdown(piv)

    def auc(model: str, event: str, h: int) -> float:
        sub = metrics[(metrics["split"] == "TEST") & (metrics["metric"] == "horizon_auc_corrected")
                      & (metrics["model"] == model) & (metrics["event"] == event)
                      & (metrics["horizon_quarters"] == h)]
        return float(sub["value"].iloc[0])

    def scalar(split: str) -> str:
        sub = metrics[(metrics["split"] == split) & metrics["event"].isna()]
        return to_markdown(sub.pivot_table(index="model", columns="metric", values="value", sort=False))

    d = deltas[(deltas["split"] == "TEST") & (deltas["model"] == "v2 queue-time model")]
    d_txt = "\n".join(
        f"| {r.event} | {r.horizon_quarters} | {r.auc_delta:+.3f} | [{r.ci95_low:+.3f}, {r.ci95_high:+.3f}] |"
        for r in d.itertuples())
    report = f"""# NYISO queue-time estimator v2

The model estimates, for each queued project, the quarterly probability of withdrawing or reaching
IA/operation and turns those hazards into 4-, 8- and 12-quarter cumulative risks plus an expected time
in queue. v2 keeps v1's panel, features and forecasting method and changes training and model form
(see the module docstring of `nyiso_queue_time_v2.py`).

Design choices were made on the inner validation split (train <= 2019Q4, validate 2020-2022) before the
2023-2025 test was examined.

## Test (2023-2025): corrected horizon AUC

Controls include projects known to be still queued at the horizon.

{table("TEST", "horizon_auc_corrected")}

## Test: v1 landmark AUC definition (comparable with the slides)

{table("TEST", "horizon_auc_v1")}

## Test: v2 queue-time model minus v1, corrected AUC (project bootstrap, {N_BOOTSTRAP} draws)

| event | horizon | delta AUC | 95% CI |
|---|---|---|---|
{d_txt}

## Test: probability quality

{scalar("TEST")}

## Validation (2020-2022): corrected horizon AUC

{table("VALID", "horizon_auc_corrected")}

{scalar("VALID")}

## Test: row-level AUC at queue-age markers

Columns are queue age, not forecast horizon. Blank cells (nan) have no events at that age.

{table("TEST", "queue_age_marker_auc", by="age_quarters")}

## Interpretation

- The clearest gain is short-horizon withdrawal ranking. The 4-quarter gain is the only withdrawal change
  whose interval excludes zero on test; it is also large on validation.
- Censored training removes most of v1's withdrawal over-prediction. v2 now *under*-predicts the
  2024-2025 test, because the Order 2023 transition withdrawals (2024Q2, 2024Q4, 2025Q1) have no
  precedent in pre-2023 training data. No pre-2023 model can learn that calendar shock.
- 12-quarter IA ranking is lower than v1 on test. The test has only 24 IA events, and v1's IA advantage
  does not appear on validation, where v2 is better at every horizon.
- v1's 12-quarter withdrawal AUC (0.94 on the slides) mostly measures "withdrew vs reached IA", because
  projects still queued at the end of the window were excluded. Under the corrected definition v1 is
  {auc("v1 LightGBM calibrated (project-pure)", "withdraw", 12):.3f}.
- The 148 projects still queued at the 2025-12-31 cutoff count as stays in their final quarter (the
  panel flags those rows ineligible, which made 2025Q4 look like a 100% withdrawal quarter and pushed
  v1's active-project 4-quarter withdrawal scores to a 75% mean).
- Row-level queue-age-marker AUCs are weak for every model and v2 is *worse* than v1 at ages 4 and 8.
  At a fixed age, who withdraws in a given quarter is driven mostly by calendar-time administrative
  events, and v1's project-pure training happens to encode "recent cohort, so withdraw", which matched
  the 2024 purge. Use v2 for horizon risk and time-in-queue, not single-quarter timing at a fixed age.
- Active-project withdrawal scores remain high because the 2025Q4 lagged regional withdrawal rate
  (which reflects the 2024-2025 purge) is frozen over the forecast. That is a scenario, not a forecast.
"""
    (out / "NYISO_queue_time_v2_report.md").write_text(report, encoding="utf-8")


def main() -> None:
    args = parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)

    engineered = v1.add_engineered_features(v1.load_panel(args.input))
    active_rows = engineered[~engineered["model_eligible"]]
    # Active projects' final (2025Q4) rows are flagged ineligible, which leaves 2025Q4 with only
    # withdrawals (a 100% hazard) and inflates frozen-feature scores.  These projects were still
    # queued at the panel cutoff, so their final quarter is a stay.
    final_stays = engineered.loc[active_rows.index].assign(y=0)
    eligible = pd.concat([engineered[engineered["model_eligible"] & engineered["y"].notna()],
                          final_stays]).sort_values(["project_id", "age_quarters"])
    pre_test = eligible[eligible["quarter_start"] <= TEST_CUTOFF]

    results = [run_split("VALID", pre_test, VALID_CUTOFF, None, rng),
               run_split("TEST", eligible, TEST_CUTOFF, active_rows, rng)]
    metrics = pd.concat([r[0] for r in results], ignore_index=True)
    deltas = pd.concat([r[1] for r in results], ignore_index=True)
    metrics.to_csv(out / "model_comparison_metrics.csv", index=False)
    deltas.to_csv(out / "auc_delta_vs_v1_bootstrap.csv", index=False)
    plot_auc(metrics, out)
    plot_age_markers(metrics, out)
    write_report(metrics, deltas, out)

    # Final model: all eligible rows; active projects are naturally censored at the panel cutoff.
    maps = v1.fit_category_maps(eligible)
    final = fit_queue_time_model(v1.apply_category_maps(eligible, maps))
    active = v1.apply_category_maps(active_rows, maps)
    scores = v1.score_active(final["final"], active, out, save=False)
    scores["expected_quarters_in_queue_40q"] = expected_time_in_queue(final["final"], active)
    scores["scoring_assumption"] = "v2; age advances; 2025Q4 queue-condition features frozen"
    scores.to_csv(out / "NYISO_active_project_scores_v2.csv", index=False)

    joblib.dump({
        "region": "NYISO", "cutoff": "2025-12-31", "seed": SEED, "version": 2,
        "queue_time_model": final["final"], "category_maps": maps,
        "hyperparameters": {"lightgbm": V2_LGBM, "withdraw_age_blend_weight": WITHDRAW_BLEND_WEIGHT},
        "feature_assumptions": {"active_forecast": "age advances; queue-condition features frozen",
                                "training": "all eligible rows; active projects right-censored"},
    }, out / "NYISO_queue_time_v2_model.joblib", compress=3)
    manifest = {"input": str(args.input.resolve()), "output": str(out),
                "files": sorted(p.name for p in out.iterdir() if p.is_file())}
    (out / "run_manifest.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps({"status": "complete", **manifest}, indent=2))


if __name__ == "__main__":
    main()
