# NYISO queue-time estimator v2

The model estimates, for each queued project, the quarterly probability of withdrawing or reaching
IA/operation and turns those hazards into 4-, 8- and 12-quarter cumulative risks plus an expected time
in queue. v2 keeps v1's panel, features and forecasting method and changes training and model form
(see the module docstring of `nyiso_queue_time_v2.py`).

Design choices were made on the inner validation split (train <= 2019Q4, validate 2020-2022) before the
2023-2025 test was examined.

## Test (2023-2025): corrected horizon AUC

Controls include projects known to be still queued at the horizon.

| model | withdraw 4q | IA/operational 4q | withdraw 8q | IA/operational 8q | withdraw 12q | IA/operational 12q |
|---|---|---|---|---|---|---|
| v1 LightGBM calibrated (project-pure) | 0.664 | 0.932 | 0.886 | 0.928 | 0.883 | 0.923 |
| Age-only (censored) | 0.703 | 0.912 | 0.878 | 0.821 | 0.852 | 0.749 |
| v2 LightGBM calibrated (censored) | 0.715 | 0.926 | 0.845 | 0.923 | 0.832 | 0.839 |
| v2 queue-time model | 0.715 | 0.925 | 0.896 | 0.921 | 0.888 | 0.825 |

## Test: v1 landmark AUC definition (comparable with the slides)

| model | withdraw 4q | IA/operational 4q | withdraw 8q | IA/operational 8q | withdraw 12q | IA/operational 12q |
|---|---|---|---|---|---|---|
| v1 LightGBM calibrated (project-pure) | 0.664 | 0.932 | 0.886 | 0.928 | 0.945 | 0.934 |
| Age-only (censored) | 0.703 | 0.912 | 0.878 | 0.821 | 0.856 | 0.775 |
| v2 LightGBM calibrated (censored) | 0.715 | 0.926 | 0.845 | 0.923 | 0.783 | 0.842 |
| v2 queue-time model | 0.715 | 0.925 | 0.896 | 0.921 | 0.863 | 0.827 |

## Test: v2 queue-time model minus v1, corrected AUC (project bootstrap, 300 draws)

| event | horizon | delta AUC | 95% CI |
|---|---|---|---|
| withdraw | 4 | +0.051 | [+0.028, +0.076] |
| IA/operational | 4 | -0.007 | [-0.024, +0.010] |
| withdraw | 8 | +0.010 | [-0.019, +0.043] |
| IA/operational | 8 | -0.006 | [-0.024, +0.010] |
| withdraw | 12 | +0.005 | [-0.032, +0.040] |
| IA/operational | 12 | -0.098 | [-0.137, -0.064] |

## Test: probability quality

| model | multiclass_log_loss | multiclass_brier | mean_pred_withdraw | observed_withdraw | mean_pred_ia | observed_ia |
|---|---|---|---|---|---|---|
| v1 LightGBM calibrated (project-pure) | 0.644 | 0.420 | 0.334 | 0.171 | 0.059 | 0.005 |
| Age-only (censored) | 0.586 | 0.316 | 0.052 | 0.171 | 0.010 | 0.005 |
| v2 LightGBM calibrated (censored) | 0.597 | 0.318 | 0.060 | 0.171 | 0.022 | 0.005 |
| v2 queue-time model | 0.592 | 0.318 | 0.056 | 0.171 | 0.022 | 0.005 |

## Validation (2020-2022): corrected horizon AUC

| model | withdraw 4q | IA/operational 4q | withdraw 8q | IA/operational 8q | withdraw 12q | IA/operational 12q |
|---|---|---|---|---|---|---|
| v1 LightGBM calibrated (project-pure) | 0.572 | 0.862 | 0.605 | 0.796 | 0.546 | 0.765 |
| Age-only (censored) | 0.598 | 0.920 | 0.646 | 0.918 | 0.824 | 0.866 |
| v2 LightGBM calibrated (censored) | 0.736 | 0.956 | 0.690 | 0.916 | 0.699 | 0.855 |
| v2 queue-time model | 0.743 | 0.957 | 0.707 | 0.917 | 0.772 | 0.843 |

| model | multiclass_log_loss | multiclass_brier | mean_pred_withdraw | observed_withdraw | mean_pred_ia | observed_ia |
|---|---|---|---|---|---|---|
| v1 LightGBM calibrated (project-pure) | 0.603 | 0.380 | 0.352 | 0.057 | 0.034 | 0.015 |
| Age-only (censored) | 0.278 | 0.134 | 0.045 | 0.057 | 0.006 | 0.015 |
| v2 LightGBM calibrated (censored) | 0.264 | 0.130 | 0.043 | 0.057 | 0.009 | 0.015 |
| v2 queue-time model | 0.264 | 0.130 | 0.044 | 0.057 | 0.009 | 0.015 |

## Test: row-level AUC at queue-age markers

Columns are queue age, not forecast horizon. Blank cells (nan) have no events at that age.

| model | withdraw 4q | withdraw 8q | withdraw 12q |
|---|---|---|---|
| v1 LightGBM calibrated (project-pure) | 0.603 | 0.776 | 0.626 |
| Age-only (censored) | 0.500 | 0.500 | 0.500 |
| v2 LightGBM calibrated (censored) | 0.426 | 0.726 | 0.540 |
| v2 queue-time model | 0.426 | 0.726 | 0.540 |

## Interpretation

- The clearest gain is short-horizon withdrawal ranking. The 4-quarter gain is the only withdrawal change
  whose interval excludes zero on test; it is also large on validation.
- Censored training removes most of v1's withdrawal over-prediction. v2 now *under*-predicts the
  2024-2025 test, because the Order 2023 transition withdrawals (2024Q2, 2024Q4, 2025Q1) have no
  precedent in pre-2023 training data. No pre-2023 model can learn that calendar shock.
- 12-quarter IA ranking is lower than v1 on test. The test has only 24 IA events, and v1's IA advantage
  does not appear on validation, where v2 is better at every horizon.
- v1's 12-quarter withdrawal AUC (0.94 on the slides) mostly measures "withdrew vs reached IA", because
  projects still queued at the end of the window were excluded. Under the corrected definition v1 is
  0.883.
- The 148 projects still queued at the 2025-12-31 cutoff count as stays in their final quarter (the
  panel flags those rows ineligible, which made 2025Q4 look like a 100% withdrawal quarter and pushed
  v1's active-project 4-quarter withdrawal scores to a 75% mean).
- Row-level queue-age-marker AUCs are weak for every model and v2 is *worse* than v1 at ages 4 and 8.
  At a fixed age, who withdraws in a given quarter is driven mostly by calendar-time administrative
  events, and v1's project-pure training happens to encode "recent cohort, so withdraw", which matched
  the 2024 purge. Use v2 for horizon risk and time-in-queue, not single-quarter timing at a fixed age.
- Active-project withdrawal scores remain high because the 2025Q4 lagged regional withdrawal rate
  (which reflects the 2024-2025 purge) is frozen over the forecast. That is a scenario, not a forecast.
