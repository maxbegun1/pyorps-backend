# NYISO queue-time estimator (v2)

v2 of the NYISO competing-risks model. For each project in the queue, it estimates the chance of
**withdrawing** or **reaching an IA/operation** in each quarter. It then turns those quarterly chances
into risks over 4, 8 and 12 quarters, an expected time to IA, and an expected time in queue.

v1 is still in place: `nyiso_competing_risks.py` and `results/` are unchanged, so the numbers on the
Week 9 slides still reproduce.

## TL;DR

- v2 ranks **4-quarter withdrawal** clearly better than v1: AUC **0.664 → 0.715**. This is the one
  withdrawal gain we can be confident in.
- At 8 and 12 quarters, withdrawal AUC is about the same (+0.01). IA AUC at 4 and 8 quarters is
  unchanged (~0.92).
- **IA AUC at 12 quarters is worse on test (0.923 → 0.825).** The test has only 24 IA events. On the
  2020–2022 validation period, v2 beats v1 on IA at every horizon.
- Probabilities are much better calibrated. Test Brier 0.420 → 0.318. Validation log loss 0.603 → 0.264.
- We found **two problems in v1**:
  - its 12-quarter withdrawal AUC is inflated;
  - its active-project scores are inflated.

  Both are explained below.
- The withdrawal ceiling is set by the data. The 2024–2025 Order 2023 transition withdrawals have no
  precedent in the training data, so no model trained before 2023 can predict their timing.

## Files

| File | What it is |
|---|---|
| `nyiso_queue_time_v2.py` | Full v2 pipeline: validation, test, comparison with v1, final fit, scoring |
| `queue_time_models.py` | Hazard model classes (age-only, blend, cause-specific) used by the saved model |
| `score_nyiso.py` | Scorer; now accepts the v1 or the v2 model bundle |
| `results_v2/NYISO_queue_time_v2_report.md` | Auto-generated tables (regenerated on every run) |
| `results_v2/model_comparison_metrics.csv` | Every metric, model, split and horizon in long format |
| `results_v2/auc_delta_vs_v1_bootstrap.csv` | v2 minus v1 AUC with 95% project-bootstrap intervals |
| `results_v2/horizon_auc_v1_vs_v2.png` | Test horizon AUC chart |
| `results_v2/NYISO_active_project_scores_v2.csv` | Scores for the 148 active projects, including `expected_quarters_in_queue_40q` |
| `results_v2/NYISO_queue_time_v2_model.joblib` | Final v2 model bundle |

## How to run

```bash
cd regional_models/NYISO
pip install -r requirements.txt
python nyiso_queue_time_v2.py --input data/NYISO_panel_model_ready.csv --output results_v2   # ~2 min
python score_nyiso.py --input data/NYISO_panel_model_ready.csv \
    --model results_v2/NYISO_queue_time_v2_model.joblib --output-dir scores
```

Tested with Python 3.14, lightgbm 4.7, scikit-learn 1.9.1 and pandas 3.1.

## What changed from v1, and why

### 1. Training keeps every project up to the cutoff (no more project-pure split)

v1 drops every project that is still in the queue at the training cutoff. As a result, the recent
entry cohorts left in training are **only the projects that exited quickly**, and most of those exited
by withdrawing. The model learns "recent cohort → withdraws soon". That is survivorship bias, and it
is why v1 predicted a mean quarterly withdrawal rate of 33.6% against 17.6% observed (slides 21 and 28).
On the 2020–2022 validation it predicted 35% against 5.7%.

v2 trains on **every project-quarter up to the cutoff**. Projects still active at the cutoff count as
right-censored: we know they stayed up to that point and don't know what happened after. No
information from after the cutoff enters training. The test rows are exactly the same as v1's: the
project-pure 2023–2025 rows.

### 2. Separate IA and withdrawal models

Following Max's suggestion of one model per outcome:

- **IA hazard** comes from a calibrated LightGBM with shallower, slower-learning trees:
  `n_estimators=300, learning_rate=0.02, num_leaves=7, max_depth=3, min_child_samples=200`.
- **Withdrawal hazard** is a 50/50 blend of that LightGBM and the age-only hazard. Age-only is the most
  stable model under the 2024 regime shift. LightGBM adds signal on MW ahead and entry cohort.
- The chance of staying is whatever is left over. The quarterly hazards are turned into cumulative
  risks the same way as in v1, with queue conditions frozen and age advancing.

### 3. Projects still queued at the panel cutoff count as stays

The panel marks the final 2025Q4 row of each of the 148 active projects as `model_eligible = FALSE`.
So the only eligible 2025Q4 rows are the 46 withdrawals, and **2025Q4 looks like a quarter where 100%
of projects withdrew**. Active projects are scored from their 2025Q4 row, so v1's active scores
inherit this: a 75% mean 4-quarter withdrawal risk. These projects were still in the queue on
2025-12-31, so v2 counts their last quarter as a stay. The mean 4-quarter withdrawal risk for active
projects drops to 42%.

### 4. Corrected horizon AUC

v1's horizon AUC excludes any project whose window goes past the last observed quarter. That is an
off-by-one: the 12-quarter window from 2023Q1 ends exactly at the panel cutoff. Every project still
in the queue is therefore excluded, which leaves **797 withdrawals against only 24 non-withdrawers**,
and those 24 are the IA projects. So v1's 12-quarter withdrawal AUC (0.945 on slide 12) really
measures "withdrew vs reached IA", not "withdrew vs stayed in the queue".

v2 reports both definitions. The **corrected** one counts as a control any project known to still
be in the queue at the horizon, including projects that withdrew later. Under it, v1's 12-quarter
withdrawal AUC is 0.883.

### How choices were made (avoiding overfitting)

All design choices were picked on an **inner out-of-time validation**: train on data up to 2019Q4,
validate on 2020–2022, project-pure. The 2023–2025 test was examined only after that.

Things we tried that did **not** help on validation, and so were dropped:

- MW-ahead share of the active queue
- queue rank percentile
- total active projects
- entry-cohort MW and project count
- trailing 4-quarter queue inflow
- removing class weights
- spline age in the trees
- a smaller feature set

## Results

All AUCs below use the **corrected** time-dependent definition unless noted. Horizon = quarters from a
project's first test quarter.

### Test (train ≤ 2022Q4, test 2023–2025: 969 projects, 797 withdrawals, 24 IA)

| Model | WD 4q | WD 8q | WD 12q | IA 4q | IA 8q | IA 12q |
|---|---|---|---|---|---|---|
| v1 LightGBM (project-pure) | 0.664 | 0.886 | 0.883 | 0.932 | 0.928 | 0.923 |
| Age-only (censored) | 0.703 | 0.878 | 0.852 | 0.912 | 0.821 | 0.749 |
| v2 LightGBM (censored) | 0.715 | 0.845 | 0.832 | 0.926 | 0.923 | 0.839 |
| **v2 queue-time model** | **0.715** | **0.896** | **0.888** | 0.925 | 0.921 | 0.825 |

v2 minus v1, with 95% project-bootstrap intervals (300 resamples):

| | 4q | 8q | 12q |
|---|---|---|---|
| Withdrawal | **+0.051 [+0.028, +0.076]** | +0.010 [−0.019, +0.043] | +0.005 [−0.032, +0.040] |
| IA | −0.007 [−0.024, +0.010] | −0.006 [−0.024, +0.010] | **−0.098 [−0.137, −0.064]** |

Probability quality on test rows:

| Model | Log loss | Brier | Mean predicted withdrawal | Observed |
|---|---|---|---|---|
| v1 LightGBM | 0.644 | 0.420 | 0.334 | 0.171 |
| Age-only | **0.586** | **0.316** | 0.052 | 0.171 |
| v2 queue-time model | 0.592 | 0.318 | 0.056 | 0.171 |

Using v1's original AUC definition, which is the one on the slides, v2's test withdrawal AUCs are
0.715 / 0.896 / 0.863 and v1's are 0.664 / 0.886 / 0.945.

### Validation (train ≤ 2019Q4, validate 2020–2022: 251 withdrawals, 67 IA)

| Model | WD 4q | WD 8q | WD 12q | IA 4q | IA 8q | IA 12q | Log loss |
|---|---|---|---|---|---|---|---|
| v1 LightGBM (project-pure) | 0.572 | 0.605 | 0.546 | 0.862 | 0.796 | 0.765 | 0.603 |
| Age-only (censored) | 0.598 | 0.646 | **0.824** | 0.920 | **0.918** | **0.866** | 0.278 |
| **v2 queue-time model** | **0.743** | **0.707** | 0.772 | **0.957** | 0.917 | 0.843 | **0.264** |

### Single-quarter AUC at fixed queue ages (Alexis's chart), test

| Model | WD age 4 | WD age 8 | WD age 12 |
|---|---|---|---|
| v1 LightGBM | 0.603 | 0.776 | 0.626 |
| v2 queue-time model | 0.426 | 0.726 | 0.540 |

![AUC at queue-age markers](results_v2/queue_age_marker_auc.png)

![Log loss at queue-age markers](results_v2/queue_age_marker_logloss.png)

These charts use the same layout as the team's earlier "separate logits vs competing risks" charts.
"Train" is in-sample: each model is scored on its own training rows (project-pure rows for v1,
censored rows for v2). "Recent test" is 2023–2025. Notes on reading them:

- No test project reached IA at exactly age 4, 8 or 12, so the test panel has no IA AUC line.
- Train IA at age 8 rests on a single event, so the AUC of 1.0 there is not meaningful.
- On test, v2's withdrawal log loss spikes at age 8 (0.815 vs 0.540). At that age 23% of projects
  withdrew in the quarter (38 of 163, mostly in the purge quarters), and v2's calibrated
  pre-2023 hazard is far below that.

This measures something different from the horizon AUC above. It asks: among projects that are
exactly 4 (or 8, 12) quarters old, who withdraws *in that quarter*? Age-only is 0.5 here by
construction. There are no IA events at these ages in the test.

## Discussion

**Where v2 helps.** The clear gain is in ranking which projects withdraw within about a year, which is
the horizon that matters most for near-term planning. The gain shows up on both the validation and the
test windows, and on test its interval excludes zero. v2's probabilities are also on the right scale
for the training era. v1 overstated withdrawal risk by about 6× on validation and about 2× on test.

**Where v2 does not help, or hurts.**

- **IA at 12 quarters (test).** v1 is better here. But the test has only 24 IA events, all from older
  cohorts (no project entering in 2020 or later has reached IA), and v1's advantage disappears on
  validation. We read this as small-sample noise plus the recent-cohort artifact, not as a real
  strength of v1. If 12-quarter IA ranking is the priority, keeping v1's IA model alongside v2's
  withdrawal model is a defensible choice.
- **Single-quarter timing at fixed ages.** v2 is worse. Which 4-quarter-old project withdraws in a
  *specific* quarter is driven mainly by calendar events: the Order 2023 transition purges in 2024Q2,
  2024Q4 and 2025Q1. v1's survivorship bias happens to encode "recent cohort → withdraw", which matched
  that purge.
- **Calibration under the 2024–2025 shock.** v2 now *under*-predicts test withdrawal: 5.6% predicted
  vs 17.1% observed per quarter. No model trained before 2023 has seen an administrative purge, so
  this cannot be learned from the data. On test, age-only still has slightly better log loss than v2
  (0.586 vs 0.592).

**What this says about the data.** This backs up the team's conclusion (Patrick and Alexis) that the
data, not the modeling, is the limit. IA is easy to rank because it is driven by age and maturity.
Withdrawal timing in 2023–2025 is dominated by regulatory deadlines that leave no trace in project
features. More features (cohort MW, queue inflow, position share) did not help. The useful signals
remain age, MW ahead, entry cohort and the lagged regional withdrawal rate.

**Recommended use for clients.**

- Use v2 to **rank projects by near-term withdrawal risk and by expected time in queue**, and v1 or v2
  for IA prioritization.
- Do not use either model as a calibrated forecast of withdrawal counts across a reform. The
  active-project scores assume 2025Q4 queue conditions stay frozen. That includes a regional
  withdrawal rate inflated by the purge, so treat them as a stress scenario.
- Re-estimate once post-reform cluster-study data (2025+) accumulates. That is the first period where
  the new regime is visible in training.

## Caveats carried over from v1

- 686 NYISO withdrawal dates are proxies from the "Last Update" field.
- MW, technology, utility and POI are end-of-period snapshots.
- `prop_date` is excluded because it is a revisable 2025 snapshot.
- Results are predictive associations, not causal effects.
- Expected time to IA and expected time in queue are truncated at 40 quarters.
