#!/usr/bin/env python3
"""Reusable scorer for an updated NYISO person-period panel.

The input must use the same schema as NYISO_panel_model_ready.csv.  The scorer
rebuilds time-valid engineered features from the full supplied panel and scores
the model_eligible == FALSE rows under the frozen-queue-condition scenario.
Accepts either the v1 bundle (NYISO_competing_risks_model.joblib) or the v2
queue-time bundle (NYISO_queue_time_v2_model.joblib).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import joblib

from nyiso_competing_risks import (
    FittedModel, add_engineered_features, apply_category_maps, load_panel, score_active,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--model", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    bundle = joblib.load(args.model)
    panel = add_engineered_features(load_panel(args.input))
    active = panel[~panel["model_eligible"]].copy()
    active = apply_category_maps(active, bundle["category_maps"])
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if bundle.get("version") == 2:
        from nyiso_queue_time_v2 import expected_time_in_queue

        model = bundle["queue_time_model"]
        scores = score_active(model, active, args.output_dir, save=False)
        scores["expected_quarters_in_queue_40q"] = expected_time_in_queue(model, active)
        scores["scoring_assumption"] = "v2; age advances; queue-condition features frozen"
        path = args.output_dir / "NYISO_active_project_scores_v2.csv"
        scores.to_csv(path, index=False)
    else:
        model = FittedModel(**bundle["preferred_model"])
        score_active(model, active, args.output_dir)
        path = args.output_dir / "NYISO_active_project_scores.csv"
    print(path)


if __name__ == "__main__":
    main()
