"""Quarterly hazard models used by the v2 NYISO queue-time estimator.

Every class exposes ``predict_proba(frame) -> (n, 3)`` over (stay, withdraw,
IA/operational), so it plugs into ``forecast_cif`` and ``score_active`` from
``nyiso_competing_risks``.  Kept in a separate module so joblib bundles unpickle
cleanly from any entry point.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from nyiso_competing_risks import age_naive_fit, age_naive_predict


@dataclass
class AgeOnlyHazard:
    hazards: pd.DataFrame
    name: str = "Age-only"

    @classmethod
    def fit(cls, train: pd.DataFrame) -> "AgeOnlyHazard":
        return cls(age_naive_fit(train))

    def predict_proba(self, frame: pd.DataFrame) -> np.ndarray:
        return age_naive_predict(frame, self.hazards)


@dataclass
class BlendedHazard:
    """Convex blend of two hazard models; shrinks a flexible model toward age-only."""
    first: Any
    second: Any
    weight: float
    name: str

    def predict_proba(self, frame: pd.DataFrame) -> np.ndarray:
        return (self.weight * self.first.predict_proba(frame)
                + (1.0 - self.weight) * self.second.predict_proba(frame))


@dataclass
class CauseSpecificHazard:
    """IA hazard from one model and withdrawal hazard from another; stay is the remainder."""
    ia_model: Any
    withdraw_model: Any
    name: str

    def predict_proba(self, frame: pd.DataFrame) -> np.ndarray:
        p_ia = self.ia_model.predict_proba(frame)[:, 2]
        p_wd = self.withdraw_model.predict_proba(frame)[:, 1]
        total = p_ia + p_wd
        scale = np.where(total > 0.999, 0.999 / total, 1.0)
        p_ia, p_wd = p_ia * scale, p_wd * scale
        return np.column_stack([1.0 - p_ia - p_wd, p_wd, p_ia])
