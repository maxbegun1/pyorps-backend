# NYISO model package

Start with `results/NYISO_Master_Competing_Risks_Report.docx` for the full business and technical interpretation.

- `data/NYISO_panel_model_ready.csv`: model-ready quarterly person-period panel.
- `nyiso_competing_risks.py`: reproducible training, evaluation, sensitivity, and reporting pipeline.
- `score_nyiso.py`: reusable scoring entry point.
- `results/`: trained model, active-project scores, audit outputs, validation metrics, calibration results, sensitivity tables, and charts.

The active-project scores are experimental diagnostics and are not calibrated operational forecasts.


## NYISO queue-time estimator v2

See [README_queue_time_v2.md](README_queue_time_v2.md) for the Model 2 architecture, input, training and scoring commands, results, and limitations. The v2 code and fitted model are in this folder and `results_v2/`.
