# NYISO discrete-time competing-risks model

## Executive result

The best of the two requested multivariable specifications is **LightGBM calibrated**, but it is
**experimental rather than deployment-ready**. On the project-pure 2023–2025
out-of-time test, multinomial log loss was 0.7290 for the regularized logit,
0.6423 for calibrated LightGBM, and 0.5516 for the age-only benchmark.
Multiclass Brier scores were 0.4359 and 0.4190. Lower is better for both metrics.
Neither multivariable model beats the age-only benchmark out of time. The active-project score
file is supplied as requested, but its probabilities should not be used for operational decisions
until recalibrated on newer, cleaner event timing.

The IA result is intrinsically weak: only 166 IA events
exist in the full file, only 24 occur in the OOT test rows, and no post-2020 entry
cohort has an observed IA. Mean horizon concordance was 0.907 for IA and 0.817
for withdrawal across the reported model/horizon combinations. IA scores should be treated as
rough prioritization, not dependable forecasts.

## Data and validation

- Audit: 18,328 rows, 1,732 projects, 0
  integrity failures, and 148 active projects to score.
- Project-pure OOT split: 8,442 rows / 763 training
  projects and 4,526 rows / 969 test projects, with
  0 project overlap.
- The time split is stricter than an ordinary row-based cutoff: a project that appears after
  2022Q4 contributes no rows to training.
- Hyperparameters were selected only inside the training-project set with grouped inner CV.
  Five-fold stability CV also keeps every project's rows in one fold.
- Random grouped five-fold log loss is 0.2400 for LightGBM and 0.2900 for the logit,
  much better than the out-of-time results. This gap is evidence of calendar/regime shift and
  explains why random CV alone would overstate production reliability.
- The entry-year range is 1998–2024. Because
  the region notes supplied no narrower entry-year window, no cohort was silently removed.

## Feature and leakage controls

Age uses flexible cubic splines in the logit. Queue backlog features use only panel membership at
the start of the row's quarter. POI/county counts exclude the focal project. Regional withdrawal
rate uses the prior four quarters and is shifted by one quarter. Developer history counts strictly
earlier queue entries. `panel_quarter` is not a predictive fixed effect. The Order 2023 indicator
uses NYISO's requested May 2, 2024 effective date, documented in
[NYISO's April 2024 compliance update](https://www.nyiso.com/documents/20142/43847922/06_Order%20No.%202023_2023-A%20Compliance%20Update_TPAS_20240401_final.pdf/bec463ce-42a9-b67e-8338-b7f9fe3d2075).
`service` is dropped because it is fully missing.

`prop_date` is excluded from the baseline. Its best sensitivity log loss was 0.5819; the
improvement is large enough to look suspicious.
The proposal date remains excluded because it is a revisable 2025 snapshot. Static project MW,
technology, utility, and POI are also snapshot fields and may differ from their entry-time values.

The coefficient table reports RRRs and project-cluster bootstrap intervals: regularized multinomial RRRs; 80 project-cluster bootstrap replicates; n=8442. A
penalized bootstrap is used because the thin IA class creates quasi-separation for unpenalized
MNLogit. These are descriptive associations in a predictive model. They are not causal effects.

## Interpreting congestion and sensitivity

`mw_ahead`, POI counts, and county counts measure **queue backlog**, not physical transmission
congestion. The proxy-withdrawal and spike-quarter runs show how much model fit and active-project
scores move when known timing-quality and administrative-shock concerns are removed. The spike
exclusion does not alter the pre-2023 OOT fit because those quarters occur after its training cutoff;
it is evaluated against the all-period scoring model instead.

## Scoring assumptions

Active-project CIFs advance age while freezing 2025Q4 time-varying queue-condition features. This
is a transparent scenario, not a forecast of future queue composition. Conditional expected time
to IA is truncated at 40 quarters because the data do not support a reliable infinite-horizon tail.
Predictions are probabilities conditional on the supplied snapshot, not causal conclusions or
guarantees of interconnection.
