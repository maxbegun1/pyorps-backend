# NYISO panel data audit

The file contains **18,328 rows and 1,732 projects**. There are
**18,180 model-eligible rows** and **148
currently active projects**. Eligible terminal events comprise **1,418
withdrawals** and **166 IA/operational events**.

Integrity checks found **0 failures**. Every passing project has consecutive
`age_quarters`, no more than one terminal event, and no rows after its terminal event. The audit
found 0 stop-level issue(s): none.

`service` is 100.0% missing and is dropped. `prop_date` is reserved for
the leakage sensitivity. POI, county, and developer are not one-hot encoded. They enter only through
time-valid backlog or prior-count features. Static MW, technology, utility, and POI values are
end-of-period snapshots and may differ from their values at queue entry.

The robust spike review flags: **2020Q1, 2020Q2, 2023Q1, 2023Q2, 2024Q1, 2024Q2, 2024Q3, 2024Q4, 2025Q1, 2025Q3, 2025Q4**. NYISO's
required 2024Q2, 2024Q4, and 2025Q1 sensitivity quarters are retained in the spike list even when a
mechanical threshold would not flag them.
