# NYISO queue-outcome model: planner summary

## What the model says

The model estimates each project's quarterly probability of staying in the queue, withdrawing, or
reaching an interconnection agreement/operation. It then combines those quarterly probabilities
into 4-, 8-, and 12-quarter cumulative risks. **LightGBM calibrated** is the stronger of the two requested
multivariable models, but the results are experimental.
The leading LightGBM signals are MW already ahead in the queue, entry cohort, flexible project-age
terms, and the lagged regional withdrawal rate. Project size, technology, developer history, and
POI/county queue backlogs add smaller signals. These backlog measures do not measure physical
transmission congestion, and SHAP importance does not establish causal direction.

## Reliability

Out-of-time log loss is 0.6423, versus 0.5516 for an age-only benchmark.
Because the benchmark is better, the current probabilities are not ready for operational use.
The test contains 797 withdrawals but only 24 IA/operational events.
Withdrawal predictions are therefore more useful than IA predictions. IA estimates have wide
uncertainty, especially for recent cohorts: the file contains no observed IA for projects entering
in 2020 or later. Use IA scores for triage and scenario planning, not precise commitment dates.

## Limits and appropriate use

This is a predictive, non-causal model. The source has 686 proxy-filled withdrawal dates, large
administrative withdrawal spikes in 2024Q2, 2024Q4, and 2025Q1, and no entries after October 2024.
Static MW, technology, and POI fields are end-of-period snapshots. Active-project forecasts freeze
current queue conditions while advancing project age, and expected time to IA is capped at a
40-quarter horizon. Refresh and recalibrate the model when newer queue entries, study milestones,
facility-upgrade costs, deposit/security status, and dated study-phase records become available.
