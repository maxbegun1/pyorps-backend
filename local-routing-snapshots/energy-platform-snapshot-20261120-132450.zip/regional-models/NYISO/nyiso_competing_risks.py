#!/usr/bin/env python3
"""Reproducible discrete-time competing-risks analysis for the NYISO panel.

The model predicts the mutually exclusive quarterly outcomes stay, withdraw, and
IA/operational.  It then converts the cause-specific quarterly hazards to CIFs.

Run:
    PYTHONPATH=.python_packages python nyiso_competing_risks.py \
        --input /path/to/NYISO_panel_model_ready.csv \
        --output nyiso_model_output
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("OMP_NUM_THREADS", "4")

import joblib
import lightgbm as lgb
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, SplineTransformer, StandardScaler

SEED = 20261020
np.random.seed(SEED)
random.seed(SEED)

OUTCOME_TO_INT = {"stay": 0, "withdraw": 1, "IA/operational": 2}
INT_TO_OUTCOME = {v: k for k, v in OUTCOME_TO_INT.items()}
ORDER_2023_NYISO_DATE = pd.Timestamp("2024-05-02")
SPIKE_QUARTERS_REQUIRED = ["2024Q2", "2024Q4", "2025Q1"]
HORIZONS = [4, 8, 12, 20]


@dataclass
class FittedModel:
    preprocessor: ColumnTransformer
    model: Any
    calibrator: Any | None
    name: str

    def predict_proba(self, frame: pd.DataFrame) -> np.ndarray:
        x = self.preprocessor.transform(frame)
        p = np.clip(self.model.predict_proba(x), 1e-9, 1.0)
        p = p / p.sum(axis=1, keepdims=True)
        if self.calibrator is not None:
            p = self.calibrator.predict_proba(np.log(p))
        return np.clip(p / p.sum(axis=1, keepdims=True), 1e-9, 1.0)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", default=Path("nyiso_model_output"), type=Path)
    return parser.parse_args()


def load_panel(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    for col in ["quarter_start", "observation_date", "q_date", "prop_date"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    for col in ["model_eligible", "audit_wd_date_proxy_flag"]:
        if df[col].dtype != bool:
            df[col] = df[col].astype(str).str.lower().map({"true": True, "false": False})
    return df.sort_values(["project_id", "age_quarters"]).reset_index(drop=True)


def audit_panel(df: pd.DataFrame, out: Path) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    problems: list[str] = []
    project_checks: list[dict[str, Any]] = []
    for pid, g in df.groupby("project_id", sort=False):
        ages = g["age_quarters"].to_numpy()
        consecutive = np.array_equal(ages, np.arange(ages.min(), ages.max() + 1))
        terminal = g["transition_outcome"].isin(["withdraw", "IA/operational"]).to_numpy()
        terminal_count = int(terminal.sum())
        rows_after = bool(terminal.any() and np.flatnonzero(terminal)[0] != len(g) - 1)
        if not consecutive or terminal_count > 1 or rows_after:
            project_checks.append(
                {"project_id": pid, "consecutive_age": consecutive,
                 "terminal_events": terminal_count, "rows_after_event": rows_after}
            )
    if project_checks:
        problems.append(f"{len(project_checks)} projects fail sequence/event checks")
        pd.DataFrame(project_checks).to_csv(out / "audit_project_integrity_failures.csv", index=False)

    if df.duplicated(["project_id", "age_quarters"]).any():
        problems.append("duplicate project_id/age_quarters rows")
    if set(df["transition_outcome"].dropna()) - {"stay", "withdraw", "IA/operational", "censored"}:
        problems.append("unexpected transition_outcome values")
    censored_bad = df.loc[~df["model_eligible"], "transition_outcome"].ne("censored").sum()
    if censored_bad:
        problems.append(f"{censored_bad} ineligible rows are not censored")

    missing = pd.DataFrame({
        "column": df.columns,
        "missing_n": [int(df[c].isna().sum()) for c in df.columns],
        "missing_pct": [float(df[c].isna().mean()) for c in df.columns],
    })
    forbidden = {"project_id", "transition_outcome", "model_eligible", "audit_wd_date_proxy_flag"}
    deliberately_dropped = {"entity", "fips_code", "duplicate_source_rows", "service", "panel_quarter"}
    high_card = {"poi_name", "county", "developer"}
    statuses = []
    for c in df.columns:
        if c in forbidden:
            statuses.append("target/group/audit only; never a feature")
        elif c == "prop_date":
            statuses.append("sensitivity only; 2025 snapshot")
        elif c in high_card:
            statuses.append("derived count features only; not one-hot")
        elif c in deliberately_dropped:
            statuses.append("not used directly")
        else:
            statuses.append("usable directly or through stated transformation")
    missing["modeling_status"] = statuses
    missing.to_csv(out / "audit_missingness_and_usability.csv", index=False)

    def event_table(group_col: str) -> pd.DataFrame:
        eligible = df[df["model_eligible"]].copy()
        tab = pd.crosstab(eligible[group_col], eligible["transition_outcome"], dropna=False)
        for c in ["stay", "withdraw", "IA/operational"]:
            if c not in tab:
                tab[c] = 0
        tab["rows"] = tab[["stay", "withdraw", "IA/operational"]].sum(axis=1)
        tab["withdraw_rate"] = tab["withdraw"] / tab["rows"]
        tab["ia_rate"] = tab["IA/operational"] / tab["rows"]
        return tab.reset_index()

    by_year = event_table("q_year")
    by_quarter = event_table("panel_quarter")
    by_age = event_table("age_quarters")
    by_year.to_csv(out / "audit_events_by_entry_year.csv", index=False)
    by_quarter.to_csv(out / "audit_events_by_panel_quarter.csv", index=False)
    by_age.to_csv(out / "audit_events_by_age_quarters.csv", index=False)

    # Robust high-count flag plus the required NYISO sensitivity quarters.
    counts = by_quarter.set_index("panel_quarter")["withdraw"].astype(float)
    med = float(counts.median())
    mad = float(np.median(np.abs(counts - med)))
    robust_threshold = med + 6.0 * max(mad, 1.0)
    q3 = float(counts.quantile(0.75))
    iqr_threshold = q3 + 3.0 * float(counts.quantile(0.75) - counts.quantile(0.25))
    threshold = max(20.0, min(robust_threshold, iqr_threshold))
    spike = by_quarter[(by_quarter["withdraw"] >= threshold) |
                       (by_quarter["panel_quarter"].isin(SPIKE_QUARTERS_REQUIRED))].copy()
    spike["flag_reason"] = np.where(
        spike["panel_quarter"].isin(SPIKE_QUARTERS_REQUIRED),
        "NYISO region note; also reviewed statistically", "robust high-count rule")
    spike.to_csv(out / "audit_spike_quarters.csv", index=False)

    outcomes = df["transition_outcome"].value_counts(dropna=False).to_dict()
    result = {
        "rows": int(len(df)),
        "projects": int(df["project_id"].nunique()),
        "eligible_rows": int(df["model_eligible"].sum()),
        "active_projects": int((~df["model_eligible"]).sum()),
        "outcomes": {str(k): int(v) for k, v in outcomes.items()},
        "integrity_failures": len(project_checks),
        "problems": problems,
        "spike_quarters": spike["panel_quarter"].tolist(),
        "service_missing_pct": float(df["service"].isna().mean()),
        "date_range": [str(df["quarter_start"].min().date()), str(df["quarter_start"].max().date())],
        "entry_year_range": [int(df["q_year"].min()), int(df["q_year"].max())],
    }
    (out / "audit_summary.json").write_text(json.dumps(result, indent=2))

    report = f"""# NYISO panel data audit

The file contains **{len(df):,} rows and {df['project_id'].nunique():,} projects**. There are
**{int(df['model_eligible'].sum()):,} model-eligible rows** and **{int((~df['model_eligible']).sum()):,}
currently active projects**. Eligible terminal events comprise **{outcomes.get('withdraw', 0):,}
withdrawals** and **{outcomes.get('IA/operational', 0):,} IA/operational events**.

Integrity checks found **{len(project_checks)} failures**. Every passing project has consecutive
`age_quarters`, no more than one terminal event, and no rows after its terminal event. The audit
found {len(problems)} stop-level issue(s): {', '.join(problems) if problems else 'none'}.

`service` is {df['service'].isna().mean():.1%} missing and is dropped. `prop_date` is reserved for
the leakage sensitivity. POI, county, and developer are not one-hot encoded. They enter only through
time-valid backlog or prior-count features. Static MW, technology, utility, and POI values are
end-of-period snapshots and may differ from their values at queue entry.

The robust spike review flags: **{', '.join(spike['panel_quarter'].tolist()) or 'none'}**. NYISO's
required 2024Q2, 2024Q4, and 2025Q1 sensitivity quarters are retained in the spike list even when a
mechanical threshold would not flag them.
"""
    (out / "data_audit.md").write_text(report)
    return result


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    x["project_mw"] = pd.to_numeric(x["project_mw"], errors="coerce")
    x["mw_ahead"] = pd.to_numeric(x["mw_ahead"], errors="coerce")
    x["log_project_mw"] = np.log1p(x["project_mw"].clip(lower=0))
    x["log_mw_ahead"] = np.log1p(x["mw_ahead"].clip(lower=0))
    x["mw_ahead_per_project_mw"] = (x["mw_ahead"] / x["project_mw"].clip(lower=1e-6)).clip(0, 500)
    x["q_year_centered"] = x["q_year"] - 2015
    x["post_order_2023_entry"] = (x["q_date"] >= ORDER_2023_NYISO_DATE).astype(int)
    x["cluster_process"] = x["cluster"].fillna("").eq("C24").astype(int)
    storage_text = (x["type_clean"].fillna("") + " " + x["type_1"].fillna("") +
                    " " + x["type_2"].fillna("")).str.lower()
    x["hybrid_storage_flag"] = (
        x["type_2"].notna() | storage_text.str.contains("battery|storage", regex=True)
    ).astype(int)

    # Panel membership represents the projects at risk at the start of each quarter.
    # Exclude the focal project so the counts measure other queued projects.
    for loc, prefix in [("poi_name", "poi"), ("county", "county")]:
        key = x[loc].fillna("Missing")
        grp = x.assign(_key=key).groupby(["panel_quarter", "_key"], dropna=False)
        x[f"{prefix}_active_projects"] = grp["project_id"].transform("nunique") - 1
        x[f"{prefix}_active_mw"] = (grp["project_mw"].transform("sum") - x["project_mw"]).clip(lower=0)
        x[f"log_{prefix}_active_mw"] = np.log1p(x[f"{prefix}_active_mw"])

    # Four-quarter regional withdrawal rate, shifted so the current quarter is excluded.
    eligible = x[x["model_eligible"]]
    qstats = eligible.groupby("quarter_start").agg(
        rows=("project_id", "size"),
        withdrawals=("transition_outcome", lambda s: int((s == "withdraw").sum())),
    ).sort_index()
    qstats["withdraw_rate"] = qstats["withdrawals"] / qstats["rows"]
    qstats["lagged_regional_withdraw_rate_4q"] = (
        qstats["withdraw_rate"].shift(1).rolling(4, min_periods=1).mean()
    )
    x["lagged_regional_withdraw_rate_4q"] = x["quarter_start"].map(
        qstats["lagged_regional_withdraw_rate_4q"]
    ).fillna(0.0)

    # Developer prior count is based only on strictly earlier queue-entry dates.
    proj = x.sort_values(["developer", "q_date", "project_id"]).drop_duplicates("project_id")
    proj["developer_key"] = proj["developer"].fillna("Missing")
    proj["developer_prior_project_count"] = (
        proj.groupby("developer_key")["q_date"].rank(method="min").sub(1).astype(float)
    )
    prior_map = proj.set_index("project_id")["developer_prior_project_count"]
    x["developer_prior_project_count"] = x["project_id"].map(prior_map).fillna(0)
    x["log_developer_prior_project_count"] = np.log1p(x["developer_prior_project_count"])

    x["prop_date_gap_quarters"] = (
        (x["prop_date"] - x["quarter_start"]).dt.days / 91.3125
    ).clip(-40, 80)
    x["prop_date_missing"] = x["prop_date"].isna().astype(int)
    x["y"] = x["transition_outcome"].map(OUTCOME_TO_INT)
    return x


def fit_category_maps(train: pd.DataFrame) -> dict[str, set[str]]:
    maps: dict[str, set[str]] = {}
    for col, cutoff in [("type_clean", 0.02), ("utility", 0.01)]:
        s = train[col].fillna("Missing").astype(str)
        freq = s.value_counts(normalize=True)
        maps[col] = set(freq[freq >= cutoff].index)
    return maps


def apply_category_maps(frame: pd.DataFrame, maps: dict[str, set[str]]) -> pd.DataFrame:
    x = frame.copy()
    for col, keep in maps.items():
        s = x[col].fillna("Missing").astype(str)
        x[f"{col}_group"] = np.where(s.isin(keep), s, "Other")
    x["state_group"] = x["state"].fillna("Missing").astype(str)
    return x


BASE_NUMERIC = [
    "log_project_mw", "log_mw_ahead", "mw_ahead_per_project_mw",
    "poi_active_projects", "log_poi_active_mw", "county_active_projects",
    "log_county_active_mw", "lagged_regional_withdraw_rate_4q",
    "q_year_centered", "post_order_2023_entry", "cluster_process",
    "hybrid_storage_flag", "log_developer_prior_project_count",
]
BASE_CATEGORICAL = ["type_clean_group", "utility_group", "state_group"]


def make_preprocessor(include_prop: bool = False) -> ColumnTransformer:
    numeric = BASE_NUMERIC + (["prop_date_gap_quarters", "prop_date_missing"] if include_prop else [])
    return ColumnTransformer(
        transformers=[
            ("age", Pipeline([
                ("impute", SimpleImputer(strategy="median")),
                ("spline", SplineTransformer(n_knots=6, degree=3, include_bias=False,
                                             extrapolation="linear")),
                ("scale", StandardScaler()),
            ]), ["age_quarters"]),
            ("num", Pipeline([
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
            ]), numeric),
            ("cat", Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore", drop="first",
                                         sparse_output=False)),
            ]), BASE_CATEGORICAL),
        ],
        remainder="drop",
        verbose_feature_names_out=True,
    )


def brier_multiclass(y: np.ndarray, p: np.ndarray) -> float:
    truth = np.eye(3)[y.astype(int)]
    return float(np.mean(np.sum((p - truth) ** 2, axis=1)))


def age_naive_fit(train: pd.DataFrame) -> pd.DataFrame:
    bins = [0, 1, 2, 3, 4, 8, 12, 20, np.inf]
    labels = ["1", "2", "3", "4", "5-8", "9-12", "13-20", "21+"]
    ages = pd.cut(train["age_quarters"], bins=bins, labels=labels)
    rows = []
    prior = np.array([1.0, 0.5, 0.5])
    for age, g in train.groupby(ages, observed=False):
        counts = np.bincount(g["y"].astype(int), minlength=3).astype(float) + prior
        rows.append({"age_bin": str(age), **{f"p{k}": counts[k] / counts.sum() for k in range(3)}})
    return pd.DataFrame(rows).set_index("age_bin")


def age_naive_predict(frame: pd.DataFrame, hazards: pd.DataFrame) -> np.ndarray:
    bins = [0, 1, 2, 3, 4, 8, 12, 20, np.inf]
    labels = ["1", "2", "3", "4", "5-8", "9-12", "13-20", "21+"]
    age = pd.cut(frame["age_quarters"], bins=bins, labels=labels).astype(str)
    return np.vstack([hazards.loc[a, ["p0", "p1", "p2"]].to_numpy(float) for a in age])


def tune_logit(train: pd.DataFrame, groups: pd.Series) -> float:
    candidates = [0.03, 0.1, 0.3]
    cv = GroupKFold(n_splits=3)
    scores = []
    for c in candidates:
        fold_scores = []
        for tr, va in cv.split(train, train["y"], groups):
            pre = make_preprocessor(False)
            xtr = pre.fit_transform(train.iloc[tr])
            xva = pre.transform(train.iloc[va])
            model = LogisticRegression(C=c, max_iter=3000, solver="lbfgs", random_state=SEED)
            model.fit(xtr, train.iloc[tr]["y"])
            fold_scores.append(log_loss(train.iloc[va]["y"], model.predict_proba(xva), labels=[0, 1, 2]))
        scores.append(float(np.mean(fold_scores)))
    return candidates[int(np.argmin(scores))]


def class_weights_sqrt(y: pd.Series) -> dict[int, float]:
    counts = y.value_counts().to_dict()
    n = len(y)
    return {k: min(8.0, math.sqrt(n / (3.0 * counts.get(k, 1)))) for k in [0, 1, 2]}


def lgbm_from_params(params: dict[str, Any], weights: dict[int, float]) -> lgb.LGBMClassifier:
    return lgb.LGBMClassifier(
        objective="multiclass", num_class=3, random_state=SEED, n_jobs=4,
        verbosity=-1, class_weight=weights, reg_alpha=1.0, reg_lambda=4.0,
        subsample=0.85, colsample_bytree=0.85, **params,
    )


def tune_lgbm(train: pd.DataFrame, groups: pd.Series) -> dict[str, Any]:
    candidates = [
        {"n_estimators": 180, "learning_rate": 0.035, "num_leaves": 7, "max_depth": 3, "min_child_samples": 80},
        {"n_estimators": 260, "learning_rate": 0.025, "num_leaves": 7, "max_depth": 3, "min_child_samples": 120},
        {"n_estimators": 180, "learning_rate": 0.03, "num_leaves": 11, "max_depth": 4, "min_child_samples": 120},
    ]
    cv = GroupKFold(n_splits=3)
    weights = class_weights_sqrt(train["y"])
    means = []
    for params in candidates:
        fold_scores = []
        for tr, va in cv.split(train, train["y"], groups):
            pre = make_preprocessor(False)
            xtr = pre.fit_transform(train.iloc[tr])
            xva = pre.transform(train.iloc[va])
            model = lgbm_from_params(params, weights)
            model.fit(xtr, train.iloc[tr]["y"])
            fold_scores.append(log_loss(train.iloc[va]["y"], model.predict_proba(xva), labels=[0, 1, 2]))
        means.append(float(np.mean(fold_scores)))
    return candidates[int(np.argmin(means))]


def fit_calibrator_oof(frame: pd.DataFrame, params: dict[str, Any], include_prop: bool,
                       n_splits: int = 3) -> LogisticRegression:
    groups = frame["project_id"]
    splitter = GroupKFold(n_splits=n_splits)
    oof = np.zeros((len(frame), 3))
    weights = class_weights_sqrt(frame["y"])
    for tr, va in splitter.split(frame, frame["y"], groups):
        pre = make_preprocessor(include_prop)
        xtr = pre.fit_transform(frame.iloc[tr])
        xva = pre.transform(frame.iloc[va])
        model = lgbm_from_params(params, weights)
        model.fit(xtr, frame.iloc[tr]["y"])
        oof[va] = np.clip(model.predict_proba(xva), 1e-9, 1.0)
    cal = LogisticRegression(C=1.0, max_iter=2000, solver="lbfgs", random_state=SEED)
    cal.fit(np.log(oof), frame["y"])
    return cal


def fit_models(train: pd.DataFrame, logit_c: float, lgbm_params: dict[str, Any],
               include_prop: bool = False, calibrate_splits: int = 3) -> tuple[FittedModel, FittedModel]:
    pre_logit = make_preprocessor(include_prop)
    xlog = pre_logit.fit_transform(train)
    logit = LogisticRegression(C=logit_c, max_iter=4000, solver="lbfgs", random_state=SEED)
    logit.fit(xlog, train["y"])

    pre_lgb = make_preprocessor(include_prop)
    xlgb = pre_lgb.fit_transform(train)
    weights = class_weights_sqrt(train["y"])
    lgb_model = lgbm_from_params(lgbm_params, weights)
    lgb_model.fit(xlgb, train["y"])
    calibrator = fit_calibrator_oof(train, lgbm_params, include_prop, calibrate_splits)
    return (
        FittedModel(pre_logit, logit, None, "Multinomial logit"),
        FittedModel(pre_lgb, lgb_model, calibrator, "LightGBM calibrated"),
    )


def evaluate_rows(y: pd.Series, predictions: dict[str, np.ndarray]) -> pd.DataFrame:
    rows = []
    for name, p in predictions.items():
        rows.append({
            "model": name,
            "multiclass_log_loss": log_loss(y, p, labels=[0, 1, 2]),
            "multiclass_brier": brier_multiclass(y.to_numpy(int), p),
            "mean_pred_withdraw": float(p[:, 1].mean()),
            "observed_withdraw": float((y == 1).mean()),
            "mean_pred_ia": float(p[:, 2].mean()),
            "observed_ia": float((y == 2).mean()),
        })
    return pd.DataFrame(rows)


def grouped_cv(frame: pd.DataFrame, logit_c: float, lgbm_params: dict[str, Any]) -> pd.DataFrame:
    splitter = GroupKFold(n_splits=5)
    rows = []
    for fold, (tr, va) in enumerate(splitter.split(frame, frame["y"], frame["project_id"]), 1):
        train, valid = frame.iloc[tr], frame.iloc[va]
        logit_fit, lgb_fit = fit_models(train, logit_c, lgbm_params, calibrate_splits=3)
        pred = {logit_fit.name: logit_fit.predict_proba(valid), lgb_fit.name: lgb_fit.predict_proba(valid)}
        fold_metrics = evaluate_rows(valid["y"], pred)
        fold_metrics.insert(0, "fold", fold)
        rows.append(fold_metrics)
    result = pd.concat(rows, ignore_index=True)
    means = result.groupby("model", as_index=False).mean(numeric_only=True)
    means["fold"] = "mean"
    return pd.concat([result, means[result.columns]], ignore_index=True)


def fit_logit_rrr_bootstrap(train: pd.DataFrame, out: Path, logit_c: float,
                            n_bootstrap: int = 80) -> str:
    """Report regularized multinomial RRRs with project-cluster bootstrap CIs.

    Unpenalized MNLogit is singular here because the thin IA class has quasi-separation
    across recent cohorts.  The bootstrap therefore uses the same stable penalized
    multinomial logit as the predictive baseline and resamples whole projects.
    """
    pre = make_preprocessor(False)
    x = pre.fit_transform(train)
    names = ["Intercept"] + pre.get_feature_names_out().tolist()
    y = train["y"].to_numpy(int)
    point = LogisticRegression(C=logit_c, max_iter=4000, solver="lbfgs", random_state=SEED)
    point.fit(x, y)
    point_coef = np.column_stack([point.intercept_, point.coef_])
    point_contrast = np.vstack([point_coef[1] - point_coef[0], point_coef[2] - point_coef[0]])

    group_positions = {
        pid: np.flatnonzero(train["project_id"].to_numpy() == pid)
        for pid in train["project_id"].unique()
    }
    project_ids = np.array(list(group_positions), dtype=object)
    rng = np.random.default_rng(SEED)
    boots = []
    attempts = 0
    while len(boots) < n_bootstrap and attempts < n_bootstrap * 2:
        attempts += 1
        sampled = rng.choice(project_ids, size=len(project_ids), replace=True)
        idx = np.concatenate([group_positions[pid] for pid in sampled])
        if np.unique(y[idx]).size < 3:
            continue
        model = LogisticRegression(C=logit_c, max_iter=2500, solver="lbfgs",
                                   random_state=SEED + attempts)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            model.fit(x[idx], y[idx])
        coef = np.column_stack([model.intercept_, model.coef_])
        boots.append(np.vstack([coef[1] - coef[0], coef[2] - coef[0]]))
    boot = np.stack(boots)
    low = np.quantile(boot, 0.025, axis=0)
    high = np.quantile(boot, 0.975, axis=0)
    rows = []
    for j, event_name in enumerate(["withdraw_vs_stay", "IA_vs_stay"]):
        for k, feature in enumerate(names):
            coef = float(point_contrast[j, k])
            rows.append({
                "contrast": event_name, "feature": feature,
                "coefficient_log_rrr": coef,
                "relative_risk_ratio": float(np.exp(np.clip(coef, -50, 50))),
                "ci95_low": float(np.exp(np.clip(low[j, k], -50, 50))),
                "ci95_high": float(np.exp(np.clip(high[j, k], -50, 50))),
                "method": "L2-regularized multinomial logit; project-cluster bootstrap",
                "bootstrap_replicates": len(boots),
            })
    pd.DataFrame(rows).to_csv(out / "logit_relative_risk_ratios.csv", index=False)
    return f"regularized multinomial RRRs; {len(boots)} project-cluster bootstrap replicates; n={len(train)}"


def project_pure_oot_split(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, int]]:
    cutoff = pd.Timestamp("2022-10-01")
    test_projects = set(frame.loc[frame["quarter_start"] > cutoff, "project_id"])
    train = frame[(frame["quarter_start"] <= cutoff) & (~frame["project_id"].isin(test_projects))].copy()
    test = frame[(frame["quarter_start"] > cutoff) & (frame["project_id"].isin(test_projects))].copy()
    info = {
        "train_rows": len(train), "test_rows": len(test),
        "train_projects": train["project_id"].nunique(), "test_projects": test["project_id"].nunique(),
        "overlap_projects": len(set(train["project_id"]) & set(test["project_id"])),
    }
    return train, test, info


def forecast_cif(model: FittedModel, landmark: pd.DataFrame, horizon: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Forecast with current time-varying queue conditions frozen; age advances."""
    n = len(landmark)
    surv = np.ones(n)
    cif_w = np.zeros(n)
    cif_i = np.zeros(n)
    ia_expected_num = np.zeros(n)
    for t in range(1, horizon + 1):
        future = landmark.copy()
        future["age_quarters"] = landmark["age_quarters"].to_numpy() + t - 1
        p = model.predict_proba(future)
        inc_w = surv * p[:, 1]
        inc_i = surv * p[:, 2]
        cif_w += inc_w
        cif_i += inc_i
        ia_expected_num += t * inc_i
        surv *= p[:, 0]
    return cif_w, cif_i, ia_expected_num


def landmark_evaluation(test: pd.DataFrame, models: list[FittedModel], out: Path) -> pd.DataFrame:
    landmark = test.sort_values(["project_id", "quarter_start"]).groupby("project_id").head(1).copy()
    last_date = test["quarter_start"].max()
    test_terminal = test[test["y"].isin([1, 2])].drop_duplicates("project_id").set_index("project_id")
    rows = []
    calibration_rows = []
    for horizon in [4, 8, 12]:
        horizon_end = landmark["quarter_start"] + pd.offsets.QuarterBegin(startingMonth=1) * horizon
        observed_event = landmark["project_id"].map(test_terminal["y"] if not test_terminal.empty else pd.Series(dtype=float))
        event_date = landmark["project_id"].map(
            test_terminal["quarter_start"] if not test_terminal.empty else pd.Series(dtype="datetime64[ns]")
        )
        evaluable = (horizon_end <= last_date) | (event_date.notna() & (event_date < horizon_end))
        for model in models:
            pw, pi, _ = forecast_cif(model, landmark, horizon)
            for event_code, label, pred in [(1, "withdraw", pw), (2, "IA/operational", pi)]:
                y_h = ((observed_event == event_code) & (event_date < horizon_end)).astype(int)
                mask = evaluable.to_numpy()
                auc = np.nan
                if y_h[mask].nunique() == 2:
                    auc = float(roc_auc_score(y_h[mask], pred[mask]))
                rows.append({
                    "model": model.name, "event": label, "horizon_quarters": horizon,
                    "time_dependent_concordance_auc": auc, "evaluable_projects": int(mask.sum()),
                    "events": int(y_h[mask].sum()),
                })
                cal = pd.DataFrame({"predicted": pred[mask], "observed": y_h[mask].to_numpy()})
                if len(cal) >= 20:
                    cal["decile"] = pd.qcut(cal["predicted"].rank(method="first"), 10,
                                             labels=False, duplicates="drop") + 1
                    agg = cal.groupby("decile", as_index=False).agg(
                        predicted=("predicted", "mean"), observed=("observed", "mean"), n=("observed", "size")
                    )
                    agg["model"] = model.name
                    agg["event"] = label
                    agg["horizon_quarters"] = horizon
                    calibration_rows.append(agg)
    result = pd.DataFrame(rows)
    result.to_csv(out / "horizon_concordance.csv", index=False)
    calibration = pd.concat(calibration_rows, ignore_index=True)
    calibration.to_csv(out / "calibration_by_decile.csv", index=False)
    plot_calibration(calibration, out)
    return result


def plot_calibration(cal: pd.DataFrame, out: Path) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(13, 8), sharex=False, sharey=False)
    for r, event in enumerate(["withdraw", "IA/operational"]):
        for c, h in enumerate([4, 8, 12]):
            ax = axes[r, c]
            sub = cal[(cal["event"] == event) & (cal["horizon_quarters"] == h)]
            for model, g in sub.groupby("model"):
                ax.plot(g["predicted"], g["observed"], marker="o", label=model)
            mx = max(0.02, sub[["predicted", "observed"]].max().max() if len(sub) else 0.1)
            ax.plot([0, mx], [0, mx], color="black", linestyle="--", linewidth=1)
            ax.set_title(f"{event}, {h} quarters")
            ax.set_xlabel("Mean predicted CIF")
            ax.set_ylabel("Observed event fraction")
            ax.grid(alpha=0.25)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2)
    fig.suptitle("Out-of-time horizon calibration by predicted-risk decile")
    fig.tight_layout(rect=[0, 0.05, 1, 0.96])
    fig.savefig(out / "calibration_plot.png", dpi=180)
    plt.close(fig)


def aalen_johansen(projects: pd.DataFrame, max_age: int | None = None) -> pd.DataFrame:
    max_t = int(projects["duration"].max() if max_age is None else max_age)
    survival, cif_w, cif_i = 1.0, 0.0, 0.0
    rows = [{"age_quarters": 0, "survival": survival, "cif_withdraw": 0.0, "cif_ia": 0.0}]
    for t in range(1, max_t + 1):
        risk = int((projects["duration"] >= t).sum())
        if risk == 0:
            break
        d_w = int(((projects["duration"] == t) & (projects["event"] == 1)).sum())
        d_i = int(((projects["duration"] == t) & (projects["event"] == 2)).sum())
        cif_w += survival * d_w / risk
        cif_i += survival * d_i / risk
        survival *= 1 - (d_w + d_i) / risk
        rows.append({"age_quarters": t, "survival": survival,
                     "cif_withdraw": cif_w, "cif_ia": cif_i})
    return pd.DataFrame(rows)


def build_project_outcomes(df: pd.DataFrame) -> pd.DataFrame:
    last = df.sort_values(["project_id", "age_quarters"]).groupby("project_id").tail(1).copy()
    last["duration"] = last["age_quarters"]
    last["event"] = last["transition_outcome"].map({"withdraw": 1, "IA/operational": 2}).fillna(0).astype(int)
    return last[["project_id", "duration", "event", "type_clean"]]


def plot_aj(df: pd.DataFrame, out: Path) -> None:
    projects = build_project_outcomes(df)
    overall = aalen_johansen(projects)
    overall.to_csv(out / "aalen_johansen_overall.csv", index=False)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.step(overall["age_quarters"], overall["cif_withdraw"], where="post", label="Withdrawal")
    ax.step(overall["age_quarters"], overall["cif_ia"], where="post", label="IA/operational")
    ax.set(xlabel="Quarters since queue entry", ylabel="Cumulative incidence",
           title="Nonparametric Aalen–Johansen cumulative incidence")
    ax.grid(alpha=0.25); ax.legend(); fig.tight_layout()
    fig.savefig(out / "cif_overall.png", dpi=180); plt.close(fig)

    top = projects["type_clean"].value_counts().head(6).index.tolist()
    tech_rows = []
    fig, axes = plt.subplots(2, 3, figsize=(14, 8), sharex=True, sharey=True)
    for ax, tech in zip(axes.ravel(), top):
        aj = aalen_johansen(projects[projects["type_clean"] == tech])
        aj["type_clean"] = tech
        tech_rows.append(aj)
        ax.step(aj["age_quarters"], aj["cif_withdraw"], where="post", label="Withdrawal")
        ax.step(aj["age_quarters"], aj["cif_ia"], where="post", label="IA/operational")
        ax.set_title(tech); ax.grid(alpha=0.2)
    axes[0, 0].legend()
    fig.supxlabel("Quarters since queue entry"); fig.supylabel("Cumulative incidence")
    fig.suptitle("Aalen–Johansen cumulative incidence by technology")
    fig.tight_layout(rect=[0.02, 0.02, 1, 0.95])
    fig.savefig(out / "cif_by_technology.png", dpi=180); plt.close(fig)
    pd.concat(tech_rows, ignore_index=True).to_csv(out / "aalen_johansen_by_technology.csv", index=False)


def plot_hazard_by_age(test: pd.DataFrame, predictions: dict[str, np.ndarray], out: Path) -> None:
    rows = []
    temp = test[["age_quarters", "y"]].copy()
    for name, p in predictions.items():
        for event, k in [("withdraw", 1), ("IA/operational", 2)]:
            t = temp.assign(pred=p[:, k], observed=(temp["y"] == k).astype(float))
            agg = t.groupby("age_quarters", as_index=False).agg(
                predicted=("pred", "mean"), observed=("observed", "mean"), rows=("y", "size"))
            agg["model"] = name; agg["event"] = event; rows.append(agg)
    curve = pd.concat(rows, ignore_index=True)
    curve.to_csv(out / "hazard_by_age.csv", index=False)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), sharex=True)
    for ax, event in zip(axes, ["withdraw", "IA/operational"]):
        sub = curve[(curve["event"] == event) & (curve["age_quarters"] <= 40)]
        for model, g in sub.groupby("model"):
            ax.plot(g["age_quarters"], g["predicted"], label=model)
        obs = sub[sub["model"] == list(predictions)[0]]
        ax.scatter(obs["age_quarters"], obs["observed"], s=12, alpha=0.45, label="Observed")
        ax.set_title(event); ax.set_xlabel("Age (quarters)"); ax.set_ylabel("Quarterly hazard")
        ax.grid(alpha=0.25)
    axes[0].legend(); fig.suptitle("Out-of-time quarterly hazard by project age")
    fig.tight_layout(); fig.savefig(out / "hazard_by_age.png", dpi=180); plt.close(fig)


def shap_outputs(model: FittedModel, frame: pd.DataFrame, out: Path) -> None:
    sample = frame.sample(min(2000, len(frame)), random_state=SEED)
    x = model.preprocessor.transform(sample)
    names = model.preprocessor.get_feature_names_out()
    explainer = shap.TreeExplainer(model.model)
    values = explainer.shap_values(x)
    if isinstance(values, list):
        arrays = values
    else:
        arr = np.asarray(values)
        arrays = [arr[:, :, k] for k in range(arr.shape[2])] if arr.ndim == 3 else [arr]
    for k, label in [(1, "withdraw"), (2, "ia")]:
        vals = arrays[k]
        imp = pd.DataFrame({"feature": names, "mean_abs_shap": np.abs(vals).mean(axis=0)})
        imp = imp.sort_values("mean_abs_shap", ascending=False)
        imp.to_csv(out / f"shap_importance_{label}.csv", index=False)
        top = imp.head(18).sort_values("mean_abs_shap")
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.barh(top["feature"].str.replace(r"^[^_]+__", "", regex=True), top["mean_abs_shap"])
        ax.set_xlabel("Mean absolute SHAP value (raw LightGBM score)")
        ax.set_title(f"LightGBM feature importance: {label}")
        fig.tight_layout(); fig.savefig(out / f"shap_summary_{label}.png", dpi=180); plt.close(fig)


def score_active(model: FittedModel, active: pd.DataFrame, out: Path,
                 save: bool = True) -> pd.DataFrame:
    result = active[["project_id", "age_quarters", "q_date", "type_clean", "project_mw",
                     "state", "county", "poi_name", "utility", "developer"]].copy()
    for horizon in [4, 8, 12]:
        pw, pi, _ = forecast_cif(model, active, horizon)
        result[f"p_withdraw_within_{horizon}q"] = pw
        result[f"p_ia_within_{horizon}q"] = pi
    _, pia40, num40 = forecast_cif(model, active, 40)
    result["expected_quarters_to_ia_conditional"] = np.divide(
        num40, pia40, out=np.full_like(num40, np.nan), where=pia40 > 1e-8
    )
    result["ia_expectation_truncation_quarters"] = 40
    result["scoring_assumption"] = "age advances; 2025Q4 queue-condition features frozen"
    if save:
        out.mkdir(parents=True, exist_ok=True)
        result.to_csv(out / "NYISO_active_project_scores.csv", index=False)
    return result


def run_sensitivities(train: pd.DataFrame, test: pd.DataFrame, all_rows: pd.DataFrame,
                      active: pd.DataFrame, logit_c: float, lgb_params: dict[str, Any],
                      base_active_scores: pd.DataFrame, out: Path) -> pd.DataFrame:
    rows = []
    # Snapshot proposed date: predictive gain may indicate temporal leakage.
    prop_logit, prop_lgb = fit_models(train, logit_c, lgb_params, include_prop=True)
    prop_metrics = evaluate_rows(test["y"], {
        prop_logit.name: prop_logit.predict_proba(test), prop_lgb.name: prop_lgb.predict_proba(test)
    })
    for _, r in prop_metrics.iterrows():
        rows.append({"sensitivity": "include_prop_date_2025_snapshot", **r.to_dict()})

    # Withdrawal timing proxy: remove entire proxy-flagged projects from estimation/evaluation.
    proxy_projects = set(all_rows.loc[all_rows["audit_wd_date_proxy_flag"], "project_id"])
    tr2 = train[~train["project_id"].isin(proxy_projects)]
    te2 = test[~test["project_id"].isin(proxy_projects)]
    if tr2["y"].nunique() == 3 and te2["y"].nunique() >= 2:
        prox_logit, prox_lgb = fit_models(tr2, logit_c, lgb_params, include_prop=False)
        prox_metrics = evaluate_rows(te2["y"], {
            prox_logit.name: prox_logit.predict_proba(te2), prox_lgb.name: prox_lgb.predict_proba(te2)
        })
        for _, r in prox_metrics.iterrows():
            rows.append({"sensitivity": "exclude_proxy_withdrawal_projects", **r.to_dict()})

    proj_last = all_rows.sort_values(["project_id", "age_quarters"]).groupby("project_id").tail(1)
    wd = proj_last[proj_last["transition_outcome"] == "withdraw"].copy()
    age_summary = wd.groupby("audit_wd_date_proxy_flag")["age_quarters"].agg(
        projects="size", mean="mean", median="median", q25=lambda s: s.quantile(.25), q75=lambda s: s.quantile(.75)
    ).reset_index()
    age_summary.to_csv(out / "sensitivity_proxy_withdrawal_age_distribution.csv", index=False)

    # Spike sensitivity affects the all-period final model, not the pre-2023 OOT fit.
    no_spike = all_rows[
        (~all_rows["panel_quarter"].isin(SPIKE_QUARTERS_REQUIRED)) & all_rows["y"].notna()
    ].copy()
    _, spike_lgb = fit_models(no_spike, logit_c, lgb_params, include_prop=False, calibrate_splits=5)
    spike_scores = score_active(spike_lgb, active, out, save=False)
    for h in [4, 8, 12]:
        for event in ["withdraw", "ia"]:
            col = f"p_{event}_within_{h}q"
            delta = spike_scores[col].to_numpy() - base_active_scores[col].to_numpy()
            rows.append({
                "sensitivity": "exclude_2024Q2_2024Q4_2025Q1_from_final_training",
                "model": "LightGBM calibrated", "metric": f"active_score_delta_{col}",
                "mean_delta": float(delta.mean()), "mean_absolute_delta": float(np.abs(delta).mean()),
                "max_absolute_delta": float(np.abs(delta).max()),
            })
    return pd.DataFrame(rows)


def write_reports(out: Path, audit: dict[str, Any], split: dict[str, int], metrics: pd.DataFrame,
                  horizon: pd.DataFrame, cv: pd.DataFrame, sensitivity: pd.DataFrame,
                  preferred: str, rrr_status: str, train: pd.DataFrame, test: pd.DataFrame,
                  active_scores: pd.DataFrame) -> None:
    def metric(model: str, col: str) -> float:
        return float(metrics.loc[metrics["model"] == model, col].iloc[0])

    naive_ll = metric("Naive age-only", "multiclass_log_loss")
    logit_ll = metric("Multinomial logit", "multiclass_log_loss")
    lgb_ll = metric("LightGBM calibrated", "multiclass_log_loss")
    logit_br = metric("Multinomial logit", "multiclass_brier")
    lgb_br = metric("LightGBM calibrated", "multiclass_brier")
    ia_events_test = int((test["y"] == 2).sum())
    wd_events_test = int((test["y"] == 1).sum())
    prop = sensitivity[sensitivity["sensitivity"] == "include_prop_date_2025_snapshot"]
    prop_best = float(prop["multiclass_log_loss"].min()) if len(prop) else np.nan
    suspicious = bool(prop_best < min(logit_ll, lgb_ll) * 0.95)
    cv_means = cv[cv["fold"].astype(str) == "mean"]
    cv_lgb = float(cv_means.loc[
        cv_means["model"] == "LightGBM calibrated", "multiclass_log_loss"
    ].iloc[0])
    cv_logit = float(cv_means.loc[
        cv_means["model"] == "Multinomial logit", "multiclass_log_loss"
    ].iloc[0])
    ia_conc = horizon[horizon["event"] == "IA/operational"]["time_dependent_concordance_auc"].mean()
    wd_conc = horizon[horizon["event"] == "withdraw"]["time_dependent_concordance_auc"].mean()

    report = f"""# NYISO discrete-time competing-risks model

## Executive result

The best of the two requested multivariable specifications is **{preferred}**, but it is
**experimental rather than deployment-ready**. On the project-pure 2023–2025
out-of-time test, multinomial log loss was {logit_ll:.4f} for the regularized logit,
{lgb_ll:.4f} for calibrated LightGBM, and {naive_ll:.4f} for the age-only benchmark.
Multiclass Brier scores were {logit_br:.4f} and {lgb_br:.4f}. Lower is better for both metrics.
Neither multivariable model beats the age-only benchmark out of time. The active-project score
file is supplied as requested, but its probabilities should not be used for operational decisions
until recalibrated on newer, cleaner event timing.

The IA result is intrinsically weak: only {audit['outcomes'].get('IA/operational', 0)} IA events
exist in the full file, only {ia_events_test} occur in the OOT test rows, and no post-2020 entry
cohort has an observed IA. Mean horizon concordance was {ia_conc:.3f} for IA and {wd_conc:.3f}
for withdrawal across the reported model/horizon combinations. IA scores should be treated as
rough prioritization, not dependable forecasts.

## Data and validation

- Audit: {audit['rows']:,} rows, {audit['projects']:,} projects, {audit['integrity_failures']}
  integrity failures, and {audit['active_projects']} active projects to score.
- Project-pure OOT split: {split['train_rows']:,} rows / {split['train_projects']:,} training
  projects and {split['test_rows']:,} rows / {split['test_projects']:,} test projects, with
  {split['overlap_projects']} project overlap.
- The time split is stricter than an ordinary row-based cutoff: a project that appears after
  2022Q4 contributes no rows to training.
- Hyperparameters were selected only inside the training-project set with grouped inner CV.
  Five-fold stability CV also keeps every project's rows in one fold.
- Random grouped five-fold log loss is {cv_lgb:.4f} for LightGBM and {cv_logit:.4f} for the logit,
  much better than the out-of-time results. This gap is evidence of calendar/regime shift and
  explains why random CV alone would overstate production reliability.
- The entry-year range is {audit['entry_year_range'][0]}–{audit['entry_year_range'][1]}. Because
  the region notes supplied no narrower entry-year window, no cohort was silently removed.

## Feature and leakage controls

Age uses flexible cubic splines in the logit. Queue backlog features use only panel membership at
the start of the row's quarter. POI/county counts exclude the focal project. Regional withdrawal
rate uses the prior four quarters and is shifted by one quarter. Developer history counts strictly
earlier queue entries. `panel_quarter` is not a predictive fixed effect. The Order 2023 indicator
uses NYISO's requested May 2, 2024 effective date, documented in
[NYISO's April 2024 compliance update](https://www.nyiso.com/documents/20142/43847922/06_Order%20No.%202023_2023-A%20Compliance%20Update_TPAS_20240401_final.pdf/bec463ce-42a9-b67e-8338-b7f9fe3d2075).
`service` is dropped because it is fully missing.

`prop_date` is excluded from the baseline. Its best sensitivity log loss was {prop_best:.4f}; the
improvement is {'large enough to look suspicious' if suspicious else 'not greater than the pre-set 5% suspicious-improvement threshold'}.
The proposal date remains excluded because it is a revisable 2025 snapshot. Static project MW,
technology, utility, and POI are also snapshot fields and may differ from their entry-time values.

The coefficient table reports RRRs and project-cluster bootstrap intervals: {rrr_status}. A
penalized bootstrap is used because the thin IA class creates quasi-separation for unpenalized
MNLogit. These are descriptive associations in a predictive model. They are not causal effects.

## Interpreting congestion and sensitivity

`mw_ahead`, POI counts, and county counts measure **queue backlog**, not physical transmission
congestion. The proxy-withdrawal and spike-quarter runs show how much model fit and active-project
scores move when known timing-quality and administrative-shock concerns are removed. The spike
exclusion does not alter the pre-2023 OOT fit because those quarters occur after its training cutoff;
it is evaluated against the all-period scoring model instead.

## Scoring assumptions

Active-project CIFs advance age while freezing 2025Q4 time-varying queue-condition features. This
is a transparent scenario, not a forecast of future queue composition. Conditional expected time
to IA is truncated at 40 quarters because the data do not support a reliable infinite-horizon tail.
Predictions are probabilities conditional on the supplied snapshot, not causal conclusions or
guarantees of interconnection.
"""
    (out / "NYISO_model_report.md").write_text(report)

    summary = f"""# NYISO queue-outcome model: planner summary

## What the model says

The model estimates each project's quarterly probability of staying in the queue, withdrawing, or
reaching an interconnection agreement/operation. It then combines those quarterly probabilities
into 4-, 8-, and 12-quarter cumulative risks. **{preferred}** is the stronger of the two requested
multivariable models, but the results are experimental.
The leading LightGBM signals are MW already ahead in the queue, entry cohort, flexible project-age
terms, and the lagged regional withdrawal rate. Project size, technology, developer history, and
POI/county queue backlogs add smaller signals. These backlog measures do not measure physical
transmission congestion, and SHAP importance does not establish causal direction.

## Reliability

Out-of-time log loss is {min(logit_ll, lgb_ll):.4f}, versus {naive_ll:.4f} for an age-only benchmark.
Because the benchmark is better, the current probabilities are not ready for operational use.
The test contains {wd_events_test} withdrawals but only {ia_events_test} IA/operational events.
Withdrawal predictions are therefore more useful than IA predictions. IA estimates have wide
uncertainty, especially for recent cohorts: the file contains no observed IA for projects entering
in 2020 or later. Use IA scores for triage and scenario planning, not precise commitment dates.

## Limits and appropriate use

This is a predictive, non-causal model. The source has 686 proxy-filled withdrawal dates, large
administrative withdrawal spikes in 2024Q2, 2024Q4, and 2025Q1, and no entries after October 2024.
Static MW, technology, and POI fields are end-of-period snapshots. Active-project forecasts freeze
current queue conditions while advancing project age, and expected time to IA is capped at a
40-quarter horizon. Refresh and recalibrate the model when newer queue entries, study milestones,
facility-upgrade costs, deposit/security status, and dated study-phase records become available.
"""
    (out / "NYISO_planner_summary.md").write_text(summary)


def main() -> None:
    args = parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    df = load_panel(args.input)
    audit = audit_panel(df, out)
    if audit["problems"]:
        raise SystemExit(f"Audit stopped modeling: {audit['problems']}")

    engineered = add_engineered_features(df)
    eligible = engineered[engineered["model_eligible"] & engineered["y"].notna()].copy()
    train_raw, test_raw, split_info = project_pure_oot_split(eligible)
    maps = fit_category_maps(train_raw)
    train = apply_category_maps(train_raw, maps)
    test = apply_category_maps(test_raw, maps)

    logit_c = tune_logit(train, train["project_id"])
    lgb_params = tune_lgbm(train, train["project_id"])
    logit_fit, lgb_fit = fit_models(train, logit_c, lgb_params)
    naive = age_naive_fit(train)
    pred_test = {
        "Naive age-only": age_naive_predict(test, naive),
        logit_fit.name: logit_fit.predict_proba(test),
        lgb_fit.name: lgb_fit.predict_proba(test),
    }
    metrics = evaluate_rows(test["y"], pred_test)
    metrics.to_csv(out / "out_of_time_metrics.csv", index=False)
    (out / "split_summary.json").write_text(json.dumps(split_info, indent=2))
    (out / "selected_hyperparameters.json").write_text(json.dumps(
        {"logit_C": logit_c, "lightgbm": lgb_params, "seed": SEED}, indent=2))

    rrr_status = fit_logit_rrr_bootstrap(train, out, logit_c)
    cv = grouped_cv(apply_category_maps(eligible, maps), logit_c, lgb_params)
    cv.to_csv(out / "grouped_5fold_cv_metrics.csv", index=False)
    horizon = landmark_evaluation(test, [logit_fit, lgb_fit], out)
    plot_hazard_by_age(test, pred_test, out)
    plot_aj(engineered, out)
    shap_outputs(lgb_fit, test, out)

    # Final models use every eligible project-quarter; category maps are refit without target use.
    final_maps = fit_category_maps(eligible)
    all_mapped = apply_category_maps(eligible, final_maps)
    final_logit, final_lgb = fit_models(all_mapped, logit_c, lgb_params, calibrate_splits=5)
    lgb_material = (
        metrics.loc[metrics["model"] == "LightGBM calibrated", "multiclass_log_loss"].iloc[0]
        < metrics.loc[metrics["model"] == "Multinomial logit", "multiclass_log_loss"].iloc[0] * 0.98
        and metrics.loc[metrics["model"] == "LightGBM calibrated", "multiclass_brier"].iloc[0]
        < metrics.loc[metrics["model"] == "Multinomial logit", "multiclass_brier"].iloc[0] * 0.98
    )
    preferred_fit = final_lgb if lgb_material else final_logit
    preferred_name = preferred_fit.name

    active_raw = engineered[~engineered["model_eligible"]].copy()
    active = apply_category_maps(active_raw, final_maps)
    active_scores = score_active(preferred_fit, active, out)
    sensitivity = run_sensitivities(train, test, apply_category_maps(engineered, final_maps), active,
                                    logit_c, lgb_params, active_scores, out)
    sensitivity.to_csv(out / "sensitivity_results.csv", index=False)

    bundle = {
        "region": "NYISO", "cutoff": "2025-12-31", "seed": SEED,
        "preferred_model_name": preferred_name,
        "preferred_model": {
            "preprocessor": preferred_fit.preprocessor, "model": preferred_fit.model,
            "calibrator": preferred_fit.calibrator, "name": preferred_fit.name,
        },
        "logit_model": {
            "preprocessor": final_logit.preprocessor, "model": final_logit.model,
            "calibrator": final_logit.calibrator, "name": final_logit.name,
        },
        "lightgbm_model": {
            "preprocessor": final_lgb.preprocessor, "model": final_lgb.model,
            "calibrator": final_lgb.calibrator, "name": final_lgb.name,
        },
        "category_maps": final_maps, "feature_assumptions": {
            "post_order_2023_date": str(ORDER_2023_NYISO_DATE.date()),
            "active_forecast": "age advances; queue-condition features frozen",
            "ia_expectation_truncation_quarters": 40,
        },
    }
    joblib.dump(bundle, out / "NYISO_competing_risks_model.joblib", compress=3)

    write_reports(out, audit, split_info, metrics, horizon, cv, sensitivity,
                  preferred_name, rrr_status, train, test, active_scores)
    manifest = {
        "input": str(args.input.resolve()), "output": str(out), "preferred_model": preferred_name,
        "files": sorted(p.name for p in out.iterdir() if p.is_file()),
    }
    (out / "run_manifest.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps({"status": "complete", **manifest}, indent=2))


if __name__ == "__main__":
    main()
