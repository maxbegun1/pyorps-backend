#!/usr/bin/env python3
"""MISO Midpoint Model: original recent-10% separate logistic models.

This Python implementation preserves the original R experiment's structure:
projects are split by the earliest queue-entry date among the most recent 10%
of observed operational dates, then separate ridge-logit models predict
withdrawal, IA, and operational outcomes at project ages 4, 8, and 12 quarters.

Active projects are retained as negatives here to match the original model.
This is the historical midpoint benchmark; it is not the censoring-corrected
12-quarter model.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


LANDMARKS = (4, 8, 12)
OUTCOMES = {
    "withdrawal": "withdrawal_date_lbnl",
    "IA": "ia_date_lbnl",
    "operational": "operational_date",
}
NUMERIC = ["age_quarters", "log_project_mw", "log_mw_ahead", "log_cluster_mw"]
CATEGORICAL = ["state_cat", "type_cat", "service_cat", "cluster_cat"]


def parse_bool(s: pd.Series) -> pd.Series:
    return s.astype("string").str.strip().str.lower().map(
        {"true": True, "false": False, "1": True, "0": False}
    ).fillna(False)


def group_rare(s: pd.Series, minimum: int = 10) -> pd.Series:
    values = s.fillna("Missing").astype(str).str.strip()
    counts = values.value_counts()
    keep = set(counts[counts >= minimum].index)
    return values.where(values.isin(keep), "Other")


def auc_or_nan(y: pd.Series, p: np.ndarray) -> float:
    return float(roc_auc_score(y, p)) if y.nunique() == 2 else np.nan


def make_features(panel: pd.DataFrame) -> pd.DataFrame:
    d = panel.copy()
    for c in ["q_date", "quarter_start", "observation_date", *OUTCOMES.values()]:
        if c in d.columns:
            d[c] = pd.to_datetime(d[c], errors="coerce")
    d["project_mw"] = pd.to_numeric(d["project_mw"], errors="coerce")
    d["mw_ahead"] = pd.to_numeric(d["mw_ahead"], errors="coerce")
    d["cluster"] = d["cluster"].fillna("Missing").astype(str)
    d["cluster_mw"] = d.groupby(["panel_quarter", "cluster"], dropna=False)["project_mw"].transform("sum")
    d["log_project_mw"] = np.log1p(d["project_mw"].clip(lower=0))
    d["log_mw_ahead"] = np.log1p(d["mw_ahead"].clip(lower=0))
    d["log_cluster_mw"] = np.log1p(d["cluster_mw"].clip(lower=0))
    d["state_cat"] = group_rare(d["state"])
    d["type_cat"] = group_rare(d["type_clean"])
    d["service_cat"] = group_rare(d["service"])
    d["cluster_cat"] = group_rare(d["cluster"])
    return d


def make_model() -> Pipeline:
    pre = ColumnTransformer(
        [
            ("numeric", Pipeline([
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
            ]), NUMERIC),
            ("categorical", Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("one_hot", OneHotEncoder(handle_unknown="ignore", min_frequency=10)),
            ]), CATEGORICAL),
        ],
        remainder="drop",
    )
    return Pipeline([
        ("features", pre),
        ("logit", LogisticRegression(C=10.0, penalty="l2", solver="liblinear", max_iter=5000)),
    ])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-panel", type=Path, default=Path("regional_models/MISO/data/MISO_panel_operational_ready.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("regional_models/MISO/miso_midpoint_model/outputs"))
    parser.add_argument("--entry-cutoff", default="2016-05-09", help="Original midpoint queue-entry cutoff")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    panel = pd.read_csv(args.input_panel, low_memory=False)
    if "model_eligible" in panel.columns:
        panel = panel[parse_bool(panel["model_eligible"])].copy()
    panel = make_features(panel)

    projects = panel.sort_values(["project_id", "q_date"]).drop_duplicates("project_id").copy()
    projects["entry_year"] = projects["q_date"].dt.year
    operational_cutoff = projects["operational_date"].dropna().quantile(0.90)
    # The original R experiment produced 2016-05-09 as its midpoint boundary.
    # Keep this fixed so the GitHub reproduction is comparable even when the
    # refreshed repository panel contains newer operational dates.
    entry_cutoff = pd.Timestamp(args.entry_cutoff)
    panel["split"] = np.where(panel["q_date"] < entry_cutoff, "train", "recent_test")

    rows = []
    predictions = []
    for landmark in LANDMARKS:
        train = panel[(panel["age_quarters"] == landmark) & (panel["split"] == "train")].copy()
        test = panel[(panel["age_quarters"] == landmark) & (panel["split"] == "recent_test")].copy()
        for outcome, date_col in OUTCOMES.items():
            train_y = train[date_col].notna().astype(int)
            test_y = test[date_col].notna().astype(int)
            if train_y.nunique() < 2:
                continue
            model = make_model()
            model.fit(train, train_y)
            p = model.predict_proba(test)[:, 1]
            rows.append({
                "model": "MISO Midpoint Model",
                "outcome": outcome,
                "landmark_quarters": landmark,
                "train_rows": len(train),
                "test_rows": len(test),
                "test_events": int(test_y.sum()),
                "test_prevalence": float(test_y.mean()),
                "auc": auc_or_nan(test_y, p),
                "log_loss": float(log_loss(test_y, p, labels=[0, 1])),
                "brier_score": float(brier_score_loss(test_y, p)),
                "mean_predicted": float(p.mean()),
            })
            predictions.append(pd.DataFrame({
                "model": "MISO Midpoint Model",
                "project_id": test["project_id"].to_numpy(),
                "panel_quarter": test["panel_quarter"].to_numpy(),
                "landmark_quarters": landmark,
                "outcome": outcome,
                "observed": test_y.to_numpy(),
                "predicted_probability": p,
            }))

    metrics = pd.DataFrame(rows)
    pred = pd.concat(predictions, ignore_index=True) if predictions else pd.DataFrame()
    metrics.to_csv(args.output_dir / "miso_midpoint_metrics.csv", index=False)
    pred.to_csv(args.output_dir / "miso_midpoint_predictions.csv", index=False)

    if not metrics.empty:
        fig, axes = plt.subplots(1, 3, figsize=(16, 5))
        for ax, metric, title in zip(
            axes,
            ["auc", "log_loss", "brier_score"],
            ["AUC", "Log loss", "Brier score"],
        ):
            for outcome, group in metrics.groupby("outcome"):
                group = group.sort_values("landmark_quarters")
                ax.plot(group["landmark_quarters"], group[metric], marker="o", linewidth=2, label=outcome)
            ax.set_title(title)
            ax.set_xlabel("Project age in queue (quarters)")
            ax.set_xticks(LANDMARKS)
            ax.grid(alpha=0.25)
        axes[0].set_ylabel("Metric")
        axes[0].legend()
        fig.suptitle("MISO Midpoint Model: original recent-10% split", fontsize=15)
        fig.tight_layout()
        fig.savefig(args.output_dir / "miso_midpoint_metrics.png", dpi=220, bbox_inches="tight")
        plt.close(fig)

    audit = {
        "model_name": "MISO Midpoint Model",
        "input_panel": str(args.input_panel),
        "operational_date_90th_percentile": operational_cutoff.strftime("%Y-%m-%d"),
        "queue_entry_cutoff": entry_cutoff.strftime("%Y-%m-%d"),
        "train_projects": int(projects.loc[projects["q_date"] < entry_cutoff, "project_id"].nunique()),
        "recent_test_projects": int(projects.loc[projects["q_date"] >= entry_cutoff, "project_id"].nunique()),
        "landmarks": list(LANDMARKS),
        "outcomes": list(OUTCOMES),
        "note": "This reproduces the original recent-10% ever-outcome benchmark; active projects are retained as negatives by design.",
    }
    pd.Series(audit).to_json(args.output_dir / "miso_midpoint_audit.json", indent=2)
    print(metrics.to_string(index=False))


if __name__ == "__main__":
    main()
