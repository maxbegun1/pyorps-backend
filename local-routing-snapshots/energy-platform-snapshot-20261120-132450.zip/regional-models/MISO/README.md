# MISO discrete-time competing-risks model

This project audits and models the quarterly MISO interconnection queue panel.
It predicts three mutually exclusive outcomes per project-quarter: stay,
withdraw, and IA/operational.  Quarterly hazards are converted into withdrawal
and IA cumulative incidence functions (CIFs).

The model is predictive, not causal. `mw_ahead` and the POI/county active-set
features measure queue backlog, not physical transmission congestion.

## Reproduce the analysis

Use Python 3.12 and install the pinned packages in `requirements.txt`. On macOS,
LightGBM also needs the OpenMP runtime (`brew install libomp`). Then run:

```bash
python audit_miso_panel.py /path/to/MISO_panel_model_ready.csv outputs/audit
python miso_pipeline.py /path/to/MISO_panel_model_ready.csv outputs/model \
  --audit-dir outputs/audit
```

The pipeline will not fit a model unless `audit_summary.json` reports a pass.
The fixed random seed is 20261020.

To rescore a refreshed model-ready panel with the saved production model:

```bash
python score_active.py /path/to/MISO_panel_model_ready.csv \
  outputs/model/MISO_competing_risks_model.joblib refreshed_scores.csv
```

## Major modeling decisions

- The main estimation sample uses `q_year >= 2013`; pre-2013 cohorts are kept
  only for the full-history sensitivity.
- The out-of-time training cutoff is 2022Q4 and the test is 2023Q1-2025Q4.
- Every cross-validation split groups by `project_id`. A second robustness run
  groups projects by parsed DPP cycle.
- Local active-project and active-MW features use the instant immediately before
  each quarter begins. This prevents an event in the target quarter from changing
  its own feature.
- The prior-four-quarter regional withdrawal rate is shifted by one quarter.
- `prop_date` is excluded from the baseline and appears only in its labeled
  snapshot sensitivity.
- No oversampling or class weighting is used because either would distort hazard
  probabilities. LightGBM receives one-parameter temperature calibration from
  project-grouped out-of-fold predictions.
- LightGBM is selected only if it improves both out-of-time log loss and Brier
  score by at least 2%; otherwise the multinomial logit is preferred.
- Future scores increment queue age but freeze current queue-backlog and recent
  withdrawal-rate features because their future values are unknown.
- The expected time to IA is conditional on IA occurring within the 20-quarter
  forecast window.

`audit_miso_panel.py` contains the structural audit. `miso_pipeline.py` contains
feature engineering, validation, model fitting, evaluation, charts, sensitivities,
production scoring, and serialization. `score_active.py` is the reusable scorer,
and `verify_outputs.py` independently checks score bounds, CIF monotonicity,
coefficient intervals, chart dimensions, and saved-model loading.
