#!/usr/bin/env python3
"""Independent sanity checks for the MISO model deliverables."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from PIL import Image


def verify(audit_dir: Path, model_dir: Path) -> dict:
    audit = json.loads((audit_dir / "audit_summary.json").read_text())
    assert audit["audit_passed"] is True

    scores = pd.read_csv(model_dir / "MISO_active_project_scores.csv")
    assert len(scores) == 1257
    assert scores["project_id"].nunique() == 1257
    probability_cols = [c for c in scores if c.startswith("p_")]
    assert np.isfinite(scores[probability_cols].to_numpy()).all()
    assert ((scores[probability_cols] >= 0) & (scores[probability_cols] <= 1)).all().all()
    for event in ["withdraw", "ia"]:
        cols = [f"p_{event}_within_{h}q" for h in [4, 8, 12, 20]]
        assert (np.diff(scores[cols].to_numpy(), axis=1) >= -1e-12).all()
    for horizon in [4, 8, 12, 20]:
        total = scores[f"p_withdraw_within_{horizon}q"] + scores[f"p_ia_within_{horizon}q"]
        assert (total <= 1 + 1e-12).all()
    expected = scores["expected_quarters_to_ia_conditional_within_20q"]
    assert expected.between(1, 20).all()

    metrics = pd.read_csv(model_dir / "out_of_time_quarterly_metrics.csv")
    assert set(metrics["model"]) == {"naive_age", "logit", "lightgbm"}
    assert np.isfinite(metrics.select_dtypes(include="number").to_numpy()).all()
    horizon = pd.read_csv(model_dir / "horizon_metrics.csv")
    assert set(horizon["horizon_quarters"]) == {4, 8, 12}
    assert horizon["time_dependent_c_index"].between(0, 1).all()
    rrr = pd.read_csv(model_dir / "logit_relative_risk_ratios.csv")
    assert set(rrr["outcome_vs_stay"]) == {"withdraw", "IA/operational"}
    assert np.isfinite(rrr[["relative_risk_ratio", "ci_95_low", "ci_95_high"]].to_numpy()).all()
    assert (rrr["ci_95_low"] <= rrr["relative_risk_ratio"]).all()
    assert (rrr["relative_risk_ratio"] <= rrr["ci_95_high"]).all()
    active_sensitivity = pd.read_csv(model_dir / "active_score_sensitivity.csv")
    assert set(active_sensitivity["sensitivity"]) == {
        "main_2013plus_all_available",
        "spike_quarters_excluded_all_available",
        "full_history_all_available",
        "prop_date_snapshot_all_available",
    }
    sensitivity_probability_columns = [
        c
        for c in active_sensitivity.columns
        if (c.startswith("mean_p_") or c.startswith("median_p_")) and not c.endswith("change_vs_main")
    ]
    assert active_sensitivity[sensitivity_probability_columns].apply(
        lambda s: s.between(0, 1).all()
    ).all()

    card = json.loads((model_dir / "model_card.json").read_text())
    assert card["statsmodels_inference"]["converged"] is True
    bundle = joblib.load(model_dir / "MISO_competing_risks_model.joblib")
    assert bundle["chosen_model"] == card["selected_model"]
    assert "model_pipeline" in bundle and "model_temperature" in bundle

    chart_files = sorted((model_dir / "charts").glob("*.png"))
    assert len(chart_files) == 5
    chart_sizes = {}
    for path in chart_files:
        with Image.open(path) as image:
            width, height = image.size
            assert width >= 1000 and height >= 700
            chart_sizes[path.name] = [width, height]

    return {
        "audit_passed": True,
        "active_score_rows": len(scores),
        "score_probability_bounds": "passed",
        "cif_monotonicity": "passed",
        "competing_cif_sum_le_one": "passed",
        "inference_converged": True,
        "active_sensitivity": "passed",
        "saved_model_load": "passed",
        "chart_sizes": chart_sizes,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("audit_dir", type=Path)
    parser.add_argument("model_dir", type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.audit_dir, args.model_dir), indent=2))


if __name__ == "__main__":
    main()
