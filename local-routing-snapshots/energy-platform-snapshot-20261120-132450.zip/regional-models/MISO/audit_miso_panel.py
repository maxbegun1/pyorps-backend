#!/usr/bin/env python3
"""Audit the MISO quarterly person-period panel before modeling.

This script is deliberately separate from model fitting.  It verifies the panel
structure and writes human-readable and machine-readable audit tables so that a
problem in the source cannot silently flow into the model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


EVENTS = {"withdraw", "IA/operational"}
EXPECTED_OUTCOMES = {"stay", "withdraw", "IA/operational", "censored"}
NEVER_FEATURES = {
    "project_id",
    "transition_outcome",
    "model_eligible",
    "audit_wd_date_proxy_flag",
}


def parse_bool(series: pd.Series) -> pd.Series:
    """Parse common CSV boolean representations without treating blanks as False."""
    lookup = {
        "true": True,
        "false": False,
        "1": True,
        "0": False,
        "yes": True,
        "no": False,
    }
    normalized = series.astype("string").str.strip().str.lower()
    parsed = normalized.map(lookup)
    return parsed.astype("boolean")


def quarter_ordinal(series: pd.Series) -> pd.Series:
    """Convert YYYYQn labels to a monotonically increasing integer."""
    extracted = series.astype("string").str.extract(r"^(\d{4})Q([1-4])$")
    year = pd.to_numeric(extracted[0], errors="coerce")
    quarter = pd.to_numeric(extracted[1], errors="coerce")
    return year * 4 + quarter - 1


def robust_z(values: pd.Series) -> pd.Series:
    """Median/MAD z-score, with a standard-deviation fallback when MAD is zero."""
    x = values.astype(float)
    median = x.median()
    mad = (x - median).abs().median()
    if mad > 0:
        return 0.67448975 * (x - median) / mad
    std = x.std(ddof=0)
    return (x - x.mean()) / std if std > 0 else pd.Series(0.0, index=x.index)


def write_csv(table: pd.DataFrame | pd.Series, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(table, pd.Series):
        table = table.rename("count").reset_index()
    table.to_csv(path, index=False)


def audit(input_path: Path, output_dir: Path) -> dict:
    df = pd.read_csv(input_path, low_memory=False)
    original_columns = list(df.columns)

    for col in ["model_eligible", "audit_wd_date_proxy_flag"]:
        df[col] = parse_bool(df[col])
    for col in ["quarter_start", "observation_date", "q_date", "prop_date"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    for col in ["age_quarters", "q_year", "project_mw", "mw_ahead", "duplicate_source_rows"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df["panel_q_ord"] = quarter_ordinal(df["panel_quarter"])
    df["is_event"] = df["transition_outcome"].isin(EVENTS)
    df["is_withdraw"] = df["transition_outcome"].eq("withdraw")
    df["is_ia"] = df["transition_outcome"].eq("IA/operational")

    outcome_counts = (
        df["transition_outcome"]
        .value_counts(dropna=False)
        .rename_axis("transition_outcome")
        .reset_index(name="rows")
    )
    entry_year_events = (
        df.groupby("q_year", dropna=False)
        .agg(
            projects=("project_id", "nunique"),
            rows=("project_id", "size"),
            withdrawals=("is_withdraw", "sum"),
            ia_operational=("is_ia", "sum"),
            censored=("transition_outcome", lambda s: s.eq("censored").sum()),
        )
        .reset_index()
        .sort_values("q_year")
    )
    quarter_events = (
        df.groupby(["panel_q_ord", "panel_quarter"], dropna=False)
        .agg(
            at_risk_rows=("project_id", "size"),
            withdrawals=("is_withdraw", "sum"),
            ia_operational=("is_ia", "sum"),
            total_events=("is_event", "sum"),
        )
        .reset_index()
        .sort_values("panel_q_ord")
    )
    quarter_events["withdraw_rate"] = quarter_events["withdrawals"] / quarter_events["at_risk_rows"]
    quarter_events["ia_rate"] = quarter_events["ia_operational"] / quarter_events["at_risk_rows"]
    quarter_events["event_rate"] = quarter_events["total_events"] / quarter_events["at_risk_rows"]
    for col in ["withdrawals", "ia_operational", "total_events", "withdraw_rate", "ia_rate", "event_rate"]:
        quarter_events[f"robust_z_{col}"] = robust_z(quarter_events[col])

    age_events = (
        df.groupby("age_quarters", dropna=False)
        .agg(
            at_risk_rows=("project_id", "size"),
            withdrawals=("is_withdraw", "sum"),
            ia_operational=("is_ia", "sum"),
            total_events=("is_event", "sum"),
        )
        .reset_index()
        .sort_values("age_quarters")
    )

    # Flag quarters with an extreme event count or event rate.  We retain both
    # diagnostics because a large queue can create a large count without an
    # unusually high project-level hazard.
    spike_cols = [
        "robust_z_withdrawals",
        "robust_z_ia_operational",
        "robust_z_total_events",
        "robust_z_withdraw_rate",
        "robust_z_ia_rate",
        "robust_z_event_rate",
    ]
    quarter_events["spike_flag"] = quarter_events[spike_cols].abs().max(axis=1) >= 3.5
    spikes = quarter_events.loc[
        quarter_events["spike_flag"],
        [
            "panel_quarter",
            "at_risk_rows",
            "withdrawals",
            "ia_operational",
            "total_events",
            "withdraw_rate",
            "ia_rate",
            "event_rate",
            *spike_cols,
        ],
    ].copy()

    missingness = pd.DataFrame(
        {
            "column": original_columns,
            "missing_rows": [df[c].isna().sum() for c in original_columns],
            "missing_pct": [df[c].isna().mean() for c in original_columns],
            "unique_nonmissing": [df[c].nunique(dropna=True) for c in original_columns],
        }
    )

    # Structural checks are performed within project after chronological sorting.
    work = df.sort_values(["project_id", "age_quarters", "panel_q_ord"]).copy()
    project_checks = []
    for project_id, g in work.groupby("project_id", sort=False):
        ages = g["age_quarters"].to_numpy(dtype=float)
        ords = g["panel_q_ord"].to_numpy(dtype=float)
        event_pos = np.flatnonzero(g["is_event"].to_numpy())
        consecutive_age = bool(
            len(ages) > 0
            and np.isfinite(ages).all()
            and ages[0] == 1
            and (len(ages) == 1 or np.all(np.diff(ages) == 1))
        )
        consecutive_calendar = bool(
            len(ords) > 0
            and np.isfinite(ords).all()
            and (len(ords) == 1 or np.all(np.diff(ords) == 1))
        )
        event_count = int(len(event_pos))
        no_rows_after_event = bool(event_count == 0 or event_pos[-1] == len(g) - 1)
        project_checks.append(
            {
                "project_id": project_id,
                "rows": len(g),
                "min_age": np.nanmin(ages) if len(ages) else np.nan,
                "max_age": np.nanmax(ages) if len(ages) else np.nan,
                "consecutive_age_from_one": consecutive_age,
                "consecutive_calendar_quarters": consecutive_calendar,
                "terminal_event_count": event_count,
                "at_most_one_terminal_event": event_count <= 1,
                "no_rows_after_event": no_rows_after_event,
                "final_outcome": g.iloc[-1]["transition_outcome"],
                "final_model_eligible": g.iloc[-1]["model_eligible"],
            }
        )
    project_checks = pd.DataFrame(project_checks)
    project_violations = project_checks.loc[
        ~(
            project_checks["consecutive_age_from_one"]
            & project_checks["consecutive_calendar_quarters"]
            & project_checks["at_most_one_terminal_event"]
            & project_checks["no_rows_after_event"]
        )
    ].copy()

    # Cross-field checks tied to the stated target/sample contract.
    invalid_outcomes = sorted(set(df["transition_outcome"].dropna()) - EXPECTED_OUTCOMES)
    duplicate_project_quarters = int(df.duplicated(["project_id", "panel_quarter"]).sum())
    eligible_censored = int((df["model_eligible"].eq(True) & df["transition_outcome"].eq("censored")).sum())
    ineligible_non_censored = int((df["model_eligible"].eq(False) & ~df["transition_outcome"].eq("censored")).sum())
    nonfinal_ineligible = int(
        work.groupby("project_id", sort=False)["model_eligible"]
        .apply(lambda s: s.iloc[:-1].eq(False).sum() if len(s) > 1 else 0)
        .sum()
    )
    qdate_after_observation = int((df["q_date"] > df["observation_date"]).sum())
    nonpositive_mw = int((df["project_mw"].notna() & (df["project_mw"] <= 0)).sum())
    negative_mw_ahead = int((df["mw_ahead"].notna() & (df["mw_ahead"] < 0)).sum())

    # Usability labels are conservative.  Snapshot fields remain usable only with
    # an explicit caveat; prop_date is excluded from the baseline by instruction.
    usage_rows = []
    for col in original_columns:
        if col in NEVER_FEATURES:
            baseline_use = "never_feature"
        elif col == "prop_date":
            baseline_use = "sensitivity_only_snapshot"
        elif col in {"quarter_start", "observation_date", "q_date", "panel_quarter"}:
            baseline_use = "time_index_or_explanatory_only"
        elif col == "entity":
            baseline_use = "constant_drop"
        elif col == "fips_code":
            baseline_use = "identifier_or_geography_helper"
        elif col in {"poi_name", "county"}:
            baseline_use = "aggregate_or_fold_encoding_only"
        elif col == "developer":
            baseline_use = "unavailable_or_fold_encoding_only"
        else:
            baseline_use = "candidate_feature"
        usage_rows.append({"column": col, "baseline_use": baseline_use})
    feature_usability = pd.DataFrame(usage_rows).merge(missingness, on="column", how="left")

    expected_region_counts = {
        "projects": 5276,
        "eligible_rows": 50954,
        "withdraw_events": 2223,
        "ia_events": 1796,
        "active_projects": 1257,
    }
    actual_region_counts = {
        "rows": int(len(df)),
        "projects": int(df["project_id"].nunique()),
        "eligible_rows": int(df["model_eligible"].eq(True).sum()),
        "ineligible_rows": int(df["model_eligible"].eq(False).sum()),
        "withdraw_events": int(df["is_withdraw"].sum()),
        "ia_events": int(df["is_ia"].sum()),
        "active_projects": int(df.loc[df["model_eligible"].eq(False), "project_id"].nunique()),
        "main_window_projects": int(
            df.loc[(df["q_year"] >= 2013) & df["model_eligible"].eq(True), "project_id"].nunique()
        ),
        "main_window_withdraw_events": int(df.loc[df["q_year"] >= 2013, "is_withdraw"].sum()),
        "main_window_ia_events": int(df.loc[df["q_year"] >= 2013, "is_ia"].sum()),
    }
    count_comparison = pd.DataFrame(
        [
            {
                "metric": key,
                "expected_from_region_notes": expected,
                "actual": actual_region_counts.get(key),
                "matches": actual_region_counts.get(key) == expected,
            }
            for key, expected in expected_region_counts.items()
        ]
    )

    hard_failures = {
        "invalid_outcomes": invalid_outcomes,
        "missing_project_id_rows": int(df["project_id"].isna().sum()),
        "duplicate_project_quarters": duplicate_project_quarters,
        "project_structure_violations": int(len(project_violations)),
        "eligible_censored_rows": eligible_censored,
        "ineligible_non_censored_rows": ineligible_non_censored,
        "nonfinal_ineligible_rows": nonfinal_ineligible,
        "q_date_after_observation_rows": qdate_after_observation,
        "nonpositive_project_mw_rows": nonpositive_mw,
        "negative_mw_ahead_rows": negative_mw_ahead,
        "region_note_count_mismatches": int((~count_comparison["matches"]).sum()),
    }
    passed = all(
        value == 0 or value == []
        for key, value in hard_failures.items()
        if key != "region_note_count_mismatches"
    ) and hard_failures["region_note_count_mismatches"] == 0

    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(outcome_counts, output_dir / "outcome_distribution.csv")
    write_csv(entry_year_events, output_dir / "events_by_entry_year.csv")
    write_csv(quarter_events, output_dir / "events_by_panel_quarter.csv")
    write_csv(age_events, output_dir / "events_by_age_quarters.csv")
    write_csv(missingness, output_dir / "missingness.csv")
    write_csv(feature_usability, output_dir / "feature_usability.csv")
    write_csv(project_violations, output_dir / "project_structure_violations.csv")
    write_csv(spikes, output_dir / "spike_quarters.csv")
    write_csv(count_comparison, output_dir / "region_note_count_comparison.csv")

    summary = {
        "input": str(input_path),
        "actual_counts": actual_region_counts,
        "hard_failures": hard_failures,
        "audit_passed": passed,
        "spike_quarters": spikes["panel_quarter"].tolist(),
        "limitations": [
            "The supplied panel ends at the first terminal event, so it cannot independently count projects that reached IA and later withdrew.",
            "Static project fields are end-of-period snapshots and may differ from their values at queue entry.",
        ],
    }
    (output_dir / "audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    summary = audit(args.input_csv, args.output_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
