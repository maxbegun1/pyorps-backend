#!/usr/bin/env python3
"""End-to-end discrete-time competing-risks modeling for the MISO queue.

The predictive target is the mutually exclusive project-quarter outcome:
0=stay, 1=withdraw, 2=IA/operational.  Quarterly class probabilities are
converted to cumulative incidence functions (CIFs) by multiplying the
survival probability through time.

This is a predictive workflow, not a causal analysis.  Queue-backlog features
measure queue congestion, not physical transmission congestion.
"""

from __future__ import annotations

import argparse
import json
import math
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from lightgbm import LGBMClassifier
from scipy.optimize import minimize_scalar
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, SplineTransformer, StandardScaler


SEED = 20261020
np.random.seed(SEED)

CLASS_NAMES = ["stay", "withdraw", "IA/operational"]
CLASS_TO_INT = {name: i for i, name in enumerate(CLASS_NAMES)}
EVENTS = {"withdraw", "IA/operational"}
FERC_COMPLIANCE_DATE = pd.Timestamp("2024-05-16")


NUMERIC_FEATURES = [
    "age_quarters",
    "log_project_mw",
    "project_mw_missing",
    "log1p_mw_ahead",
    "log1p_mw_ahead_per_mw",
    "hybrid_flag",
    "storage_flag",
    "post_ferc_order_2023",
    "cluster_cycle_year",
    "cluster_cycle_missing",
    "log1p_poi_active_projects_lag1q",
    "log1p_poi_active_mw_lag1q",
    "log1p_county_active_projects_lag1q",
    "log1p_county_active_mw_lag1q",
    "lag4_regional_withdraw_rate",
]

CATEGORICAL_FEATURES = [
    "type_group",
    "service_cat",
    "state_cat",
    "utility_group",
    "cluster_subregion",
    "entry_cohort",
]

PROP_DATE_FEATURES = ["prop_delay_years_snapshot", "prop_year_snapshot", "prop_date_missing"]


@dataclass
class FittedModel:
    name: str
    pipeline: Pipeline
    temperature: float = 1.0


def parse_bool(series: pd.Series) -> pd.Series:
    lookup = {"true": True, "false": False, "1": True, "0": False, "yes": True, "no": False}
    return series.astype("string").str.strip().str.lower().map(lookup).astype("boolean")


def quarter_ordinal(series: pd.Series) -> pd.Series:
    parts = series.astype("string").str.extract(r"^(\d{4})Q([1-4])$")
    return pd.to_numeric(parts[0], errors="coerce") * 4 + pd.to_numeric(parts[1], errors="coerce") - 1


def load_panel(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, low_memory=False)
    for col in ["model_eligible", "audit_wd_date_proxy_flag"]:
        df[col] = parse_bool(df[col])
    for col in ["quarter_start", "observation_date", "q_date", "prop_date"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    for col in ["age_quarters", "q_year", "project_mw", "mw_ahead", "duplicate_source_rows"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["panel_q_ord"] = quarter_ordinal(df["panel_quarter"]).astype("Int64")
    df["target"] = df["transition_outcome"].map(CLASS_TO_INT).astype("Int64")
    return df


def _active_group_snapshot(
    rows: pd.DataFrame,
    projects: pd.DataFrame,
    group_col: str,
    prefix: str,
) -> pd.DataFrame:
    """Count active projects/MW at the start of each row's quarter.

    The requested active-set rule is entry <= as-of and exit > as-of.  We use
    the instant immediately before quarter_start, rather than the event's
    observation_date, so an outcome occurring in the target quarter cannot
    change its own predictor.  This is a one-quarter-start snapshot and is
    consequently safe for prospective scoring.
    """
    out_count = pd.Series(0.0, index=rows.index)
    out_mw = pd.Series(0.0, index=rows.index)
    as_of = rows["quarter_start"].astype("int64").to_numpy() - 1

    for key, row_index in rows.groupby(group_col, sort=False, dropna=False).groups.items():
        project_subset = projects.loc[projects[group_col].eq(key)].copy()
        idx = np.asarray(list(row_index))
        if project_subset.empty:
            continue

        entries = project_subset[["entry_date", "project_mw_filled"]].dropna(subset=["entry_date"])
        entries = entries.sort_values("entry_date")
        entry_times = entries["entry_date"].astype("int64").to_numpy()
        entry_mw_cum = np.r_[0.0, entries["project_mw_filled"].to_numpy().cumsum()]

        exits = project_subset[["exit_date", "project_mw_filled"]].dropna(subset=["exit_date"])
        exits = exits.sort_values("exit_date")
        exit_times = exits["exit_date"].astype("int64").to_numpy()
        exit_mw_cum = np.r_[0.0, exits["project_mw_filled"].to_numpy().cumsum()]

        query = as_of[idx]
        entered_n = np.searchsorted(entry_times, query, side="right")
        exited_n = np.searchsorted(exit_times, query, side="right")
        out_count.iloc[idx] = entered_n - exited_n
        out_mw.iloc[idx] = entry_mw_cum[entered_n] - exit_mw_cum[exited_n]

    return pd.DataFrame(
        {
            f"{prefix}_active_projects_lag1q": out_count.clip(lower=0),
            f"{prefix}_active_mw_lag1q": out_mw.clip(lower=0),
        },
        index=rows.index,
    )


def build_base_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create leakage-controlled features using only data available by each row."""
    d = df.copy().reset_index(drop=True)
    d["poi_key"] = d["poi_name"].fillna("Missing").astype(str)
    d["county_key"] = d["county"].fillna("Missing").astype(str)

    ordered = d.sort_values(["project_id", "age_quarters", "panel_q_ord"])
    first = ordered.groupby("project_id", as_index=False).first()
    event_rows = ordered.loc[ordered["transition_outcome"].isin(EVENTS)]
    exit_dates = event_rows.groupby("project_id")["observation_date"].min()
    projects = first[
        ["project_id", "q_date", "project_mw", "poi_key", "county_key"]
    ].rename(columns={"q_date": "entry_date"})
    projects["exit_date"] = projects["project_id"].map(exit_dates)
    projects["project_mw_filled"] = projects["project_mw"].fillna(0).clip(lower=0)

    poi_stats = _active_group_snapshot(d, projects, "poi_key", "poi")
    county_stats = _active_group_snapshot(d, projects, "county_key", "county")
    d = pd.concat([d, poi_stats, county_stats], axis=1)

    quarter_rates = (
        d.assign(is_withdraw=d["transition_outcome"].eq("withdraw"))
        .groupby("panel_q_ord")
        .agg(rows=("project_id", "size"), withdrawals=("is_withdraw", "sum"))
        .sort_index()
    )
    quarter_rates["withdraw_rate"] = quarter_rates["withdrawals"] / quarter_rates["rows"]
    quarter_rates["lag4_regional_withdraw_rate"] = (
        quarter_rates["withdraw_rate"].shift(1).rolling(4, min_periods=1).mean()
    )
    d["lag4_regional_withdraw_rate"] = d["panel_q_ord"].map(
        quarter_rates["lag4_regional_withdraw_rate"]
    )

    d["project_mw_missing"] = d["project_mw"].isna().astype(int)
    d["log_project_mw"] = np.log1p(d["project_mw"].clip(lower=0))
    d["log1p_mw_ahead"] = np.log1p(d["mw_ahead"].clip(lower=0))
    ratio = d["mw_ahead"] / d["project_mw"].where(d["project_mw"] > 0)
    d["log1p_mw_ahead_per_mw"] = np.log1p(ratio.clip(lower=0))

    for level in ["poi", "county"]:
        d[f"log1p_{level}_active_projects_lag1q"] = np.log1p(
            d[f"{level}_active_projects_lag1q"].clip(lower=0)
        )
        d[f"log1p_{level}_active_mw_lag1q"] = np.log1p(
            d[f"{level}_active_mw_lag1q"].clip(lower=0)
        )

    type_text = (
        d[["type_clean", "type_1", "type_2"]]
        .fillna("")
        .astype(str)
        .agg(" ".join, axis=1)
        .str.lower()
    )
    d["storage_flag"] = type_text.str.contains("battery|storage", regex=True).astype(int)
    d["hybrid_flag"] = (
        d["type_2"].notna() | d["type_clean"].fillna("").astype(str).str.contains("\\+")
    ).astype(int)

    cluster_text = d["cluster"].fillna("").astype(str)
    cycle = pd.to_numeric(cluster_text.str.extract(r"DPP-(\d{4})", expand=False), errors="coerce")
    d["cluster_cycle_year"] = cycle
    d["cluster_cycle_missing"] = cycle.isna().astype(int)
    subregion = cluster_text.str.extract(
        r"\b(Central|South|West|East(?:\s*\([^)]*\))?|North)\b", expand=False
    )
    d["cluster_subregion"] = subregion.fillna("Missing")
    d["cluster_cycle_key"] = np.where(
        cycle.notna(),
        "cycle_" + cycle.astype("Int64").astype(str),
        "project_" + d["project_id"].astype(str),
    )

    d["post_ferc_order_2023"] = (d["observation_date"] >= FERC_COMPLIANCE_DATE).astype(int)
    d["service_cat"] = d["service"].fillna("Missing").astype(str)
    d["state_cat"] = d["state"].fillna("Missing").astype(str)
    d["utility_cat"] = d["utility"].fillna("Missing").astype(str)
    d["entry_cohort"] = pd.cut(
        d["q_year"],
        bins=[-np.inf, 2012, 2015, 2018, 2021, np.inf],
        labels=["pre-2013", "2013-2015", "2016-2018", "2019-2021", "2022+"],
    ).astype(str)

    d["prop_date_missing"] = d["prop_date"].isna().astype(int)
    d["prop_delay_years_snapshot"] = (d["prop_date"] - d["observation_date"]).dt.days / 365.25
    d["prop_year_snapshot"] = d["prop_date"].dt.year
    return d


def fit_level_map(
    reference_rows: pd.DataFrame,
    column: str,
    minimum_project_share: float,
) -> set[str]:
    project_values = (
        reference_rows.sort_values(["project_id", "age_quarters"])
        .drop_duplicates("project_id")[["project_id", column]]
    )
    shares = project_values[column].fillna("Missing").astype(str).value_counts(normalize=True)
    return set(shares.loc[shares >= minimum_project_share].index)


def apply_level_maps(d: pd.DataFrame, type_levels: set[str], utility_levels: set[str]) -> pd.DataFrame:
    out = d.copy()
    type_value = out["type_clean"].fillna("Missing").astype(str)
    utility_value = out["utility_cat"].fillna("Missing").astype(str)
    out["type_group"] = type_value.where(type_value.isin(type_levels), "Other")
    out["utility_group"] = utility_value.where(utility_value.isin(utility_levels), "Other")
    return out


def make_preprocessor(model_kind: str, numeric_features: list[str], categorical_features: list[str]) -> ColumnTransformer:
    numeric_without_age = [c for c in numeric_features if c != "age_quarters"]
    transformers: list[tuple[str, Any, list[str]]] = []
    if model_kind == "logit":
        transformers.append(
            (
                "age",
                Pipeline(
                    [
                        ("impute", SimpleImputer(strategy="median")),
                        ("spline", SplineTransformer(n_knots=5, degree=3, include_bias=False)),
                        ("scale", StandardScaler()),
                    ]
                ),
                ["age_quarters"],
            )
        )
        transformers.append(
            (
                "num",
                Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]),
                numeric_without_age,
            )
        )
    else:
        transformers.append(
            (
                "num",
                Pipeline([("impute", SimpleImputer(strategy="median"))]),
                numeric_features,
            )
        )
    transformers.append(
        (
            "cat",
            Pipeline(
                [
                    ("impute", SimpleImputer(strategy="most_frequent")),
                    (
                        "onehot",
                        OneHotEncoder(handle_unknown="ignore", drop="first", sparse_output=True),
                    ),
                ]
            ),
            categorical_features,
        )
    )
    return ColumnTransformer(transformers, remainder="drop", sparse_threshold=0.3)


def make_pipeline(
    model_kind: str,
    params: dict[str, Any],
    numeric_features: list[str],
    categorical_features: list[str],
) -> Pipeline:
    preprocess = make_preprocessor(model_kind, numeric_features, categorical_features)
    if model_kind == "logit":
        estimator = LogisticRegression(
            C=float(params.get("C", 1.0)),
            solver="lbfgs",
            max_iter=1200,
            random_state=SEED,
        )
    else:
        estimator = LGBMClassifier(
            objective="multiclass",
            num_class=3,
            n_estimators=int(params.get("n_estimators", 350)),
            learning_rate=float(params.get("learning_rate", 0.04)),
            num_leaves=int(params.get("num_leaves", 31)),
            min_child_samples=int(params.get("min_child_samples", 50)),
            subsample=float(params.get("subsample", 0.9)),
            colsample_bytree=float(params.get("colsample_bytree", 0.9)),
            reg_lambda=float(params.get("reg_lambda", 1.0)),
            random_state=SEED,
            n_jobs=-1,
            verbosity=-1,
        )
    return Pipeline([("preprocess", preprocess), ("model", estimator)])


def multiclass_brier(y_true: np.ndarray, probabilities: np.ndarray) -> float:
    truth = np.eye(3)[np.asarray(y_true, dtype=int)]
    return float(np.mean(np.sum((probabilities - truth) ** 2, axis=1)))


def apply_temperature(probabilities: np.ndarray, temperature: float) -> np.ndarray:
    p = np.clip(probabilities, 1e-12, 1.0)
    logits = np.log(p) / max(float(temperature), 1e-6)
    logits -= logits.max(axis=1, keepdims=True)
    exp_logits = np.exp(logits)
    return exp_logits / exp_logits.sum(axis=1, keepdims=True)


def fit_temperature(y_true: np.ndarray, probabilities: np.ndarray) -> float:
    result = minimize_scalar(
        lambda t: log_loss(y_true, apply_temperature(probabilities, float(t)), labels=[0, 1, 2]),
        bounds=(0.35, 4.0),
        method="bounded",
    )
    return float(result.x)


def cross_val_predictions(
    model_kind: str,
    params: dict[str, Any],
    data: pd.DataFrame,
    groups: pd.Series,
    numeric_features: list[str],
    categorical_features: list[str],
    n_splits: int = 3,
) -> tuple[np.ndarray, list[dict[str, float]]]:
    feature_cols = numeric_features + categorical_features
    y = data["target"].astype(int).to_numpy()
    oof = np.zeros((len(data), 3), dtype=float)
    fold_metrics: list[dict[str, float]] = []
    splitter = GroupKFold(n_splits=n_splits)
    for fold, (train_idx, valid_idx) in enumerate(splitter.split(data, y, groups), start=1):
        model = make_pipeline(model_kind, params, numeric_features, categorical_features)
        model.fit(data.iloc[train_idx][feature_cols], y[train_idx])
        pred = model.predict_proba(data.iloc[valid_idx][feature_cols])
        oof[valid_idx] = pred
        fold_metrics.append(
            {
                "fold": fold,
                "log_loss": log_loss(y[valid_idx], pred, labels=[0, 1, 2]),
                "brier": multiclass_brier(y[valid_idx], pred),
            }
        )
    return oof, fold_metrics


def tune_model(
    model_kind: str,
    candidates: list[dict[str, Any]],
    train: pd.DataFrame,
    numeric_features: list[str],
    categorical_features: list[str],
) -> tuple[dict[str, Any], pd.DataFrame]:
    rows: list[dict[str, Any]] = []
    for candidate_id, params in enumerate(candidates, start=1):
        oof, folds = cross_val_predictions(
            model_kind,
            params,
            train,
            train["project_id"],
            numeric_features,
            categorical_features,
            n_splits=3,
        )
        rows.append(
            {
                "model": model_kind,
                "candidate": candidate_id,
                "params": json.dumps(params, sort_keys=True),
                "mean_log_loss": log_loss(train["target"].astype(int), oof, labels=[0, 1, 2]),
                "mean_brier": multiclass_brier(train["target"].astype(int).to_numpy(), oof),
                "fold_log_loss_sd": float(pd.DataFrame(folds)["log_loss"].std(ddof=1)),
            }
        )
    results = pd.DataFrame(rows).sort_values(["mean_log_loss", "mean_brier"])
    best = json.loads(results.iloc[0]["params"])
    return best, results


def fit_calibrated_model(
    model_kind: str,
    params: dict[str, Any],
    train: pd.DataFrame,
    numeric_features: list[str],
    categorical_features: list[str],
    calibrate: bool,
) -> FittedModel:
    feature_cols = numeric_features + categorical_features
    temperature = 1.0
    if calibrate:
        oof, _ = cross_val_predictions(
            model_kind,
            params,
            train,
            train["project_id"],
            numeric_features,
            categorical_features,
            n_splits=3,
        )
        temperature = fit_temperature(train["target"].astype(int).to_numpy(), oof)
    pipeline = make_pipeline(model_kind, params, numeric_features, categorical_features)
    pipeline.fit(train[feature_cols], train["target"].astype(int))
    return FittedModel(model_kind, pipeline, temperature)


def predict_probabilities(model: FittedModel, data: pd.DataFrame, feature_cols: list[str]) -> np.ndarray:
    raw = model.pipeline.predict_proba(data[feature_cols])
    return apply_temperature(raw, model.temperature)


def naive_age_probabilities(train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    """Laplace-smoothed age-specific hazards used as the required naive benchmark."""
    counts = pd.crosstab(train["age_quarters"], train["target"]).reindex(columns=[0, 1, 2], fill_value=0)
    probs = (counts + 0.5).div(counts.sum(axis=1) + 1.5, axis=0)
    overall = (train["target"].value_counts().reindex([0, 1, 2], fill_value=0) + 0.5)
    overall = (overall / overall.sum()).to_numpy()
    max_age = int(probs.index.max())
    rows = []
    for age in test["age_quarters"].astype(int):
        if age in probs.index:
            rows.append(probs.loc[age].to_numpy())
        elif age > max_age:
            rows.append(probs.loc[max_age].to_numpy())
        else:
            rows.append(overall)
    return np.asarray(rows)


def evaluate_quarterly(
    train: pd.DataFrame,
    test: pd.DataFrame,
    models: dict[str, FittedModel],
    feature_cols: list[str],
) -> tuple[pd.DataFrame, dict[str, np.ndarray]]:
    y = test["target"].astype(int).to_numpy()
    predictions: dict[str, np.ndarray] = {"naive_age": naive_age_probabilities(train, test)}
    for name, model in models.items():
        predictions[name] = predict_probabilities(model, test, feature_cols)
    rows = []
    for name, pred in predictions.items():
        rows.append(
            {
                "model": name,
                "rows": len(test),
                "log_loss": log_loss(y, pred, labels=[0, 1, 2]),
                "multiclass_brier": multiclass_brier(y, pred),
                "mean_pred_withdraw": pred[:, 1].mean(),
                "observed_withdraw": (y == 1).mean(),
                "mean_pred_ia": pred[:, 2].mean(),
                "observed_ia": (y == 2).mean(),
            }
        )
    return pd.DataFrame(rows), predictions


def advance_rows(origins: pd.DataFrame, quarter_offset: int) -> pd.DataFrame:
    future = origins.copy()
    future["age_quarters"] = future["age_quarters"] + quarter_offset
    future["observation_date"] = future["observation_date"] + pd.DateOffset(months=3 * quarter_offset)
    future["post_ferc_order_2023"] = (future["observation_date"] >= FERC_COMPLIANCE_DATE).astype(int)
    # Future queue state is unknown.  The backlog, local active-set, and lagged
    # withdrawal-rate features are deliberately frozen at the prediction origin.
    return future


def predict_cif(
    model: FittedModel,
    origins: pd.DataFrame,
    feature_cols: list[str],
    max_horizon: int,
    start_next_quarter: bool,
) -> dict[str, np.ndarray]:
    n = len(origins)
    survival = np.ones(n)
    cif_w = np.zeros(n)
    cif_i = np.zeros(n)
    w_path = np.zeros((n, max_horizon))
    i_path = np.zeros((n, max_horizon))
    ia_mass = np.zeros((n, max_horizon))
    first_offset = 1 if start_next_quarter else 0
    for step in range(max_horizon):
        rows = advance_rows(origins, first_offset + step)
        hazards = predict_probabilities(model, rows, feature_cols)
        inc_w = survival * hazards[:, 1]
        inc_i = survival * hazards[:, 2]
        cif_w += inc_w
        cif_i += inc_i
        survival *= hazards[:, 0]
        w_path[:, step] = cif_w
        i_path[:, step] = cif_i
        ia_mass[:, step] = inc_i
    return {"withdraw": w_path, "ia": i_path, "ia_mass": ia_mass, "survival": survival}


def horizon_origins(data: pd.DataFrame, horizon: int, max_panel_ord: int) -> pd.DataFrame:
    cutoff = max_panel_ord - (horizon - 1)
    eligible = data.loc[
        data["model_eligible"].eq(True)
        & (data["q_year"] >= 2013)
        & (data["panel_q_ord"] >= 2023 * 4)
        & (data["panel_q_ord"] <= cutoff)
    ].sort_values(["project_id", "panel_q_ord"])
    return eligible.drop_duplicates("project_id", keep="first").copy()


def evaluate_horizons(
    data: pd.DataFrame,
    models: dict[str, FittedModel],
    feature_cols: list[str],
    horizons: Iterable[int] = (4, 8, 12),
) -> tuple[pd.DataFrame, pd.DataFrame]:
    terminal = (
        data.sort_values(["project_id", "age_quarters", "panel_q_ord"])
        .groupby("project_id", as_index=False)
        .tail(1)
        .set_index("project_id")[["panel_q_ord", "transition_outcome"]]
        .rename(columns={"panel_q_ord": "terminal_ord", "transition_outcome": "terminal_outcome"})
    )
    max_ord = int(data["panel_q_ord"].max())
    metric_rows: list[dict[str, Any]] = []
    calibration_rows: list[dict[str, Any]] = []
    for horizon in horizons:
        origins = horizon_origins(data, horizon, max_ord).join(terminal, on="project_id")
        end_ord = origins["panel_q_ord"].astype(int) + horizon - 1
        complete = ~(
            origins["terminal_outcome"].eq("censored")
            & (origins["terminal_ord"].astype(int) < end_ord)
        )
        origins = origins.loc[complete].copy()
        for model_name, model in models.items():
            cif = predict_cif(model, origins, feature_cols, horizon, start_next_quarter=False)
            for event_name, event_label, risk_key in [
                ("withdraw", "withdraw", "withdraw"),
                ("IA/operational", "IA/operational", "ia"),
            ]:
                y = (
                    origins["terminal_outcome"].eq(event_label)
                    & (origins["terminal_ord"].astype(int) <= end_ord.loc[origins.index])
                ).astype(int).to_numpy()
                risk = cif[risk_key][:, horizon - 1]
                c_index = float(roc_auc_score(y, risk)) if len(np.unique(y)) == 2 else np.nan
                metric_rows.append(
                    {
                        "model": model_name,
                        "event": event_name,
                        "horizon_quarters": horizon,
                        "projects": len(origins),
                        "events_by_horizon": int(y.sum()),
                        "time_dependent_c_index": c_index,
                        "mean_predicted_cif": float(risk.mean()),
                        "observed_cif": float(y.mean()),
                        "calibration_intercept_error": float(risk.mean() - y.mean()),
                    }
                )
                decile = pd.qcut(pd.Series(risk).rank(method="first"), 10, labels=False) + 1
                cal = pd.DataFrame({"decile": decile, "risk": risk, "observed": y}).groupby("decile")
                for dec, g in cal:
                    calibration_rows.append(
                        {
                            "model": model_name,
                            "event": event_name,
                            "horizon_quarters": horizon,
                            "risk_decile": int(dec),
                            "projects": len(g),
                            "mean_predicted_cif": g["risk"].mean(),
                            "observed_cif": g["observed"].mean(),
                        }
                    )
    return pd.DataFrame(metric_rows), pd.DataFrame(calibration_rows)


def aalen_johansen_curve(projects: pd.DataFrame) -> pd.DataFrame:
    durations = projects["duration"].astype(int).to_numpy()
    outcomes = projects["event"].astype(str).to_numpy()
    survival = 1.0
    cif_w = 0.0
    cif_i = 0.0
    rows = [{"age_quarters": 0, "survival": 1.0, "cif_withdraw": 0.0, "cif_ia": 0.0}]
    for time in np.sort(np.unique(durations)):
        at_risk = int((durations >= time).sum())
        d_w = int(((durations == time) & (outcomes == "withdraw")).sum())
        d_i = int(((durations == time) & (outcomes == "IA/operational")).sum())
        d_all = d_w + d_i
        if at_risk > 0:
            cif_w += survival * d_w / at_risk
            cif_i += survival * d_i / at_risk
            survival *= 1.0 - d_all / at_risk
        rows.append(
            {
                "age_quarters": int(time),
                "survival": survival,
                "cif_withdraw": cif_w,
                "cif_ia": cif_i,
            }
        )
    return pd.DataFrame(rows)


def build_aj_reference(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    final = (
        data.loc[data["q_year"] >= 2013]
        .sort_values(["project_id", "age_quarters"])
        .groupby("project_id", as_index=False)
        .tail(1)
        .rename(columns={"age_quarters": "duration", "transition_outcome": "event"})
    )
    groups = ["Overall"] + final["type_group"].value_counts().head(5).index.tolist()
    curves = []
    horizon_rows = []
    for group in groups:
        subset = final if group == "Overall" else final.loc[final["type_group"].eq(group)]
        curve = aalen_johansen_curve(subset)
        curve["technology"] = group
        curves.append(curve)
        for h in [4, 8, 12, 20]:
            row = curve.loc[curve["age_quarters"] <= h].tail(1).iloc[0]
            horizon_rows.append(
                {
                    "technology": group,
                    "projects": len(subset),
                    "horizon_quarters": h,
                    "aj_cif_withdraw": row["cif_withdraw"],
                    "aj_cif_ia": row["cif_ia"],
                }
            )
    return pd.concat(curves, ignore_index=True), pd.DataFrame(horizon_rows)


def grouped_cv_report(
    model_kind: str,
    params: dict[str, Any],
    train: pd.DataFrame,
    numeric_features: list[str],
    categorical_features: list[str],
    grouping: str,
) -> pd.DataFrame:
    groups = train["project_id"] if grouping == "project" else train["cluster_cycle_key"]
    _, folds = cross_val_predictions(
        model_kind,
        params,
        train,
        groups,
        numeric_features,
        categorical_features,
        n_splits=5,
    )
    result = pd.DataFrame(folds)
    result.insert(0, "grouping", grouping)
    result.insert(0, "model", model_kind)
    return result


def fit_statsmodels_rrr(
    fitted_logit: FittedModel,
    data: pd.DataFrame,
    feature_cols: list[str],
    output_path: Path,
) -> dict[str, Any]:
    """Fit a compact unpenalized inference companion with project-clustered SEs.

    The predictive logit retains the complete feature set.  For interpretable
    confidence intervals, the companion specification omits the highest-cardinality
    utility and cluster-subregion controls, which otherwise create near-separation
    and an ill-conditioned Hessian.  This is explicitly labeled in the output.
    """
    del fitted_logit, feature_cols
    compact_categorical = ["type_group", "service_cat", "entry_cohort"]
    compact_numeric = list(NUMERIC_FEATURES)
    compact_features = compact_numeric + compact_categorical
    preprocess = make_preprocessor("logit", compact_numeric, compact_categorical)
    design = preprocess.fit_transform(data[compact_features])
    if hasattr(design, "toarray"):
        design = design.toarray()
    names = list(preprocess.get_feature_names_out())
    design = np.asarray(design, dtype=float)
    nonconstant = np.nanstd(design, axis=0) > 1e-10
    design = design[:, nonconstant]
    names = [name for name, keep in zip(names, nonconstant) if keep]
    design = sm.add_constant(design, prepend=True)
    names = ["intercept"] + names
    model = sm.MNLogit(data["target"].astype(int).to_numpy(), design)
    fit = model.fit(
        method="lbfgs",
        maxiter=500,
        pgtol=1e-8,
        factr=1e7,
        disp=False,
        cov_type="cluster",
        cov_kwds={"groups": data["project_id"].to_numpy()},
    )
    params = np.asarray(fit.params)
    bse = np.asarray(fit.bse)
    rows = []
    for class_col, outcome in enumerate(["withdraw", "IA/operational"]):
        for i, feature in enumerate(names):
            beta = params[i, class_col]
            se = bse[i, class_col]
            rows.append(
                {
                    "outcome_vs_stay": outcome,
                    "feature": feature,
                    "coefficient": beta,
                    "relative_risk_ratio": math.exp(np.clip(beta, -50, 50)),
                    "ci_95_low": math.exp(np.clip(beta - 1.96 * se, -50, 50)),
                    "ci_95_high": math.exp(np.clip(beta + 1.96 * se, -50, 50)),
                    "standard_error": se,
                    "p_value": float(fit.pvalues[i, class_col]),
                    "scale_note": "numeric terms are per 1 SD; categorical terms are relative to the omitted level",
                    "model_scope": "compact unpenalized companion; project-clustered standard errors; predictive logit uses the full feature set",
                }
            )
    pd.DataFrame(rows).to_csv(output_path, index=False)
    return {"converged": bool(fit.mle_retvals.get("converged", False)), "iterations": fit.mle_retvals.get("iterations")}


def shap_importance(
    lgbm: FittedModel,
    test: pd.DataFrame,
    feature_cols: list[str],
    output_dir: Path,
) -> dict[str, list[str]]:
    sample = test.sample(min(1500, len(test)), random_state=SEED)
    preprocess = lgbm.pipeline.named_steps["preprocess"]
    estimator = lgbm.pipeline.named_steps["model"]
    matrix = preprocess.transform(sample[feature_cols])
    feature_names = np.asarray(preprocess.get_feature_names_out())
    # Native LightGBM contributions are exact TreeSHAP values.  LightGBM may
    # return either a class-major list (for sparse input) or one concatenated
    # dense matrix, depending on its version and matrix type.
    values = estimator.booster_.predict(matrix, pred_contrib=True)
    if isinstance(values, list):
        class_arrays = []
        for class_value in values:
            if hasattr(class_value, "toarray"):
                class_value = class_value.toarray()
            class_arrays.append(np.asarray(class_value)[:, :-1])  # drop expected-value column
    else:
        values = np.asarray(values)
        feature_count = len(feature_names)
        if values.ndim == 2 and values.shape[1] == 3 * (feature_count + 1):
            reshaped = values.reshape(len(sample), 3, feature_count + 1)
            class_arrays = [reshaped[:, i, :-1] for i in range(3)]
        elif values.ndim == 3 and values.shape[1] == 3:
            class_arrays = [values[:, i, :-1] for i in range(3)]
        elif values.ndim == 3 and values.shape[2] == 3:
            class_arrays = [values[:, :-1, i] for i in range(3)]
        else:
            raise ValueError(f"Unexpected native SHAP contribution shape: {values.shape}")
    top_features: dict[str, list[str]] = {}
    for class_idx, label in [(1, "withdraw"), (2, "ia")]:
        mean_abs = np.abs(class_arrays[class_idx]).mean(axis=0)
        importance = pd.DataFrame({"feature": feature_names, "mean_abs_shap": mean_abs}).sort_values(
            "mean_abs_shap", ascending=False
        )
        importance.to_csv(output_dir / f"shap_importance_{label}.csv", index=False)
        top = importance.head(18).sort_values("mean_abs_shap")
        fig, ax = plt.subplots(figsize=(9, 6))
        ax.barh(top["feature"].str.replace(r"^[^_]+__", "", regex=True), top["mean_abs_shap"], color="#2a6f97")
        ax.set_xlabel("Mean absolute SHAP value")
        ax.set_title(f"LightGBM feature importance: {label}")
        fig.tight_layout()
        fig.savefig(output_dir / f"shap_summary_{label}.png", dpi=180)
        plt.close(fig)
        top_features[label] = importance.head(8)["feature"].tolist()
    return top_features


def plot_calibration(calibration: pd.DataFrame, output_path: Path) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(14, 8), sharex=True, sharey=True)
    for row, event in enumerate(["withdraw", "IA/operational"]):
        for col, horizon in enumerate([4, 8, 12]):
            ax = axes[row, col]
            subset = calibration.loc[
                calibration["event"].eq(event) & calibration["horizon_quarters"].eq(horizon)
            ]
            ax.plot([0, 1], [0, 1], color="gray", linestyle="--", linewidth=1)
            for model, marker in [("logit", "o"), ("lightgbm", "s")]:
                g = subset.loc[subset["model"].eq(model)].sort_values("mean_predicted_cif")
                ax.plot(g["mean_predicted_cif"], g["observed_cif"], marker=marker, label=model)
            ax.set_title(f"{event}, {horizon} quarters")
            ax.set_xlabel("Mean predicted CIF")
            ax.set_ylabel("Observed CIF")
            ax.legend(frameon=False)
    fig.suptitle("Out-of-time cumulative-incidence calibration by risk decile")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_aj(curves: pd.DataFrame, output_path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), sharey=True)
    for technology, group in curves.groupby("technology"):
        for ax, column, title in [
            (axes[0], "cif_withdraw", "Withdrawal"),
            (axes[1], "cif_ia", "IA / operational"),
        ]:
            ax.step(group["age_quarters"], group[column], where="post", label=technology)
            ax.set_xlim(0, min(40, curves["age_quarters"].max()))
            ax.set_ylim(0, 1)
            ax.set_xlabel("Quarters since queue entry")
            ax.set_title(title)
    axes[0].set_ylabel("Aalen-Johansen cumulative incidence")
    axes[1].legend(frameon=False, fontsize=8, loc="best")
    fig.suptitle("Nonparametric MISO outcome reference, overall and leading technologies")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def plot_hazard_by_age(
    test: pd.DataFrame,
    predictions: dict[str, np.ndarray],
    output_path: Path,
) -> None:
    work = test[["age_quarters", "target"]].copy()
    work["pred_w_logit"] = predictions["logit"][:, 1]
    work["pred_i_logit"] = predictions["logit"][:, 2]
    work["pred_w_lgbm"] = predictions["lightgbm"][:, 1]
    work["pred_i_lgbm"] = predictions["lightgbm"][:, 2]
    grouped = work.groupby("age_quarters").agg(
        rows=("target", "size"),
        actual_withdraw=("target", lambda s: (s == 1).mean()),
        actual_ia=("target", lambda s: (s == 2).mean()),
        pred_w_logit=("pred_w_logit", "mean"),
        pred_i_logit=("pred_i_logit", "mean"),
        pred_w_lgbm=("pred_w_lgbm", "mean"),
        pred_i_lgbm=("pred_i_lgbm", "mean"),
    )
    grouped = grouped.loc[grouped["rows"] >= 20]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), sharey=True)
    for ax, actual, logit_col, lgbm_col, title in [
        (axes[0], "actual_withdraw", "pred_w_logit", "pred_w_lgbm", "Withdrawal hazard"),
        (axes[1], "actual_ia", "pred_i_logit", "pred_i_lgbm", "IA / operational hazard"),
    ]:
        ax.plot(grouped.index, grouped[actual], color="black", label="Observed", linewidth=2)
        ax.plot(grouped.index, grouped[logit_col], label="Logit")
        ax.plot(grouped.index, grouped[lgbm_col], label="LightGBM")
        ax.set_xlabel("Age (quarters)")
        ax.set_title(title)
        ax.legend(frameon=False)
    axes[0].set_ylabel("Per-quarter probability")
    fig.suptitle("Out-of-time hazards by queue age (ages with at least 20 rows)")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def score_active_projects(
    active_rows: pd.DataFrame,
    model: FittedModel,
    feature_cols: list[str],
) -> pd.DataFrame:
    cif = predict_cif(model, active_rows, feature_cols, max_horizon=20, start_next_quarter=True)
    scores = active_rows[
        ["project_id", "panel_quarter", "age_quarters", "state", "county", "poi_name", "type_clean", "project_mw"]
    ].copy()
    for horizon in [4, 8, 12, 20]:
        scores[f"p_withdraw_within_{horizon}q"] = cif["withdraw"][:, horizon - 1]
        scores[f"p_ia_within_{horizon}q"] = cif["ia"][:, horizon - 1]
    quarter_numbers = np.arange(1, 21)
    ia_probability = cif["ia_mass"].sum(axis=1)
    expected = (cif["ia_mass"] * quarter_numbers).sum(axis=1) / np.where(ia_probability > 0, ia_probability, np.nan)
    scores["expected_quarters_to_ia_conditional_within_20q"] = expected
    scores["ia_probability_mass_used_for_conditional_expectation"] = ia_probability
    return scores


def sensitivity_run(
    name: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    params: dict[str, Any],
    numeric_features: list[str],
    categorical_features: list[str],
) -> dict[str, Any]:
    fitted = fit_calibrated_model(
        "lightgbm", params, train, numeric_features, categorical_features, calibrate=True
    )
    feature_cols = numeric_features + categorical_features
    pred = predict_probabilities(fitted, test, feature_cols)
    y = test["target"].astype(int).to_numpy()
    return {
        "sensitivity": name,
        "training_rows": len(train),
        "training_projects": train["project_id"].nunique(),
        "temperature": fitted.temperature,
        "test_log_loss": log_loss(y, pred, labels=[0, 1, 2]),
        "test_brier": multiclass_brier(y, pred),
        "mean_pred_withdraw": pred[:, 1].mean(),
        "mean_pred_ia": pred[:, 2].mean(),
        "observed_withdraw": (y == 1).mean(),
        "observed_ia": (y == 2).mean(),
    }


def active_score_sensitivity(
    data: pd.DataFrame,
    active: pd.DataFrame,
    main_scores: pd.DataFrame,
    best_logit_params: dict[str, Any],
    spike_quarters: set[str],
) -> pd.DataFrame:
    """Measure how modeling choices move current active-project CIFs."""
    feature_cols = NUMERIC_FEATURES + CATEGORICAL_FEATURES
    scenarios: list[tuple[str, pd.DataFrame, list[str], list[str]]] = [
        (
            "spike_quarters_excluded_all_available",
            data.loc[
                data["model_eligible"].eq(True)
                & (data["q_year"] >= 2013)
                & ~data["panel_quarter"].astype(str).isin(spike_quarters)
            ].copy(),
            NUMERIC_FEATURES,
            CATEGORICAL_FEATURES,
        ),
        (
            "full_history_all_available",
            data.loc[data["model_eligible"].eq(True)].copy(),
            NUMERIC_FEATURES,
            CATEGORICAL_FEATURES,
        ),
        (
            "prop_date_snapshot_all_available",
            data.loc[data["model_eligible"].eq(True) & (data["q_year"] >= 2013)].copy(),
            NUMERIC_FEATURES + PROP_DATE_FEATURES,
            CATEGORICAL_FEATURES,
        ),
    ]

    score_sets: list[tuple[str, pd.DataFrame, int, int]] = [
        (
            "main_2013plus_all_available",
            main_scores,
            int(data.loc[data["model_eligible"].eq(True) & (data["q_year"] >= 2013)].shape[0]),
            int(
                data.loc[data["model_eligible"].eq(True) & (data["q_year"] >= 2013), "project_id"].nunique()
            ),
        )
    ]
    for name, scenario_train, numeric, categorical in scenarios:
        model = fit_calibrated_model(
            "logit",
            best_logit_params,
            scenario_train,
            numeric,
            categorical,
            calibrate=False,
        )
        scenario_features = numeric + categorical
        scored = score_active_projects(active, model, scenario_features)
        score_sets.append((name, scored, len(scenario_train), scenario_train["project_id"].nunique()))

    rows: list[dict[str, Any]] = []
    for name, scored, training_rows, training_projects in score_sets:
        row: dict[str, Any] = {
            "sensitivity": name,
            "training_rows": training_rows,
            "training_projects": training_projects,
            "active_projects": len(scored),
        }
        for horizon in [4, 8, 12]:
            for event in ["withdraw", "ia"]:
                values = scored[f"p_{event}_within_{horizon}q"]
                row[f"mean_p_{event}_{horizon}q"] = values.mean()
                row[f"median_p_{event}_{horizon}q"] = values.median()
        rows.append(row)
    result = pd.DataFrame(rows)
    main = result.loc[result["sensitivity"].eq("main_2013plus_all_available")].iloc[0]
    for horizon in [4, 8, 12]:
        for event in ["withdraw", "ia"]:
            result[f"mean_p_{event}_{horizon}q_change_vs_main"] = (
                result[f"mean_p_{event}_{horizon}q"] - main[f"mean_p_{event}_{horizon}q"]
            )
    return result


def write_summary(
    output_path: Path,
    audit: dict[str, Any],
    quarterly: pd.DataFrame,
    horizons: pd.DataFrame,
    sensitivity: pd.DataFrame,
    active_sensitivity: pd.DataFrame,
    chosen_model: str,
    top_features: dict[str, list[str]],
) -> None:
    friendly_names = {
        "num__cluster_cycle_year": "cluster cycle year",
        "num__log1p_mw_ahead": "queued MW ahead",
        "cat__entry_cohort_2022+": "2022+ entry cohort",
        "num__lag4_regional_withdraw_rate": "prior-four-quarter regional withdrawal rate",
        "num__age_quarters": "queue age",
        "cat__service_cat_Missing": "missing service designation",
        "num__log1p_county_active_projects_lag1q": "lagged county active-project count",
    }
    withdrawal_drivers = [friendly_names.get(x, x) for x in top_features.get("withdraw", [])[:5]]
    ia_drivers = [friendly_names.get(x, x) for x in top_features.get("ia", [])[:5]]
    q = quarterly.set_index("model")
    h = horizons.loc[horizons["model"].eq(chosen_model)]
    c_withdraw = h.loc[(h["event"] == "withdraw") & (h["horizon_quarters"] == 12), "time_dependent_c_index"]
    c_ia = h.loc[(h["event"] == "IA/operational") & (h["horizon_quarters"] == 12), "time_dependent_c_index"]
    prop = sensitivity.loc[sensitivity["sensitivity"].eq("prop_date_snapshot")].iloc[0]
    baseline = sensitivity.loc[sensitivity["sensitivity"].eq("main_window")].iloc[0]
    prop_change = (prop["test_log_loss"] - baseline["test_log_loss"]) / baseline["test_log_loss"]
    suspicious = prop_change < -0.05
    full_history = sensitivity.loc[
        sensitivity["sensitivity"].eq("full_history_pre2013_included")
    ].iloc[0]
    full_history_ia_change = (
        full_history["mean_pred_ia"] - baseline["mean_pred_ia"]
    ) / baseline["mean_pred_ia"]
    active_main = active_sensitivity.loc[
        active_sensitivity["sensitivity"].eq("main_2013plus_all_available")
    ].iloc[0]
    active_no_spikes = active_sensitivity.loc[
        active_sensitivity["sensitivity"].eq("spike_quarters_excluded_all_available")
    ].iloc[0]
    text = f"""# MISO interconnection queue outcome model

## What the model says

The model estimates quarterly probabilities of staying in the queue, withdrawing, or reaching an interconnection agreement/operation. It is predictive, not causal. The selected production model is **{chosen_model}** because the out-of-time comparison {'showed a material improvement over the logit' if chosen_model == 'lightgbm' else 'did not show enough improvement to justify replacing the simpler logit'}. Queue-backlog variables such as `mw_ahead` and POI/county active counts measure **queue congestion**, not physical transmission congestion.

The strongest LightGBM predictors for withdrawal were {', '.join(withdrawal_drivers)}. For IA/operation they were {', '.join(ia_drivers)}. These rankings describe predictive contribution; they do not establish that changing a feature will change an outcome.

## Reliability

The out-of-time test covers 2023Q1-2025Q4. Quarterly log loss was {q.loc[chosen_model, 'log_loss']:.4f} for the selected model versus {q.loc['naive_age', 'log_loss']:.4f} for the age-only benchmark; multiclass Brier score was {q.loc[chosen_model, 'multiclass_brier']:.4f} versus {q.loc['naive_age', 'multiclass_brier']:.4f}. At 12 quarters, fixed-horizon concordance was {float(c_withdraw.iloc[0]) if len(c_withdraw) else float('nan'):.3f} for withdrawal and {float(c_ia.iloc[0]) if len(c_ia) else float('nan'):.3f} for IA. Calibration is shown by decile in the accompanying chart and table.

The active-project point estimates are **not stable enough for high-stakes use**. Refitting through all available 2013+ data produces a mean four-quarter withdrawal CIF of {active_main['mean_p_withdraw_4q']:.1%}; excluding all audit-flagged spike quarters lowers it to {active_no_spikes['mean_p_withdraw_4q']:.1%}. This {active_main['mean_p_withdraw_4q'] - active_no_spikes['mean_p_withdraw_4q']:.1%}-point swing shows that mass administrative withdrawals dominate the live forecast. Use the main scores for stress/triage and the spike-excluded result as a contrasting scenario, not as precise probabilities.

## Important limitations

The main model uses 2013+ entry cohorts because older records have strong survivorship bias. Including full history changed the mean out-of-time IA hazard by {full_history_ia_change:+.1%}; the upward movement is consistent with the old cohorts biasing IA probabilities upward. The proposed online date is excluded from the baseline because it is a 2025 snapshot. Adding it {'improved' if prop_change < 0 else 'worsened'} out-of-time log loss by {abs(prop_change):.1%}; this is {'large enough to treat as suspicious evidence of snapshot leakage' if suspicious else 'not evidence of a performance inflation, but the snapshot field remains excluded'}. Static MW, technology, POI, utility, and related fields are end-of-period snapshots and may not equal their values at entry.

MISO filed its Order 2023 compliance proposal on May 16, 2024. The indicator marks rows on or after that filing date; it is a regime label, not evidence of a causal policy effect or full implementation. The supplied panel stops at the first terminal event, so it cannot independently verify the approximately 850 projects reported to have reached IA and later withdrawn. IA remains the terminal event as instructed.

Future active-project scores freeze today's queue-backlog and recent-withdrawal-rate features because future queue conditions are unknown. The conditional expected time to IA is calculated over a 20-quarter forecast window. Predictions should be refreshed as the queue changes and should support, not replace, planner review.
"""
    output_path.write_text(text, encoding="utf-8")


def run(input_csv: Path, output_dir: Path, audit_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    chart_dir = output_dir / "charts"
    chart_dir.mkdir(exist_ok=True)

    audit_summary = json.loads((audit_dir / "audit_summary.json").read_text(encoding="utf-8"))
    if not audit_summary.get("audit_passed", False):
        raise RuntimeError("Audit did not pass; modeling stopped.")

    raw = load_panel(input_csv)
    data = build_base_features(raw)
    pretrain_reference = data.loc[
        data["model_eligible"].eq(True)
        & (data["q_year"] >= 2013)
        & (data["panel_q_ord"] <= 2022 * 4 + 3)
    ]
    type_levels = fit_level_map(pretrain_reference, "type_clean", 0.02)
    utility_levels = fit_level_map(pretrain_reference, "utility_cat", 0.005)
    data = apply_level_maps(data, type_levels, utility_levels)

    eligible_main = data.loc[data["model_eligible"].eq(True) & (data["q_year"] >= 2013)].copy()
    train = eligible_main.loc[eligible_main["panel_q_ord"] <= 2022 * 4 + 3].copy()
    test = eligible_main.loc[eligible_main["panel_q_ord"] >= 2023 * 4].copy()
    feature_cols = NUMERIC_FEATURES + CATEGORICAL_FEATURES

    logit_candidates = [{"C": 0.1}, {"C": 1.0}, {"C": 5.0}]
    lgbm_candidates = [
        {"n_estimators": 300, "learning_rate": 0.04, "num_leaves": 15, "min_child_samples": 80},
        {"n_estimators": 350, "learning_rate": 0.04, "num_leaves": 31, "min_child_samples": 60},
        {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 45, "min_child_samples": 100},
    ]
    best_logit, logit_tuning = tune_model(
        "logit", logit_candidates, train, NUMERIC_FEATURES, CATEGORICAL_FEATURES
    )
    best_lgbm, lgbm_tuning = tune_model(
        "lightgbm", lgbm_candidates, train, NUMERIC_FEATURES, CATEGORICAL_FEATURES
    )
    pd.concat([logit_tuning, lgbm_tuning], ignore_index=True).to_csv(
        output_dir / "hyperparameter_tuning.csv", index=False
    )

    logit_model = fit_calibrated_model(
        "logit", best_logit, train, NUMERIC_FEATURES, CATEGORICAL_FEATURES, calibrate=False
    )
    lgbm_model = fit_calibrated_model(
        "lightgbm", best_lgbm, train, NUMERIC_FEATURES, CATEGORICAL_FEATURES, calibrate=True
    )
    models = {"logit": logit_model, "lightgbm": lgbm_model}
    quarterly, test_predictions = evaluate_quarterly(train, test, models, feature_cols)
    quarterly.to_csv(output_dir / "out_of_time_quarterly_metrics.csv", index=False)

    logit_row = quarterly.set_index("model").loc["logit"]
    lgbm_row = quarterly.set_index("model").loc["lightgbm"]
    material_lgbm_gain = (
        lgbm_row["log_loss"] <= 0.98 * logit_row["log_loss"]
        and lgbm_row["multiclass_brier"] <= 0.98 * logit_row["multiclass_brier"]
    )
    chosen_model_name = "lightgbm" if material_lgbm_gain else "logit"

    cv_reports = []
    for model_kind, params in [("logit", best_logit), ("lightgbm", best_lgbm)]:
        for grouping in ["project", "cluster_cycle"]:
            cv_reports.append(
                grouped_cv_report(
                    model_kind,
                    params,
                    train,
                    NUMERIC_FEATURES,
                    CATEGORICAL_FEATURES,
                    grouping,
                )
            )
    cv = pd.concat(cv_reports, ignore_index=True)
    cv.to_csv(output_dir / "grouped_cv_metrics.csv", index=False)
    cv_summary = (
        cv.groupby(["model", "grouping"], as_index=False)
        .agg(
            mean_log_loss=("log_loss", "mean"),
            sd_log_loss=("log_loss", "std"),
            mean_brier=("brier", "mean"),
            sd_brier=("brier", "std"),
        )
    )
    cv_summary.to_csv(output_dir / "grouped_cv_summary.csv", index=False)

    horizon_metrics, calibration = evaluate_horizons(data, models, feature_cols)
    horizon_metrics.to_csv(output_dir / "horizon_metrics.csv", index=False)
    calibration.to_csv(output_dir / "calibration_by_decile.csv", index=False)
    plot_calibration(calibration, chart_dir / "calibration_by_decile.png")
    plot_hazard_by_age(test, test_predictions, chart_dir / "hazard_by_age.png")

    aj_curves, aj_horizons = build_aj_reference(data)
    aj_curves.to_csv(output_dir / "aalen_johansen_curves.csv", index=False)
    aj_horizons.to_csv(output_dir / "aalen_johansen_horizons.csv", index=False)
    plot_aj(aj_curves, chart_dir / "aalen_johansen_cif.png")

    top_features = shap_importance(lgbm_model, test, feature_cols, chart_dir)

    spike_quarters = set(pd.read_csv(audit_dir / "spike_quarters.csv")["panel_quarter"].astype(str))
    sensitivity_rows = []
    sensitivity_rows.append(
        sensitivity_run(
            "main_window", train, test, best_lgbm, NUMERIC_FEATURES, CATEGORICAL_FEATURES
        )
    )
    sensitivity_rows.append(
        sensitivity_run(
            "prop_date_snapshot",
            train,
            test,
            best_lgbm,
            NUMERIC_FEATURES + PROP_DATE_FEATURES,
            CATEGORICAL_FEATURES,
        )
    )
    full_history_train = data.loc[
        data["model_eligible"].eq(True) & (data["panel_q_ord"] <= 2022 * 4 + 3)
    ].copy()
    sensitivity_rows.append(
        sensitivity_run(
            "full_history_pre2013_included",
            full_history_train,
            test,
            best_lgbm,
            NUMERIC_FEATURES,
            CATEGORICAL_FEATURES,
        )
    )
    sensitivity_rows.append(
        sensitivity_run(
            "spike_quarters_excluded",
            train.loc[~train["panel_quarter"].astype(str).isin(spike_quarters)].copy(),
            test,
            best_lgbm,
            NUMERIC_FEATURES,
            CATEGORICAL_FEATURES,
        )
    )
    sensitivity = pd.DataFrame(sensitivity_rows)
    main_ll = sensitivity.loc[sensitivity["sensitivity"].eq("main_window"), "test_log_loss"].iloc[0]
    main_ia = sensitivity.loc[sensitivity["sensitivity"].eq("main_window"), "mean_pred_ia"].iloc[0]
    sensitivity["log_loss_change_vs_main"] = sensitivity["test_log_loss"] - main_ll
    sensitivity["mean_ia_probability_change_vs_main"] = sensitivity["mean_pred_ia"] - main_ia
    sensitivity.to_csv(output_dir / "sensitivity_results.csv", index=False)

    # Refit both models to all eligible 2013+ rows after evaluation.  Only this
    # production fit is used to score the 1,257 active projects.
    production_logit = fit_calibrated_model(
        "logit", best_logit, eligible_main, NUMERIC_FEATURES, CATEGORICAL_FEATURES, calibrate=False
    )
    production_lgbm = fit_calibrated_model(
        "lightgbm", best_lgbm, eligible_main, NUMERIC_FEATURES, CATEGORICAL_FEATURES, calibrate=True
    )
    production_models = {"logit": production_logit, "lightgbm": production_lgbm}
    production_model = production_models[chosen_model_name]

    active = data.loc[data["model_eligible"].eq(False)].sort_values("project_id").copy()
    scores = score_active_projects(active, production_model, feature_cols)
    scores.to_csv(output_dir / "MISO_active_project_scores.csv", index=False)
    active_sensitivity = active_score_sensitivity(
        data, active, scores, best_logit, spike_quarters
    )
    active_sensitivity.to_csv(output_dir / "active_score_sensitivity.csv", index=False)

    inference_status: dict[str, Any]
    try:
        inference_status = fit_statsmodels_rrr(
            production_logit,
            eligible_main,
            feature_cols,
            output_dir / "logit_relative_risk_ratios.csv",
        )
    except Exception as exc:
        inference_status = {"converged": False, "error": f"{type(exc).__name__}: {exc}"}
        warnings.warn(f"Statsmodels inference fit failed: {exc}")

    bundle = {
        "model_pipeline": production_model.pipeline,
        "model_temperature": production_model.temperature,
        "model_name": production_model.name,
        "chosen_model": chosen_model_name,
        "numeric_features": NUMERIC_FEATURES,
        "categorical_features": CATEGORICAL_FEATURES,
        "feature_cols": feature_cols,
        "type_levels": sorted(type_levels),
        "utility_levels": sorted(utility_levels),
        "ferc_compliance_date": str(FERC_COMPLIANCE_DATE.date()),
        "training_entry_year_min": 2013,
        "training_cutoff": "2025Q4",
        "random_seed": SEED,
        "future_queue_feature_assumption": "frozen at scoring origin",
        "expected_ia_window_quarters": 20,
    }
    joblib.dump(bundle, output_dir / "MISO_competing_risks_model.joblib")

    model_card = {
        "predictive_not_causal": True,
        "queue_not_transmission_congestion": True,
        "selected_model": chosen_model_name,
        "selection_rule": "LightGBM must improve both out-of-time log loss and Brier score by at least 2%; otherwise choose logit.",
        "pre2023_best_logit_params": best_logit,
        "pre2023_best_lgbm_params": best_lgbm,
        "pre2023_lgbm_temperature": lgbm_model.temperature,
        "production_lgbm_temperature": production_lgbm.temperature,
        "statsmodels_inference": inference_status,
        "active_score_instability": {
            "main_mean_p_withdraw_4q": float(
                active_sensitivity.loc[
                    active_sensitivity["sensitivity"].eq("main_2013plus_all_available"),
                    "mean_p_withdraw_4q",
                ].iloc[0]
            ),
            "spike_excluded_mean_p_withdraw_4q": float(
                active_sensitivity.loc[
                    active_sensitivity["sensitivity"].eq("spike_quarters_excluded_all_available"),
                    "mean_p_withdraw_4q",
                ].iloc[0]
            ),
            "use": "scenario/triage only; not stable enough for high-stakes point prediction",
        },
        "ferc_indicator": {
            "date": "2024-05-16",
            "meaning": "MISO Order 2023 compliance filing deadline/filing date, not full implementation",
            "source": "https://www.ferc.gov/explainer-interconnection-final-rule",
        },
        "later_withdrawal_caveat": "The panel terminates at first IA/withdraw event and cannot independently count IA-first projects that later withdrew.",
    }
    (output_dir / "model_card.json").write_text(json.dumps(model_card, indent=2), encoding="utf-8")
    write_summary(
        output_dir / "MISO_model_summary.md",
        audit_summary,
        quarterly,
        horizon_metrics,
        sensitivity,
        active_sensitivity,
        chosen_model_name,
        top_features,
    )

    run_summary = {
        "selected_model": chosen_model_name,
        "active_projects_scored": len(scores),
        "outputs": str(output_dir),
        "statsmodels_inference": inference_status,
    }
    print(json.dumps(run_summary, indent=2))


def score_from_saved_bundle(input_csv: Path, model_path: Path, output_csv: Path) -> None:
    bundle = joblib.load(model_path)
    raw = load_panel(input_csv)
    data = build_base_features(raw)
    data = apply_level_maps(data, set(bundle["type_levels"]), set(bundle["utility_levels"]))
    active = data.loc[data["model_eligible"].eq(False)].sort_values("project_id")
    model = FittedModel(
        name=bundle["model_name"],
        pipeline=bundle["model_pipeline"],
        temperature=float(bundle["model_temperature"]),
    )
    scores = score_active_projects(active, model, bundle["feature_cols"])
    scores.to_csv(output_csv, index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--audit-dir", type=Path, required=True)
    args = parser.parse_args()
    run(args.input_csv, args.output_dir, args.audit_dir)


if __name__ == "__main__":
    main()
