"""Check the fitted artifacts and report release-blocking failures."""
import json
import argparse
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from train import EVENTS, FEATURES, HORIZONS, load_projects

BASE = Path(__file__).resolve().parent
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('panel', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    bundle = joblib.load(args.output / 'miso_models.joblib')
    data, _ = load_projects(args.panel)
    report = {'projects_checked': len(data), 'release_ready': False, 'horizons': {}}
    for event in EVENTS:
        probabilities = np.column_stack([bundle['models'][f'{event}_{h}y'].predict_proba(data[FEATURES])[:, 1] for h in HORIZONS])
        report['horizons'][event] = {'nonmonotonic_projects': int((np.diff(probabilities, axis=1) < -1e-10).any(axis=1).sum()),
                                     'nonfinite_values': int((~np.isfinite(probabilities)).sum())}
    (args.output / 'release_check.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
