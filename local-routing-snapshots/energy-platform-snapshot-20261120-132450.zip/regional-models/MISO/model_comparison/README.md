# MISO IA and operation: research comparison

Status: **not approved for website prediction**. The three approaches are logistic regression, extra trees, and histogram gradient boosting. They are fitted separately for IA and commercial operation at one, three, and five years. A dated withdrawal before the endpoint counts against that endpoint. Projects without a full horizon, unmatched records, and known outcomes without a usable event date are excluded. The observation is the first project record near queue entry, using project capacity, year, state, technology, and service. Some source attributes are latest snapshots and may not actually have been known at entry.

The selection rule sums the ranks of project-grouped five-fold AUC (higher), log loss and Brier score (lower), with log loss breaking ties. This is necessary because the same candidate does not always lead all three measures. The later-time holdout is not used for selection; training projects are purged if their outcome window extends into the holdout. The production-fit research artifacts refit selected approaches on all mature projects. Random project folds are not a substitute for a temporal test and can be optimistic.

| Endpoint | Years | CV-selected model | CV AUC | CV log loss | CV Brier | Holdout events / projects | Holdout AUC |
|---|---:|---|---:|---:|---:|---:|---:|
| IA | 1 | Gradient boosting | 0.941 | 0.052 | 0.013 | 6 / 719 | 0.459 |
| IA | 3 | Extra trees | 0.830 | 0.377 | 0.125 | 0 / 686 | unavailable |
| IA | 5 | Gradient boosting | 0.396 | 0.705 | 0.256 | 152 / 520 | 0.506 |
| Operation | 1 | Logistic regression | 0.848 | 0.030 | 0.005 | 0 / 721 | unavailable |
| Operation | 3 | Extra trees | 0.827 | 0.168 | 0.044 | 1 / 687 | 0.532 |
| Operation | 5 | Gradient boosting | 0.385 | 0.591 | 0.200 | 23 / 527 | 0.568 |

For both five-year models the training split contained fewer than 70 projects. The AUC for a holdout with zero events is undefined. Results for one-event holdouts are highly unstable. `comparison.csv` contains every approach and metric, including temporal holdout log loss and Brier; `temporal_holdout_predictions.csv` enables independent checks.

The separately fitted horizon models also fail a basic cumulative-probability requirement: among 3,978 projects, the predicted chance falls at a longer horizon for 1,400 IA cases and 2,242 operation cases. `verify.py` records this and sets `release_ready` to false. `score.py` refuses to return a probability curve that fails this check; it does not imply the remaining curves are calibrated or ready for decisions. Retrain a joint competing-risks or survival model, independently validate calibration and time splits, and verify date coverage before integrating scoring into the public website.

## Teammate's operational model

`train_age_dpp_models.py` is a replacement for the missing imported helper, not recovered source. It uses a logistic pipeline and prior-quarter cluster MW; it may not match the author's intended definitions. `teammate_reproduction` contains outputs produced with that replacement and cutoff 2019Q4. These are exploratory only: the original script splits by project entry, yet can train on later project-quarter observations and their later outcomes. Its test also includes repeated project-quarter records. Its AUCs therefore cannot be treated as independent, current model validation. The endpoint is operation, not IA.

## Run

Use Python with pandas, numpy, scikit-learn, joblib, scipy, and matplotlib installed. The supplied artifacts were produced with scikit-learn 1.8.0; loading joblib artifacts across versions is unsupported. Only load model files from trusted sources.

```text
python train.py ../data/MISO_panel_operational_ready.csv outputs
python -m unittest -v test_train.py
python verify.py ../data/MISO_panel_operational_ready.csv outputs
```

Input data cutoff: 2025-12-31. No automatic current-data refresh or hosted inference service is included.
