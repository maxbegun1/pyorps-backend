#!/usr/bin/env python3
"""Train the MISO unconditional operational-probability model.

The model estimates, for each 4-, 12-, and 20-quarter horizon:

    P(operation) = P(resolution) * P(operation | resolution)

Resolution means that a project reaches either verified operation or
withdrawal within the forecast horizon.  The conditional model is trained
only on projects that resolve, while the overall operational probability is
scored for all at-risk projects with complete follow-up.

This is a predictive model, not a causal policy model.  It uses the same
MISO panel and feature-engineering conventions as the other MISO scripts.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss, roc_auc_score

from train_age_dpp_models import (
    add_dynamic_cluster_mw,
    add_location_features,
    make_model,
    parse_bool,
    quarter_ordinal,
)

# One-, three-, and five-year forecast horizons.
HORIZONS = (4, 12, 20)
SEED = 20261020
NUMERIC = [
    "age_quarters",
    "log_project_mw",
    "log_mw_ahead_dynamic",
    "log_cluster_mw_dynamic",
]
CATEGORICAL = [
    "state_cat",
    "county_cat",
    "poi_cat",
    "utility_cat",
    "type_cat",
    "service_cat",
]


def prepare_panel(panel: pd.DataFrame) -> pd.DataFrame:
    """Create leakage-safe model features and terminal outcome fields."""
    required_dates = {"operational_date", "withdrawal_date_lbnl"}
    missing_dates = sorted(required_dates - set(panel.columns))
    if missing_dates:
        raise ValueError(
            "Input panel is missing verified outcome dates: "
            + ", ".join(missing_dates)
            + ". Run build_miso_operational_panel.py first and use its enriched output."
        )
    d = panel.copy()
    d["model_eligible"] = parse_bool(d["model_eligible"])
    d = d[d["model_eligible"]].copy()
    d = add_location_features(d)
    d = add_dynamic_cluster_mw(d)

    d["project_mw"] = pd.to_numeric(d["project_mw"], errors="coerce")
    d["log_project_mw"] = np.log1p(d["project_mw"].clip(lower=0))
    d["log_mw_ahead_dynamic"] = np.log1p(
        pd.to_numeric(d["mw_ahead_dynamic"], errors="coerce").fillna(0).clip(lower=0)
    )
    d["log_cluster_mw_dynamic"] = np.log1p(
        pd.to_numeric(d["cluster_mw_dynamic"], errors="coerce").fillna(0).clip(lower=0)
    )

    d["panel_q_ord"] = quarter_ordinal(d["panel_quarter"])
    d["entry_q_ord"] = quarter_ordinal(
        pd.to_datetime(d["q_date"], errors="coerce").dt.to_period("Q").astype("string")
    )
    d["observation_date"] = pd.to_datetime(d["observation_date"], errors="coerce")
    d["operational_date"] = pd.to_datetime(d["operational_date"], errors="coerce")
    d["withdrawal_date"] = pd.to_datetime(d["withdrawal_date_lbnl"], errors="coerce")
    d["terminal_date"] = d[["operational_date", "withdrawal_date"]].min(axis=1)
    d["terminal_outcome"] = pd.Series(pd.NA, index=d.index, dtype="string")
    operational_first = d["operational_date"].notna() & (
        d["withdrawal_date"].isna()
        | (d["operational_date"] <= d["withdrawal_date"])
    )
    withdrawal_first = d["withdrawal_date"].notna() & ~operational_first
    d.loc[operational_first, "terminal_outcome"] = "operational"
    d.loc[withdrawal_first, "terminal_outcome"] = "withdrawal"
    d["terminal_q_ord"] = quarter_ordinal(
        d["terminal_date"].dt.to_period("Q").astype("string")
    )
    d["offset_quarters"] = d["terminal_q_ord"] - d["panel_q_ord"]

    # Keep only observations before a project's terminal event.
    d = d[d["terminal_date"].isna() | (d["observation_date"] < d["terminal_date"])].copy()
    return d


def build_targets(panel: pd.DataFrame, horizon: int, max_q: int) -> pd.DataFrame:
    """Build resolution and conditional-operation targets for one horizon."""
    d = panel.copy()
    d = d[(d["panel_q_ord"] + horizon <= max_q) | (
        d["offset_quarters"].notna() & d["offset_quarters"].between(1, horizon)
    )].copy()
    d["resolution_target"] = (
        d["terminal_outcome"].isin(["operational", "withdrawal"])
        & d["offset_quarters"].between(1, horizon).fillna(False)
    ).astype(int)
    d["operational_target"] = (
        (d["terminal_outcome"] == "operational")
        & d["offset_quarters"].between(1, horizon).fillna(False)
    ).astype(int)
    return d


def metric(y: pd.Series, p: np.ndarray) -> dict[str, float | int | None]:
    y = pd.Series(y).astype(int)
    result: dict[str, float | int | None] = {
        "rows": int(len(y)),
        "events": int(y.sum()),
        "auc": None,
        "log_loss": None,
    }
    if y.nunique() >= 2:
        result["auc"] = float(roc_auc_score(y, p))
        result["log_loss"] = float(log_loss(y, p, labels=[0, 1]))
    return result


def write_plots(metrics_df: pd.DataFrame, predictions_df: pd.DataFrame, output_dir: Path) -> None:
    """Write AUC-by-horizon and calibration plots after training."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    horizon_labels = {4: "1 year", 12: "3 years", 20: "5 years"}
    metrics_plot = metrics_df[metrics_df["auc"].notna()].copy()
    metrics_plot["horizon_label"] = metrics_plot["horizon_quarters"].map(horizon_labels)

    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    for model_name, group in metrics_plot.groupby("model"):
        group = group.sort_values("horizon_quarters")
        ax.plot(
            group["horizon_quarters"], group["auc"], marker="o", linewidth=2,
            label=model_name,
        )
    ax.axhline(0.5, color="grey", linestyle="--", linewidth=1)
    ax.set_xticks(list(horizon_labels), list(horizon_labels.values()))
    ax.set_ylim(0, 1)
    ax.set_xlabel("Forecast horizon")
    ax.set_ylabel("AUC")
    ax.set_title("MISO unconditional operational model: AUC")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "unconditional_operational_auc.png", dpi=220)
    plt.close(fig)

    calibration_rows = []
    for horizon in HORIZONS:
        sub = predictions_df[predictions_df["horizon_quarters"].eq(horizon)].copy()
        for label, probability, outcome, mask in [
            (
                "Overall operational probability",
                "predicted_overall_operational_probability",
                "observed_operational",
                np.ones(len(sub), dtype=bool),
            ),
            (
                "Operational conditional on resolution",
                "predicted_operational_given_resolution",
                "observed_operational",
                sub["observed_resolution"].eq(1).to_numpy(),
            ),
        ]:
            d = sub.loc[mask, [probability, outcome]].dropna().copy()
            if len(d) < 10:
                continue
            d["bin"] = pd.qcut(d[probability], q=min(10, len(d)), duplicates="drop")
            grouped = d.groupby("bin", observed=False).agg(
                predicted=(probability, "mean"), observed=(outcome, "mean"), n=(outcome, "size")
            ).reset_index(drop=True)
            grouped["model"] = label
            grouped["horizon_quarters"] = horizon
            calibration_rows.append(grouped)

    fig, axes = plt.subplots(1, len(HORIZONS), figsize=(15, 4.8), sharex=True, sharey=True)
    if len(HORIZONS) == 1:
        axes = [axes]
    calibration_df = pd.concat(calibration_rows, ignore_index=True) if calibration_rows else pd.DataFrame()
    calibration_df.to_csv(output_dir / "unconditional_operational_calibration.csv", index=False)
    for ax, horizon in zip(axes, HORIZONS):
        ax.plot([0, 1], [0, 1], color="grey", linestyle="--", linewidth=1)
        if not calibration_df.empty:
            sub = calibration_df[calibration_df["horizon_quarters"].eq(horizon)]
            for model_name, group in sub.groupby("model"):
                ax.plot(group["predicted"], group["observed"], marker="o", linewidth=1.8, label=model_name)
        ax.set_title(horizon_labels[horizon])
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel("Mean predicted probability")
        ax.grid(alpha=0.2)
    axes[0].set_ylabel("Observed rate")
    axes[-1].legend(fontsize=8, loc="upper left")
    fig.suptitle("MISO unconditional operational model: calibration")
    fig.tight_layout()
    fig.savefig(output_dir / "unconditional_operational_calibration.png", dpi=220)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_panel", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--train-cutoff", default="2022Q4")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    panel = prepare_panel(pd.read_csv(args.input_panel, low_memory=False))
    max_q = int(panel["panel_q_ord"].max())
    cutoff_q = int(quarter_ordinal(pd.Series([args.train_cutoff])).iloc[0])
    # Project-level temporal split: no project may appear in both train and test.
    project_entries = panel[["project_id", "entry_q_ord"]].drop_duplicates("project_id")
    train_projects = set(project_entries.loc[project_entries["entry_q_ord"] <= cutoff_q, "project_id"])
    test_projects = set(project_entries.loc[project_entries["entry_q_ord"] > cutoff_q, "project_id"])

    metrics: list[dict] = []
    predictions: list[pd.DataFrame] = []
    models: dict[str, object] = {}

    for horizon in HORIZONS:
        targets = build_targets(panel, horizon, max_q)
        train = targets[targets["project_id"].isin(train_projects)].copy()
        test = targets[targets["project_id"].isin(test_projects)].copy()
        feature_columns = NUMERIC + CATEGORICAL

        resolution_model = make_model(NUMERIC, CATEGORICAL)
        resolution_model.fit(train[feature_columns], train["resolution_target"])
        p_resolve = resolution_model.predict_proba(test[feature_columns])[:, 1]

        train_resolved = train[train["resolution_target"].eq(1)].copy()
        conditional_model = make_model(NUMERIC, CATEGORICAL)
        conditional_model.fit(train_resolved[feature_columns], train_resolved["operational_target"])
        p_conditional = conditional_model.predict_proba(test[feature_columns])[:, 1]
        p_operational = p_resolve * p_conditional

        models[f"resolution_{horizon}q"] = resolution_model
        models[f"operation_given_resolution_{horizon}q"] = conditional_model

        resolution_metrics = metric(test["resolution_target"], p_resolve)
        overall_metrics = metric(test["operational_target"], p_operational)
        for model_name, denominator, values in [
            ("Resolution probability", "All at-risk projects", resolution_metrics),
            ("Overall operational probability", "All at-risk projects", overall_metrics),
        ]:
            metrics.append({
                "model": model_name,
                "denominator": denominator,
                "horizon_quarters": horizon,
                **values,
                "train_rows": len(train),
                "test_projects": int(test["project_id"].nunique()),
            })

        conditional_test = test[test["resolution_target"].eq(1)].copy()
        conditional_idx = conditional_test.index
        conditional_metrics = metric(
            conditional_test["operational_target"],
            p_conditional[test.index.get_indexer(conditional_idx)],
        )
        metrics.append({
            "model": "Operational probability conditional on resolution",
            "denominator": "Resolved projects only",
            "horizon_quarters": horizon,
            **conditional_metrics,
            "train_rows": len(train_resolved),
            "test_projects": int(conditional_test["project_id"].nunique()),
        })

        predictions.append(pd.DataFrame({
            "project_id": test["project_id"].to_numpy(),
            "panel_quarter": test["panel_quarter"].to_numpy(),
            "horizon_quarters": horizon,
            "observed_resolution": test["resolution_target"].to_numpy(),
            "observed_operational": test["operational_target"].to_numpy(),
            "predicted_resolution_probability": p_resolve,
            "predicted_operational_given_resolution": p_conditional,
            "predicted_overall_operational_probability": p_operational,
        }))

    metrics_df = pd.DataFrame(metrics)
    metrics_df.to_csv(args.output_dir / "unconditional_operational_metrics.csv", index=False)
    predictions_df = pd.concat(predictions, ignore_index=True)
    predictions_df.to_csv(
        args.output_dir / "unconditional_operational_predictions.csv", index=False
    )
    write_plots(metrics_df, predictions_df, args.output_dir)
    joblib.dump(models, args.output_dir / "unconditional_operational_models.joblib")

    audit = {
        "train_cutoff": args.train_cutoff,
        "horizons": list(HORIZONS),
        "formula": "P(operation) = P(resolution) * P(operation | resolution)",
        "resolution_definition": "Verified operation or withdrawal within the horizon.",
        "operational_definition": "Verified operational_date from the MISO model-ready panel.",
        "train_projects": len(train_projects),
        "test_projects": len(test_projects),
        "features": feature_columns,
        "predictive_not_causal": True,
    }
    with open(args.output_dir / "unconditional_operational_audit.json", "w") as f:
        json.dump(audit, f, indent=2)

    print(metrics_df.to_string(index=False))


if __name__ == "__main__":
    main()
