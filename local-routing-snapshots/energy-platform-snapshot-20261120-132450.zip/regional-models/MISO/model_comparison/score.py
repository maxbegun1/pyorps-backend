"""Research-only scorer with a fail-closed release check for invalid curves."""
import argparse
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd

from train import EVENTS, FEATURES, HORIZONS


def score(bundle, rows):
    missing = [name for name in FEATURES if name not in rows.columns]
    if missing:
        raise ValueError(f'Missing required fields: {missing}')
    result = {}
    for endpoint in EVENTS:
        try:
            values = np.column_stack([bundle['models'][f'{endpoint}_{year}y'].predict_proba(rows[FEATURES])[:, 1]
                                      for year in HORIZONS])
        except KeyError:
            result[endpoint] = {'available': False, 'reason': 'Model not trained for all horizons.'}
            continue
        valid = np.isfinite(values).all(axis=1) & (values >= 0).all(axis=1) & (values <= 1).all(axis=1)
        valid &= (np.diff(values, axis=1) >= -1e-10).all(axis=1)
        result[endpoint] = [{'available': bool(ok), 'probabilities': dict(zip(map(str, HORIZONS), map(float, row))) if ok else None,
                             'reason': None if ok else 'Horizon probabilities failed consistency checks.'}
                            for row, ok in zip(values, valid)]
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Research scorer; results require independent model validation.')
    parser.add_argument('model', type=Path)
    parser.add_argument('input', type=Path, help='CSV with project_mw, q_year, state, type_clean, service')
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    output = score(joblib.load(args.model), pd.read_csv(args.input))
    args.output.write_text(json.dumps(output, indent=2, allow_nan=False), encoding='utf-8')
