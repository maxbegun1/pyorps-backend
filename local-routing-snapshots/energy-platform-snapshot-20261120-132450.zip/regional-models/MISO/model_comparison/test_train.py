import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd

from train import horizon_data, load_projects


class DatasetTests(unittest.TestCase):
    def test_withdrawal_competes_with_both_outcomes_and_censored_is_excluded(self):
        projects = pd.DataFrame({
            'project_id': ['a', 'b', 'c', 'd'],
            'q_date': pd.to_datetime(['2020-01-01', '2020-01-01', '2020-01-01', '2024-06-01']),
            'ia_date_lbnl': pd.to_datetime(['2020-04-01', '2020-04-01', None, None]),
            'operational_date': pd.to_datetime(['2020-08-01', None, None, None]),
            'withdrawal_date_lbnl': pd.to_datetime([None, '2020-03-01', '2020-05-01', None]),
            '_matched': [True] * 4, '_known_ia_event': [True, True, False, False],
            'lbnl_q_status': ['active'] * 4,
        })
        ia = horizon_data(projects, pd.Timestamp('2024-12-31'), 1, 'agreement')
        self.assertEqual(dict(zip(ia.project_id, ia.target)), {'a': 1, 'b': 0, 'c': 0})
        operation = horizon_data(projects, pd.Timestamp('2024-12-31'), 1, 'operation')
        self.assertEqual(dict(zip(operation.project_id, operation.target)), {'a': 1, 'b': 0, 'c': 0})

    def test_features_come_from_first_observation_not_future_rows(self):
        rows = [dict(project_id='a', panel_quarter='2020Q1', observation_date='2020-01-01',
                     q_date='2020-01-01', model_eligible=True, project_mw=100, q_year=2020,
                     state=None, type_clean='Solar', service=None, ia_date_lbnl=None,
                     operational_date=None, withdrawal_date_lbnl=None, transition_outcome='stay', lbnl_q_status='active', lbnl_match=True),
                dict(project_id='a', panel_quarter='2021Q1', observation_date='2021-01-01',
                     q_date='2020-01-01', model_eligible=True, project_mw=200, q_year=2020,
                     state='WI', type_clean='Wind', service='NRIS', ia_date_lbnl='2021-01-01',
                     operational_date=None, withdrawal_date_lbnl=None, transition_outcome='IA/operational', lbnl_q_status='active', lbnl_match=True)]
        with TemporaryDirectory() as temp:
            path = Path(temp) / 'panel.csv'
            pd.DataFrame(rows).to_csv(path, index=False)
            result, _ = load_projects(path)
        self.assertEqual(result.iloc[0].project_mw, 100)
        self.assertEqual(result.iloc[0].state, 'Missing')
        self.assertEqual(str(result.iloc[0].ia_date_lbnl.date()), '2021-01-01')


if __name__ == '__main__':
    unittest.main()
