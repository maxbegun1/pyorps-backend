"""Replacement helpers for the repository's operational model entry point.

This is a new, documented implementation. It is not a recovered copy of the
teammate's missing code and its forecasts must not be presented as identical.
"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def parse_bool(series):
    return series.astype(str).str.strip().str.lower().isin(['true', '1', 'yes'])


def quarter_ordinal(series):
    parts = series.astype('string').str.extract(r'^(\d{4})Q([1-4])$')
    return pd.to_numeric(parts[0], errors='coerce') * 4 + pd.to_numeric(parts[1], errors='coerce') - 1


def add_location_features(frame):
    data = frame.copy()
    for output, source in [('state_cat', 'state'), ('county_cat', 'county'),
                           ('poi_cat', 'poi_name'), ('utility_cat', 'utility'),
                           ('type_cat', 'type_clean'), ('service_cat', 'service')]:
        data[output] = data[source].fillna('Missing').astype(str)
    return data


def add_dynamic_cluster_mw(frame):
    data = frame.copy()
    data['mw_ahead_dynamic'] = pd.to_numeric(data['mw_ahead'], errors='coerce')
    # Prior-quarter observed panel totals; no future-quarter information.
    # Missing cluster is deliberately not pooled with unrelated projects.
    data['_q'] = quarter_ordinal(data['panel_quarter'])
    data['_mw'] = pd.to_numeric(data['project_mw'], errors='coerce').clip(lower=0)
    available = data.dropna(subset=['cluster', '_q'])
    totals = available.groupby(['cluster', '_q'])['_mw'].sum(min_count=1)
    keys = pd.MultiIndex.from_arrays([data['cluster'], data['_q'] - 1])
    data['cluster_mw_dynamic'] = totals.reindex(keys).to_numpy()
    return data.drop(columns=['_q', '_mw'])


def make_model(numeric, categorical):
    numeric_pipeline = Pipeline([('impute', SimpleImputer(strategy='median', keep_empty_features=True)),
                                 ('scale', StandardScaler())])
    categorical_pipeline = Pipeline([('impute', SimpleImputer(strategy='most_frequent', keep_empty_features=True)),
                                     ('encode', OneHotEncoder(handle_unknown='ignore'))])
    preprocessor = ColumnTransformer([('num', numeric_pipeline, numeric),
                                      ('cat', categorical_pipeline, categorical)])
    return Pipeline([('preprocess', preprocessor),
                     ('model', LogisticRegression(max_iter=1000, random_state=20261111))])
