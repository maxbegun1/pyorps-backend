"""Compare entry-time MISO IA and operation models, using mature cohorts only.

Each record is one project. All labels are observed at the data cutoff; an
earlier withdrawal prevents a later event. K-fold groups are project IDs.
The chronological test additionally purges training labels that would not
have matured when the first test project entered the queue.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

SEED = 20261111
HORIZONS = (1, 3, 5)
NUMERIC = ['project_mw', 'q_year']
CATEGORICAL = ['state', 'type_clean', 'service']
FEATURES = NUMERIC + CATEGORICAL
EVENTS = {'agreement': 'ia_date_lbnl', 'operation': 'operational_date'}


def load_projects(path: Path) -> tuple[pd.DataFrame, pd.Timestamp]:
    panel = pd.read_csv(path, low_memory=False)
    required = {'project_id', 'panel_quarter', 'observation_date', 'q_date',
                'model_eligible', 'withdrawal_date_lbnl', 'transition_outcome',
                'lbnl_q_status', 'lbnl_match', *EVENTS.values(), *FEATURES}
    missing = sorted(required - set(panel.columns))
    if missing:
        raise ValueError(f'Missing required columns: {missing}')
    eligible = panel.model_eligible.astype(str).str.lower().isin(['true', '1'])
    panel = panel.loc[eligible].copy()
    for col in ['observation_date', 'q_date', 'withdrawal_date_lbnl', *EVENTS.values()]:
        panel[col] = pd.to_datetime(panel[col], errors='coerce')
    cutoff = pd.Period(panel.panel_quarter.max(), freq='Q').end_time.normalize()
    panel = panel.sort_values(['project_id', 'observation_date'])
    projects = panel.drop_duplicates('project_id', keep='first').copy()
    # Event dates describe future labels and may only appear on later rows;
    # features, however, must come from the actual first observation.
    dates = panel.groupby('project_id')[['withdrawal_date_lbnl', *EVENTS.values()]].first()
    for col in dates.columns:
        projects[col] = projects.project_id.map(dates[col])
    known_event = panel.assign(_ia=panel.transition_outcome.eq('IA/operational')).groupby('project_id')['_ia'].any()
    projects['_known_ia_event'] = projects.project_id.map(known_event).fillna(False)
    projects['_matched'] = projects.lbnl_match.astype(str).str.lower().isin(['true', '1'])
    projects = projects.loc[projects.q_date.notna() & projects.observation_date.notna()].copy()
    # Score only snapshots observed near entry, rather than pretending that
    # later observations were available when the project entered the queue.
    gap = (projects.observation_date - projects.q_date).dt.days
    projects = projects.loc[gap.between(0, 120) & projects.q_date.dt.year.ge(2013)].copy()
    for col in CATEGORICAL:
        projects[col] = projects[col].fillna('Missing').astype(str)
    projects['project_mw'] = pd.to_numeric(projects.project_mw, errors='coerce')
    projects['q_year'] = projects.q_date.dt.year.astype(float)
    return projects, cutoff


def horizon_data(projects: pd.DataFrame, cutoff: pd.Timestamp, years: int, endpoint: str) -> pd.DataFrame:
    d = projects.copy()
    # A known event with no usable date cannot be classified at a horizon.
    # Unmatched projects and undated withdrawals likewise have unknown labels.
    d = d.loc[d['_matched'] & ~(d.lbnl_q_status.eq('withdrawn') & d.withdrawal_date_lbnl.isna())].copy()
    if endpoint == 'agreement':
        d = d.loc[~((d['_known_ia_event'] | d.lbnl_q_status.eq('operational')) & d.ia_date_lbnl.isna())].copy()
    else:
        d = d.loc[~(d.lbnl_q_status.eq('operational') & d.operational_date.isna())].copy()
    d['horizon_end'] = d.q_date + pd.DateOffset(years=years)
    # Restrict both classes to a complete horizon, avoiding preferential
    # inclusion of fast-resolving projects with incomplete follow-up.
    d = d.loc[d.horizon_end.le(cutoff)].copy()
    date = d[EVENTS[endpoint]]
    withdrawal = d.withdrawal_date_lbnl
    valid_event = date.notna() & date.ge(d.q_date) & date.le(d.horizon_end)
    before_withdrawal = withdrawal.isna() | date.le(withdrawal)
    d['target'] = (valid_event & before_withdrawal).astype(int)
    return d


def make_model(name: str) -> Pipeline:
    num = Pipeline([('impute', SimpleImputer(strategy='median', keep_empty_features=True)),
                    ('scale', StandardScaler())])
    cat = Pipeline([('impute', SimpleImputer(strategy='most_frequent', keep_empty_features=True)),
                    ('encode', OneHotEncoder(handle_unknown='ignore', sparse_output=False))])
    preprocess = ColumnTransformer([('num', num, NUMERIC), ('cat', cat, CATEGORICAL)])
    choices = {
        'logistic': LogisticRegression(max_iter=1000, random_state=SEED),
        'extra_trees': ExtraTreesClassifier(n_estimators=100, min_samples_leaf=15,
                                           max_features=.8, n_jobs=1, random_state=SEED),
        'hist_gradient_boosting': HistGradientBoostingClassifier(max_iter=100, max_leaf_nodes=15,
                                           min_samples_leaf=30, l2_regularization=2, random_state=SEED),
    }
    return Pipeline([('preprocess', preprocess), ('model', choices[name])])


def metrics(y: np.ndarray, probability: np.ndarray) -> dict:
    return {'auc': float(roc_auc_score(y, probability)) if len(np.unique(y)) == 2 else None,
            'log_loss': float(log_loss(y, probability, labels=[0, 1])),
            'brier': float(brier_score_loss(y, probability))}


def run(path: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    projects, cutoff = load_projects(path)
    scores, predictions, bundles = [], [], {}
    for endpoint in EVENTS:
        for horizon in HORIZONS:
            data = horizon_data(projects, cutoff, horizon, endpoint)
            # Pick a cohort boundary, then purge labels not fully known at it.
            boundary = data.q_date.quantile(.8).normalize()
            train = data.loc[(data.q_date < boundary) & (data.horizon_end < boundary)].copy()
            holdout = data.loc[data.q_date >= boundary].copy()
            if len(train) < 50 or train.target.nunique() < 2 or len(holdout) == 0:
                scores.append({'endpoint': endpoint, 'years': horizon, 'status': 'insufficient temporal sample',
                               'train_projects': len(train), 'holdout_projects': len(holdout)})
                continue
            groups = GroupKFold(n_splits=5)
            candidates = {}
            for name in ('logistic', 'extra_trees', 'hist_gradient_boosting'):
                oof = np.full(len(train), np.nan)
                for fit, validate in groups.split(train, train.target, train.project_id):
                    fold_train, fold_test = train.iloc[fit], train.iloc[validate]
                    if fold_train.target.nunique() < 2:
                        raise ValueError(f'{endpoint}/{horizon}: one-class training fold')
                    model = make_model(name).fit(fold_train[FEATURES], fold_train.target)
                    oof[validate] = model.predict_proba(fold_test[FEATURES])[:, 1]
                cv = metrics(train.target.to_numpy(), oof)
                fitted = make_model(name).fit(train[FEATURES], train.target)
                test_prob = fitted.predict_proba(holdout[FEATURES])[:, 1]
                test = metrics(holdout.target.to_numpy(), test_prob)
                record = {'endpoint': endpoint, 'years': horizon, 'model': name, 'status': 'ok',
                          'train_projects': len(train), 'train_events': int(train.target.sum()),
                          'holdout_projects': len(holdout), 'holdout_events': int(holdout.target.sum()),
                          'holdout_start': str(boundary.date()),
                          **{f'cv_{k}': v for k, v in cv.items()},
                          **{f'holdout_{k}': v for k, v in test.items()}}
                scores.append(record)
                candidates[name] = record
                for pid, y, p in zip(holdout.project_id, holdout.target, test_prob):
                    predictions.append({'project_id': pid, 'endpoint': endpoint, 'years': horizon,
                                        'model': name, 'observed': int(y), 'probability': float(p)})
            # No algorithm is guaranteed to win all metrics. Use equal-weight
            # CV ranks, with log loss as deterministic tie-breaker; reserve the
            # temporal holdout for reporting, not selection.
            ranking = pd.DataFrame(candidates.values()).set_index('model')
            ranking['rank'] = (ranking.cv_auc.rank(ascending=False) + ranking.cv_log_loss.rank() + ranking.cv_brier.rank())
            winner = ranking.sort_values(['rank', 'cv_log_loss']).index[0]
            for row in scores:
                if row.get('endpoint') == endpoint and row.get('years') == horizon and row.get('model'):
                    row['selected'] = row['model'] == winner
            bundles[f'{endpoint}_{horizon}y'] = make_model(winner).fit(data[FEATURES], data.target)
            print(f'{endpoint} {horizon}y: {winner}, train {len(train)}, holdout {len(holdout)}', flush=True)
    pd.DataFrame(scores).to_csv(output / 'comparison.csv', index=False)
    pd.DataFrame(predictions).to_csv(output / 'temporal_holdout_predictions.csv', index=False)
    joblib.dump({'models': bundles, 'features': FEATURES, 'cutoff': str(cutoff.date()),
                 'sklearn_version': sklearn.__version__, 'seed': SEED}, output / 'miso_models.joblib')
    (output / 'audit.json').write_text(json.dumps({'cutoff': str(cutoff.date()),
        'input_projects': len(projects), 'selection': 'sum of ranks across project-grouped CV AUC, log loss and Brier',
        'limitations': ['IA dates may be missing or incomplete', 'static project attributes can reflect later snapshots',
          'no probability calibration guarantee', 'five-year holdout is small',
          'models estimate entry-time outcomes, not conditional forecasts for projects already in the queue']}, indent=2), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('panel', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    run(args.panel, args.output)
