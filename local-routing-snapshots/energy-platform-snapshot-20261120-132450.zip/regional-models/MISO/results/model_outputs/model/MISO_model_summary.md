# MISO interconnection queue outcome model

## What the model says

The model estimates quarterly probabilities of staying in the queue, withdrawing, or reaching an interconnection agreement/operation. It is predictive, not causal. The selected production model is **logit** because the out-of-time comparison did not show enough improvement to justify replacing the simpler logit. Queue-backlog variables such as `mw_ahead` and POI/county active counts measure **queue congestion**, not physical transmission congestion.

The strongest LightGBM predictors for withdrawal were cluster cycle year, queued MW ahead, 2022+ entry cohort, prior-four-quarter regional withdrawal rate, and queue age. For IA/operation they were queued MW ahead, queue age, prior-four-quarter regional withdrawal rate, missing service designation, and lagged county active-project count. These rankings describe predictive contribution; they do not establish that changing a feature will change an outcome.

## Reliability

The out-of-time test covers 2023Q1-2025Q4. Quarterly log loss was 0.3133 for the selected model versus 0.3369 for the age-only benchmark; multiclass Brier score was 0.1498 versus 0.1574. At 12 quarters, fixed-horizon concordance was 0.574 for withdrawal and 0.922 for IA. Calibration is shown by decile in the accompanying chart and table.

The active-project point estimates are **not stable enough for high-stakes use**. Refitting through all available 2013+ data produces a mean four-quarter withdrawal CIF of 86.1%; excluding all audit-flagged spike quarters lowers it to 8.1%. This 78.0-percentage-point swing shows that mass administrative withdrawals dominate the live forecast. Use the main scores for stress/triage and the spike-excluded result as a contrasting scenario, not as precise probabilities.

## Important limitations

The main model uses 2013+ entry cohorts because older records have strong survivorship bias. Including full history changed the mean out-of-time IA hazard by +28.5%; the upward movement is consistent with the old cohorts biasing IA probabilities upward. The proposed online date is excluded from the baseline because it is a 2025 snapshot. Adding it worsened out-of-time log loss by 10.7%; this is not evidence of a performance inflation, but the snapshot field remains excluded. Static MW, technology, POI, utility, and related fields are end-of-period snapshots and may not equal their values at entry.

MISO filed its Order 2023 compliance proposal on May 16, 2024. The indicator marks rows on or after that filing date; it is a regime label, not evidence of a causal policy effect or full implementation. The supplied panel stops at the first terminal event, so it cannot independently verify the approximately 850 projects reported to have reached IA and later withdrawn. IA remains the terminal event as instructed.

Future active-project scores freeze today's queue-backlog and recent-withdrawal-rate features because future queue conditions are unknown. The conditional expected time to IA is calculated over a 20-quarter forecast window. Predictions should be refreshed as the queue changes and should support, not replace, planner review.
