import unittest
import numpy as np
import pandas as pd
from train import CAT, NUM, curve
from simulate_queue import simulate, transitions
from blocked_entry_validation import split_block

class ConstantModel:
    def predict_proba(self, frame):
        return np.tile([0.7, 0.2, 0.1], (len(frame), 1))

class DynamicTests(unittest.TestCase):
    def test_competing_outcomes_and_age_progression(self):
        frame = pd.DataFrame([{**{key: 1 for key in NUM}, **{key: 'x' for key in CAT}}])
        results = curve(ConstantModel(), frame)
        for q, values in results.items():
            steps = int(q)
            self.assertAlmostEqual(values[0, 0], (1 - .7**steps) / 3)
            self.assertAlmostEqual(values[0, 1], 2 * (1 - .7**steps) / 3)
            self.assertAlmostEqual(values[0].sum(), 1)
        self.assertLess(results['4'][0,0], results['12'][0,0])
        self.assertLess(results['12'][0,0], results['20'][0,0])

    def test_simulation_preserves_competing_risk_probabilities(self):
        frame = pd.DataFrame([{**{key: 1 for key in NUM}, **{key: 'x' for key in CAT}}])
        changes = pd.DataFrame({
            'mw_ahead_before': [1.] * 100, 'withdraw_rate_before': [.1] * 100,
            'ahead_delta': [0.] * 100, 'withdraw_delta': [0.] * 100,
            'poi_peers_delta': [0.] * 100, 'county_peers_delta': [0.] * 100,
        })
        simulated = simulate(ConstantModel(), frame, changes, paths=4)
        baseline = curve(ConstantModel(), frame)
        for q in ('4', '12', '20'):
            np.testing.assert_allclose(simulated[q], baseline[q])

    def test_transition_history_stops_before_forecast_origin(self):
        rows = []
        for quarter, value in [('2019Q3', 10.), ('2019Q4', 9.), ('2020Q1', 1.)]:
            rows.append({'project_id':'J1', 'quarter':pd.Period(quarter), 'target':0,
                         'observed':True, 'mw_ahead':value, 'poi_peers':1.,
                         'county_peers':1., 'withdraw_rate':.1})
        out = transitions(pd.DataFrame(rows), pd.Period('2020Q1'))
        self.assertEqual(len(out), 1)
        self.assertEqual(out.iloc[0].quarter, pd.Period('2019Q4'))
        self.assertEqual(out.iloc[0].mw_ahead_after, 9.)

    def test_entry_year_and_adjacent_years_are_embargoed(self):
        df=pd.DataFrame({'q_date':['2003-01-01','2004-01-01','2005-01-01','2006-01-01','2007-01-01','2003-01-01'],
                         'quarter':pd.PeriodIndex(['2003Q1','2004Q1','2005Q1','2006Q1','2007Q1','2005Q1'],freq='Q')})
        train,validation=split_block(df,2005)
        self.assertEqual(train.tolist(),[True,False,False,False,True,False])
        self.assertEqual(validation.tolist(),[False,False,True,False,False,False])

if __name__ == '__main__': unittest.main()
