"""Project- and cohort-grouped quarterly IA/withdrawal research comparisons."""
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from train import ROOT,HERE,NUM,CAT,prepare,model,scores

def main():
    d,_=prepare(ROOT/'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    d=d[d.observed & (d.quarter>=pd.Period('2013Q1')) & (d.quarter<pd.Period('2023Q1'))].copy()
    d['cohort_year']=d.cluster.fillna('').astype(str).str.extract(r'(?i)DPP[- ](\d{4})',expand=False)
    # Project must map to exactly one known year. Do not pool missing or pending cohorts.
    n=d.groupby('project_id').cohort_year.nunique()
    eligible=d.cohort_year.notna() & d.project_id.map(n).eq(1)
    data=d[eligible].copy(); X=data[NUM+CAT]; y=data.target
    results={'warning':'Retrospective cluster labels and other project fields are not verified point-in-time. Quarterly metrics; not a five-year forecast test. Known-cohort subset only.',
             'all_projects':int(d.project_id.nunique()),'projects_with_known_cycle_year':int(data.project_id.nunique()),
             'rows':len(data),'cycle_years':sorted(data.cohort_year.unique().tolist()),'grouping':{}}
    for grouping in ['project_id','cohort_year']:
        out=np.zeros((len(data),3)); splits=[]
        for train_idx,test_idx in GroupKFold(n_splits=5).split(X,y,data[grouping]):
            m=model('gradient_boosting'); m.fit(X.iloc[train_idx],y.iloc[train_idx]); out[test_idx]=m.predict_proba(X.iloc[test_idx])
            splits.append({'test_rows':len(test_idx),'test_projects':int(data.iloc[test_idx].project_id.nunique()),
                           'test_cohorts':sorted(data.iloc[test_idx].cohort_year.unique().tolist())})
        results['grouping'][grouping]={'metrics':scores(y,out),'folds':splits}
    (HERE/'cluster_validation_results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
