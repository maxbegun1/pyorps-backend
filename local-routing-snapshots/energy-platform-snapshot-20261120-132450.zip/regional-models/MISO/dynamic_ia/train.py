"""Reproducible quarterly competing-risk research model; no cost estimates."""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import log_loss, roc_auc_score, brier_score_loss
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
NUM = ['age_quarters', 'project_mw', 'mw_ahead', 'poi_peers', 'county_peers', 'withdraw_rate']
CAT = ['state', 'type_clean', 'service']

def prepare(path):
    d = pd.read_csv(path, low_memory=False)
    for col in ['quarter_start', 'observation_date', 'q_date', 'ia_date_lbnl', 'withdrawal_date_lbnl', 'operational_date']:
        d[col] = pd.to_datetime(d[col], errors='coerce')
    d['quarter'] = d.quarter_start.dt.to_period('Q')
    d['quarter_end'] = d.quarter.dt.end_time.dt.normalize()
    for c in ['age_quarters', 'project_mw', 'mw_ahead']:
        d[c] = pd.to_numeric(d[c], errors='coerce').clip(lower=0)
    # Restrict to matched records with known dates for recorded terminal outcomes.
    status = d.lbnl_q_status.fillna('').str.lower()
    unclear = ((status.str.contains('withdraw') & d.withdrawal_date_lbnl.isna()) |
               ((d.transition_outcome == 'IA/operational') & d.ia_date_lbnl.isna()))
    bad_ids = set(d.loc[unclear, 'project_id'])
    matched = d.lbnl_match.astype(str).str.lower().isin(['true', '1'])
    d = d[matched & ~d.project_id.isin(bad_ids)].copy()
    ia, wd = d.ia_date_lbnl, d.withdrawal_date_lbnl
    terminal = pd.concat([ia, wd], axis=1).min(axis=1)
    d = d[terminal.isna() | (terminal >= d.observation_date)].copy()
    ia, wd = d.ia_date_lbnl, d.withdrawal_date_lbnl
    in_ia = ia.between(d.observation_date, d.quarter_end) & (wd.isna() | (ia < wd))
    in_wd = wd.between(d.observation_date, d.quarter_end) & (ia.isna() | (wd < ia))
    ties = ia.notna() & (ia == wd) & ia.between(d.observation_date, d.quarter_end)
    d = d[~ties].copy(); in_ia = in_ia[~ties]; in_wd = in_wd[~ties]
    d['target'] = np.select([in_ia, in_wd], [2, 1], default=0)
    # A stay is observed only when the project appears in the next quarter.
    d = d.sort_values(['project_id', 'quarter_start'])
    next_q = d.groupby('project_id').quarter.shift(-1)
    d['observed'] = (d.target != 0) | (next_q == d.quarter + 1)
    # Use the preceding quarter's queue snapshot. Missing locations remain missing.
    prev = d[(d.target == 0) & d.observed].copy(); prev['quarter'] = prev.quarter + 1
    previous_ids = pd.MultiIndex.from_frame(prev[['quarter', 'project_id']])
    seen_before = pd.MultiIndex.from_frame(d[['quarter', 'project_id']]).isin(previous_ids).astype(int)
    d['seen_before'] = seen_before
    for source, out in [('poi_name', 'poi_peers'), ('county', 'county_peers')]:
        cols = ['quarter', 'state', source]
        counts = prev.dropna(subset=['state', source]).groupby(cols).project_id.nunique().rename(out).reset_index()
        d = d.merge(counts, on=cols, how='left')
        # The snapshot can include the project itself.
        d[out] = (d[out] - d.seen_before).clip(lower=0)
    rates = d.groupby('quarter').agg(n=('project_id', 'size'), withdrawals=('target', lambda x: (x == 1).sum()))
    rates['withdraw_rate'] = (rates.withdrawals / rates.n).shift(1).rolling(4, min_periods=1).mean()
    d['withdraw_rate'] = d.quarter.map(rates.withdraw_rate)
    d[CAT] = d[CAT].fillna('Unknown').astype(str)
    return d, len(bad_ids)

def model(kind):
    numeric = make_pipeline(SimpleImputer(strategy='median', add_indicator=True), StandardScaler())
    prep = ColumnTransformer([('num', numeric, NUM), ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), CAT)])
    est = (LogisticRegression(max_iter=500) if kind == 'logistic' else
           HistGradientBoostingClassifier(max_iter=100, max_leaf_nodes=15, l2_regularization=10, random_state=42))
    return make_pipeline(prep, est)

def scores(y, probs):
    ia = (np.asarray(y) == 2).astype(int)
    return {'rows': len(y), 'ia_events': int(ia.sum()), 'withdrawals': int((np.asarray(y) == 1).sum()),
            'multiclass_log_loss': float(log_loss(y, probs, labels=[0,1,2])),
            'multiclass_brier': float(np.mean(np.sum((np.eye(3)[np.asarray(y)] - probs)**2, axis=1))),
            'ia_auc': float(roc_auc_score(ia, probs[:,2])) if len(np.unique(ia)) == 2 else None,
            'ia_brier': float(brier_score_loss(ia, probs[:,2]))}

def curve(m, frame):
    x = frame.copy(); n = len(x); survival = np.ones(n); ia = np.zeros(n); wd = np.zeros(n); output = {}
    for q in range(1, 21):
        p = m.predict_proba(x[NUM + CAT])
        ia += survival * p[:,2]; wd += survival * p[:,1]; survival *= p[:,0]
        if q in (4,12,20): output[str(q)] = np.column_stack([ia.copy(), wd.copy(), survival.copy()])
        x['age_quarters'] = x.age_quarters + 1
    return output

def main():
    d, excluded = prepare(ROOT / 'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    data = d[d.observed & (d.quarter >= pd.Period('2013Q1'))].copy()
    train = data[data.quarter < pd.Period('2023Q1')]; test = data[data.quarter >= pd.Period('2023Q1')]
    report = {'data_through': str(d.quarter.max()), 'excluded_projects_with_undated_outcome': excluded,
              'training_rows': len(train), 'training_projects': train.project_id.nunique(), 'models': {}}
    X = train[NUM+CAT]; y = train.target; groups = train.project_id
    for kind in ['logistic', 'gradient_boosting']:
        pred = np.zeros((len(train),3))
        for a,b in GroupKFold(n_splits=5).split(X,y,groups):
            m = model(kind); m.fit(X.iloc[a], y.iloc[a]); pred[b] = m.predict_proba(X.iloc[b])
        m = model(kind); m.fit(X,y)
        report['models'][kind] = {'grouped_5_fold': scores(y,pred), 'later_quarters': scores(test.target,m.predict_proba(test[NUM+CAT]))}
    # Select by later-time log loss, not random folds. The holdout is then selection data, not an independent final test.
    chosen = min(report['models'], key=lambda k: report['models'][k]['later_quarters']['multiclass_log_loss'])
    report['selected'] = chosen
    report['selection_warning'] = 'Later quarters were used for selection; an independent future test is still needed.'
    # Separate historical origin to assess cumulative predictions with mature follow-up.
    # The selected algorithm has already seen later-quarter model-selection results.
    older = data[data.quarter < pd.Period('2020Q1')]
    origins = d[d.quarter == pd.Period('2020Q1')].copy()
    last = d.groupby('project_id').quarter.max()
    report['historical_horizons_by_model'] = {}
    for kind in ['logistic', 'gradient_boosting']:
        historic = model(kind); historic.fit(older[NUM+CAT], older.target)
        historic_curves = curve(historic, origins)
        horizon_results = {}
        for q in (4, 12, 20):
            end = (pd.Period('2020Q1') + q - 1).end_time.normalize()
            ia, wd = origins.ia_date_lbnl, origins.withdrawal_date_lbnl
            event = ia.notna() & (ia <= end) & (wd.isna() | (ia < wd))
            withdraw = wd.notna() & (wd <= end) & (ia.isna() | (wd < ia))
            resolved = (ia.notna() & (ia <= end)) | (wd.notna() & (wd <= end))
            mature = resolved | (origins.project_id.map(last) >= pd.Period(end, freq='Q'))
            actual = event[mature].astype(int).to_numpy()
            p = historic_curves[str(q)][:,0][mature.to_numpy()]
            horizon_results[str(q//4)] = {
                'projects': int(len(p)), 'ia_events': int(actual.sum()),
                'observed_ia_rate': float(actual.mean()), 'mean_predicted_ia': float(p.mean()),
                'observed_withdrawal_rate': float(withdraw[mature].mean()),
                'mean_predicted_withdrawal': float(historic_curves[str(q)][:,1][mature.to_numpy()].mean()),
                'brier': float(brier_score_loss(actual,p)),
                'log_loss': float(log_loss(actual,p,labels=[0,1])),
                'auc': float(roc_auc_score(actual,p)) if len(np.unique(actual)) == 2 else None,
                'excluded_incomplete_followup': int((~mature).sum())}
        report['historical_horizons_by_model'][kind] = horizon_results
    m = model(chosen); m.fit(data[NUM+CAT],data.target)
    latest = d[d.quarter == d.quarter.max()].copy()
    # Score at the end of the data vintage, not at the beginning of a quarter
    # while retrospectively excluding projects that exited during that quarter.
    latest = latest[(latest.transition_outcome == 'censored') &
                    (latest.lbnl_q_status.fillna('').str.lower() == 'active')].copy()
    latest['age_quarters'] = latest.age_quarters + 1
    latest = latest.drop_duplicates('project_id', keep='last')
    curves = curve(m, latest)
    assert all(np.allclose(v.sum(axis=1), 1) for v in curves.values())
    assert np.all(curves['4'][:,0] <= curves['12'][:,0]+1e-12) and np.all(curves['12'][:,0] <= curves['20'][:,0]+1e-12)
    report['scored_projects'] = len(latest)
    HERE.mkdir(exist_ok=True)
    joblib.dump(m, HERE / 'dynamic_ia.joblib')
    (HERE / 'metrics.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    results = {}
    for i, (_, row) in enumerate(latest.iterrows()):
        results[str(row.project_id)] = {q: {'agreement': float(v[i,0]), 'withdrawal': float(v[i,1]), 'unresolved': float(v[i,2])} for q,v in curves.items()}
    # The previous model collapses almost all outcomes into the first year.
    output = {'as_of': str(d.quarter.max().end_time.date()), 'model': chosen,
              'release_ready': False, 'research_visible': False, 'projects': results}
    (ROOT / 'queue-atlas-ui/miso-dynamic-forecast.json').write_text(json.dumps(output, separators=(',',':')), encoding='utf-8')
    print(json.dumps(report, indent=2))

if __name__ == '__main__': main()
