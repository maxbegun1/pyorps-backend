# MISO dynamic IA research model

**Do not use these probabilities for decisions.** The public interface now withholds the frozen-queue estimates: 1,190 of 1,222 projects display the same IA and withdrawal percentages at 1, 3 and 5 years when rounded to one decimal. The fitted model assigned 88% average quarterly withdrawal probability at the 2025Q4 scoring origin, so most simulated outcomes occur in the first year. The observed late-2025 withdrawal spike is a likely contributor, but its precise effect has not been causally isolated. For projects observed in 2020Q1, the average predicted IA incidence at five years was 19.8%, versus 47.6% observed. This backtest is retrospective and not an independent final test.

The model estimates a quarterly transition to IA, withdrawal, or remaining in the queue, then combines quarterly probabilities over 4, 12, and 20 quarters. A withdrawal prevents a later IA in this calculation. Age increases each quarter; other attributes and queue conditions are frozen at the scoring snapshot. There are no estimated costs. The last data vintage ends 2025-12-31, so these are not current live predictions. The fitted model and generated estimates are research artifacts only.

Inputs include project age, size, technology, state, service, MW ahead, the prior quarter's POI and state/county peer counts, and a rolling lagged regional withdrawal rate. The POI and county counts come from the matched, date-usable panel, so they do not necessarily cover the whole queue. The existing `mw_ahead` and project attributes need a source audit: some may reflect later revisions rather than what was known at the time. Missing values are imputed; location is not inferred from missing fields. Costs are not used.

Records with unmatchable or undated known outcomes are excluded; 118 projects with undated outcomes were excluded by this rule. The sample selection itself uses eventual record status and may bias historical results. Censored rows without another observation are not treated as observed stays. IA and operation are separate: an operation without a dated IA is not labelled as an IA. Same-day IA and withdrawal events are excluded. Project-grouped five-fold validation prevents a project's rows crossing folds, but is not a time-based test; cross-project queue features are computed before splitting. The later-quarter comparison uses 2023–2025 for both selection and evaluation, so it is not an independent final assessment.

The output probabilities are illustrative; both `release_ready` and `research_visible` are false. To make this suitable for decisions, obtain verifiable historical snapshots of project attributes and the full queue, investigate the long-horizon calibration failure and mass withdrawals, and test independent historical cohorts and subsequent data. Validate calibration by horizon and project subgroup, competing-event handling, and data completeness.

Run from the repository root using Python with pandas, numpy, scikit-learn, scipy and joblib:

```
python regional_models/MISO/dynamic_ia/train.py
python -m unittest discover -s regional_models/MISO/dynamic_ia -p test_dynamic.py -v
```

The script writes `metrics.json`, a scikit-learn model, and the website's generated data file. Loading a model across scikit-learn versions is unsupported. Only load trusted model files.
