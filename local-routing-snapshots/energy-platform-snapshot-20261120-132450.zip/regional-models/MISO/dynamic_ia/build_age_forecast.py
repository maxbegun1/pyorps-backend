"""Build an age-based competing-risk research estimate from the dated panel."""
import json
import numpy as np
import pandas as pd
from baselines import EmpiricalHazard
from train import ROOT, HERE, prepare, curve
from simulate_queue import metric


def main():
    d, excluded = prepare(ROOT / 'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    data = d[d.observed & (d.quarter >= pd.Period('2013Q1'))]
    last = d.groupby('project_id').quarter.max()
    report = {'excluded_undated_projects': excluded, 'origins': {}}
    for year in range(2016, 2021):
        origin = pd.Period(f'{year}Q1')
        start = d[d.quarter == origin].copy()
        predictions = curve(EmpiricalHazard(data[data.quarter < origin]), start)
        horizons = {}
        for q in (4, 12, 20):
            end = (origin + q - 1).end_time.normalize()
            ia, wd = start.ia_date_lbnl, start.withdrawal_date_lbnl
            ia_event = ia.notna() & (ia <= end) & (wd.isna() | (ia < wd))
            wd_event = wd.notna() & (wd <= end) & (ia.isna() | (wd < ia))
            mature = ((ia.notna() & (ia <= end)) | (wd.notna() & (wd <= end)) |
                      (start.project_id.map(last) >= origin + q - 1))
            mask = mature.to_numpy()
            horizons[str(q // 4)] = {
                'ia': metric(ia_event[mature].astype(int).to_numpy(), predictions[str(q)][mask, 0]),
                'withdrawal': metric(wd_event[mature].astype(int).to_numpy(), predictions[str(q)][mask, 1], 'withdrawal'),
                'excluded_incomplete_followup': int((~mature).sum())}
        report['origins'][str(year)] = horizons
    latest = d[(d.quarter == d.quarter.max()) & (d.transition_outcome == 'censored') &
               (d.lbnl_q_status.fillna('').str.lower() == 'active')].drop_duplicates('project_id').copy()
    latest['age_quarters'] += 1
    predictions = curve(EmpiricalHazard(data), latest)
    assert all(np.allclose(p.sum(axis=1), 1) for p in predictions.values())
    for column in (0, 1):
        assert np.all(predictions['4'][:, column] <= predictions['12'][:, column])
        assert np.all(predictions['12'][:, column] <= predictions['20'][:, column])
    projects = {str(row.project_id): {q: dict(zip(('agreement', 'withdrawal', 'unresolved'),
                 map(float, p[i]))) for q, p in predictions.items()}
                for i, (_, row) in enumerate(latest.iterrows())}
    output = {'as_of': str(d.quarter.max().end_time.date()), 'model': 'age-based historical competing risks',
              'release_ready': False, 'research_visible': True, 'projects': projects}
    (ROOT / 'queue-atlas-ui/miso-dynamic-forecast.json').write_text(json.dumps(output, separators=(',', ':')), encoding='utf-8')
    (HERE / 'age_forecast_validation.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(f'Scored {len(projects)} projects; {excluded} projects with undated outcomes excluded.')


if __name__ == '__main__':
    main()
