"""Extract public LBNL year-end snapshots without claiming their revision dates."""
import hashlib
import json
import pandas as pd
import openpyxl
from openpyxl.utils.datetime import from_excel
from train import HERE

def main():
    base=HERE/'lbnl_vintages'
    known_hashes={'queues_2023.xlsx':'832f21cf62a3c333b1834455deecbcbc99b80cb65e43855b7a48355fec838a39',
                  'queues_2024_v2.xlsx':'d816467f629a13ef4013dee000129d61f8e4d7fcd8ba514c404a4e140dfec991'}
    specs=[('queues_2023.xlsx','data',False,'2023-12-31','2024 report, data through 2023'),
           ('queues_2024_v2.xlsx','03. Complete Queue Data',True,'2024-12-31','2025 report, data through 2024, revision v2')]
    results=[]; manifest=[]
    for filename,sheet,skip_title,date,description in specs:
        path=base/filename; raw=path.read_bytes(); book=openpyxl.load_workbook(path,read_only=True,data_only=True)
        if hashlib.sha256(raw).hexdigest()!=known_hashes[filename]:
            raise ValueError('Source revision changed; re-audit before assigning availability')
        it=book[sheet].values
        if skip_title: next(it)
        header=next(it); names={str(v).strip():i for i,v in enumerate(header) if v is not None}
        required=['q_id','q_status','q_date','entity','IA_status_raw','IA_status_clean']
        if any(k not in names for k in required): raise ValueError('Unrecognized LBNL source schema')
        count=0
        for r in it:
            entity=str(r[names['entity']]).upper().strip()
            if entity not in ['MISO','NYISO']: continue
            qid=r[names['q_id']]; qdate=r[names['q_date']]
            if qid is None or qdate is None: continue
            if isinstance(qdate,(float,int)):
                try: qdate=from_excel(qdate,book.epoch)
                except (ValueError,OverflowError): continue
            qdate=pd.to_datetime(qdate,errors='coerce')
            if pd.isna(qdate): continue
            val=lambda k: r[names[k]] if k in names else None
            results.append({'region':entity,'project_id':str(qid).strip(),'q_date':str(qdate)[:10],
                'observed_at':date,'available_at':'2026-11-11','q_status':val('q_status'),
                'phase_raw':val('IA_status_raw'),'phase_clean':val('IA_status_clean'),
                'cohort_raw':val('cluster'),'source':filename})
            count+=1
        manifest.append({'file':filename,'description':description,'sha256':hashlib.sha256(raw).hexdigest(),
                         'regional_records_before_duplicate_exclusion':count,
                         'availability_caveat':'Exact release date of this file revision unverified; do not backdate availability.'})
    data=pd.DataFrame(results)
    dup=data.duplicated(['region','project_id','q_date','observed_at'],keep=False)
    manifest.append({'ambiguous_duplicate_rows_excluded':int(dup.sum())})
    data=data[~dup].copy(); data.to_csv(base/'regional_phase_snapshots.csv',index=False)
    (base/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    by=data.groupby(['region','observed_at']).agg(records=('project_id','size'),raw_phases=('phase_raw','count'),clean_phases=('phase_clean','count'))
    left=data[data.observed_at.eq('2023-12-31')]; right=data[data.observed_at.eq('2024-12-31')]
    joined=left.merge(right,on=['region','project_id','q_date'],suffixes=('_2023','_2024'))
    print(by.to_string()); print('Matched project ID and queue date:',len(joined))
    print('Both clean phases present:',int((joined.phase_clean_2023.notna() & joined.phase_clean_2024.notna()).sum()))
    print('Clean phase differences:',int((joined.phase_clean_2023.notna() & joined.phase_clean_2024.notna() & (joined.phase_clean_2023!=joined.phase_clean_2024)).sum()))
if __name__=='__main__':main()
