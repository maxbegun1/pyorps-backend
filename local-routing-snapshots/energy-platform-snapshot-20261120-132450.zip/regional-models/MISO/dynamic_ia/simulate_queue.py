"""Research backtest: bootstrap historical queue changes into competing-risk paths.

No future data may enter a historical model fit or its transition sample.
"""
import json
import numpy as np
import pandas as pd
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score
from train import ROOT, HERE, NUM, CAT, prepare, model, curve

CHANGING = ['mw_ahead', 'poi_peers', 'county_peers', 'withdraw_rate']

def transitions(d, origin):
    past = d[d.quarter < origin].copy()
    before = past[(past.target == 0) & past.observed][['project_id','quarter']+CHANGING].copy()
    after = past[['project_id','quarter']+CHANGING].copy()
    before['quarter'] = before.quarter + 1
    t = before.merge(after, on=['project_id','quarter'], suffixes=('_before','_after'))
    t = t.dropna(subset=['mw_ahead_before','mw_ahead_after','withdraw_rate_before','withdraw_rate_after'])
    t['ahead_delta'] = (np.log1p(t.mw_ahead_after.clip(lower=0)) - np.log1p(t.mw_ahead_before.clip(lower=0))).clip(-1.5,1.5)
    t['withdraw_delta'] = (t.withdraw_rate_after - t.withdraw_rate_before).clip(-.2,.2)
    for c in ['poi_peers','county_peers']:
        t[c+'_delta'] = (t[c+'_after'] - t[c+'_before']).fillna(0).clip(-20,20)
    return t

def pools_for(t):
    if len(t) < 100: raise ValueError('Not enough past queue transitions')
    ahead_edges = np.quantile(np.log1p(t.mw_ahead_before), [1/3,2/3])
    withdraw_edges = np.quantile(t.withdraw_rate_before, [1/3,2/3])
    a = np.searchsorted(ahead_edges, np.log1p(t.mw_ahead_before), side='right')
    w = np.searchsorted(withdraw_edges, t.withdraw_rate_before, side='right')
    pool_ids = 3*a+w
    cols = ['ahead_delta','withdraw_delta','poi_peers_delta','county_peers_delta']
    changes = t[cols].to_numpy(dtype=float)
    pools = [np.flatnonzero(pool_ids==i) for i in range(9)]
    pools = [p if len(p)>=20 else np.arange(len(changes)) for p in pools]
    return ahead_edges,withdraw_edges,changes,pools

def simulate(m, origins, t, paths=32, seed=42):
    rng = np.random.default_rng(seed)
    ahead_edges, withdraw_edges, changes, pools = pools_for(t)
    # Arrange paths contiguously per project, and average incidence across paths.
    x = origins.loc[origins.index.repeat(paths), NUM+CAT].reset_index(drop=True).copy()
    n = len(x); survival = np.ones(n); ia = np.zeros(n); wd = np.zeros(n); out = {}
    for q in range(1,21):
        p = m.predict_proba(x[NUM+CAT]); ia += survival*p[:,2]; wd += survival*p[:,1]; survival *= p[:,0]
        if q in (4,12,20):
            out[str(q)] = np.column_stack([ia.reshape(-1,paths).mean(axis=1),wd.reshape(-1,paths).mean(axis=1),survival.reshape(-1,paths).mean(axis=1)])
        ahead = pd.to_numeric(x.mw_ahead,errors='coerce').to_numpy()
        rate = pd.to_numeric(x.withdraw_rate,errors='coerce').to_numpy()
        ai = np.searchsorted(ahead_edges,np.log1p(np.nan_to_num(ahead,nan=0).clip(min=0)),side='right')
        wi = np.searchsorted(withdraw_edges,np.nan_to_num(rate,nan=0),side='right')
        group = 3*ai+wi; sampled = np.empty((n,4))
        for k in range(9):
            mask = group==k; sampled[mask] = changes[rng.choice(pools[k],size=int(mask.sum()),replace=True)]
        x['mw_ahead'] = np.expm1(np.clip(np.log1p(ahead)+sampled[:,0],0,np.log1p(2_000_000)))
        x['withdraw_rate'] = np.clip(rate+sampled[:,1],0,1)
        for idx,col in enumerate(['poi_peers','county_peers'],start=2):
            x[col] = np.clip(pd.to_numeric(x[col],errors='coerce').to_numpy()+sampled[:,idx],0,None)
        x['age_quarters'] = x.age_quarters+1
    return out

def metric(y, p, event_name='ia'):
    return {'n':len(y),event_name+'_events':int(np.sum(y)),'observed_'+event_name:float(np.mean(y)),
            'predicted_'+event_name:float(np.mean(p)), 'brier':float(brier_score_loss(y,p)),
            'log_loss':float(log_loss(y,p,labels=[0,1])),
            'auc':float(roc_auc_score(y,p)) if len(np.unique(y))==2 else None}

def main():
    d,excluded = prepare(ROOT/'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    data = d[d.observed & (d.quarter >= pd.Period('2013Q1'))]
    last = d.groupby('project_id').quarter.max()
    result = {'method':'Bootstrap prior within-project quarterly queue-feature changes, grouped by congestion and withdrawal-rate thirds; age advances; project attributes otherwise frozen.',
              'paths_per_project':32,'seed':42,'excluded_undated_projects':excluded,
              'warning':'Research only. Past values can include retrospective revisions. These origins were previously inspected; this is not an untouched final test. Bootstrap paths are not full joint queue simulations.',
              'origins':{}}
    for year in range(2016,2021):
        origin = pd.Period(f'{year}Q1'); before = data[data.quarter < origin]
        start = d[d.quarter == origin].copy(); t = transitions(d,origin)
        m = model('gradient_boosting'); m.fit(before[NUM+CAT],before.target)
        fixed = curve(m,start); dynamic = simulate(m,start,t)
        cohort = {'projects':len(start),'past_transition_pairs':len(t),'horizons':{}}
        if year == 2020:
            repeat = simulate(m,start,t,seed=99)
            cohort['seed_sensitivity'] = {}
            for q in ('4','12','20'):
                delta = np.abs(dynamic[q][:,0]-repeat[q][:,0])
                cohort['seed_sensitivity'][str(int(q)//4)] = {
                    'mean_absolute_ia_difference':float(delta.mean()),
                    'p95_absolute_ia_difference':float(np.quantile(delta,.95)),
                    'max_absolute_ia_difference':float(delta.max())}
        for q in (4,12,20):
            if origin+q-1 > d.quarter.max(): continue
            end=(origin+q-1).end_time.normalize(); ia=start.ia_date_lbnl; wd=start.withdrawal_date_lbnl
            event = ia.notna() & (ia<=end) & (wd.isna() | (ia<wd))
            withdraw = wd.notna() & (wd<=end) & (ia.isna() | (wd<ia))
            resolved = (ia.notna() & (ia<=end)) | (wd.notna() & (wd<=end))
            mature = resolved | (start.project_id.map(last)>=origin+q-1)
            mask = mature.to_numpy(); actual=event[mature].astype(int).to_numpy()
            wd_actual = withdraw[mature].astype(int).to_numpy()
            cohort['horizons'][str(q//4)]={'fixed':metric(actual,fixed[str(q)][mask,0]),'simulated':metric(actual,dynamic[str(q)][mask,0]),
                                             'withdrawal_fixed':metric(wd_actual,fixed[str(q)][mask,1],'withdrawal'),
                                             'withdrawal_simulated':metric(wd_actual,dynamic[str(q)][mask,1],'withdrawal'),
                                             'excluded_incomplete_followup':int((~mature).sum())}
        for probabilities in dynamic.values():
            assert np.allclose(probabilities.sum(axis=1),1,atol=1e-8)
        assert np.all(dynamic['4'][:,0] <= dynamic['12'][:,0]+1e-10)
        assert np.all(dynamic['12'][:,0] <= dynamic['20'][:,0]+1e-10)
        result['origins'][str(year)]=cohort
        print(f'{year}: {len(start)} projects, {len(t)} historical transitions',flush=True)
    (HERE/'simulation_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
