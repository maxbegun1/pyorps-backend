"""Check whether 128 paths reduce seed-driven variation for 2020 projects."""
import json
import numpy as np
import pandas as pd
from train import ROOT,HERE,NUM,CAT,prepare,model
from simulate_queue import transitions,simulate

def main():
    d,_=prepare(ROOT/'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    origin=pd.Period('2020Q1'); data=d[d.observed & (d.quarter>=pd.Period('2013Q1')) & (d.quarter<origin)]
    cohort=d[d.quarter==origin].copy(); t=transitions(d,origin)
    m=model('gradient_boosting'); m.fit(data[NUM+CAT],data.target)
    out={'origin':'2020Q1','projects':len(cohort),'warning':'Two seeds are a diagnostic, not an uncertainty interval or independent validation.','paths':{}}
    for paths in (32,128):
        a=simulate(m,cohort,t,paths=paths,seed=42); b=simulate(m,cohort,t,paths=paths,seed=99)
        out['paths'][str(paths)]={}
        for q in ('4','12','20'):
            diff=np.abs(a[q][:,0]-b[q][:,0]); out['paths'][str(paths)][str(int(q)//4)]={
                'mean_absolute_difference':float(diff.mean()),'p95_absolute_difference':float(np.quantile(diff,.95)),
                'max_absolute_difference':float(diff.max()),'mean_prediction_seed_42':float(a[q][:,0].mean()),
                'mean_prediction_seed_99':float(b[q][:,0].mean())}
        print(paths,'paths complete',flush=True)
    (HERE/'path_sensitivity_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
