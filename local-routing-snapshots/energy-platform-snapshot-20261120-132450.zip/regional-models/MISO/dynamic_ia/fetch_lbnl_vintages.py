"""Download public LBNL archived workbooks; run audit_lbnl_vintages.py next."""
from urllib.request import urlretrieve
from train import HERE

SOURCES = {
    'queues_2023.xlsx':'https://eta-publications.lbl.gov/sites/default/files/queues_2023_clean_data_r1.xlsx',
    'queues_2024_v2.xlsx':'https://eta-publications.lbl.gov/sites/default/files/2025-08/lbnl_ix_queue_data_file_thru2024_v2.xlsx',
}
if __name__=='__main__':
    folder=HERE/'lbnl_vintages'; folder.mkdir(exist_ok=True)
    for name,url in SOURCES.items():
        urlretrieve(url,folder/name)
        print('Downloaded',name)
