"""Common study-cohort innovations from documented comparable queue snapshots."""
import numpy as np
import pandas as pd

def cohort_transitions(snapshots, as_of, min_days=60, max_days=120):
    """Quarter-like cohort changes, available by as_of, with no invented history.

    Each input must be a complete snapshot for the stated region and date.
    Missing cohort IDs are excluded; callers must not label partial files complete.
    """
    s=snapshots.copy()
    if not s['full_snapshot'].eq(True).all(): raise ValueError('Cohort process needs complete snapshots')
    for c in ['observed_at','available_at']: s[c]=pd.to_datetime(s[c],errors='raise')
    if s.duplicated(['region','project_id','observed_at','available_at']).any():
        raise ValueError('Ambiguous project records within a snapshot')
    s=s[(s.observed_at<=pd.Timestamp(as_of)) & (s.available_at<=pd.Timestamp(as_of))]
    s=s[s.cohort_id.notna() & s.cohort_id.astype(str).str.strip().ne('')]
    s=s.copy()
    s['active']=s.status.astype(str).str.lower().isin(['active','pending transfer','pending revision approval'])
    s['mw']=pd.to_numeric(s.mw,errors='coerce')
    s['active_mw']=s.mw.where(s.active,0)
    counts=(s.groupby(['region','cohort_id','observed_at','available_at'],as_index=False)
              .agg(active_projects=('active','sum'),active_mw=('active_mw',lambda x:x.sum(min_count=1))))
    counts=counts.sort_values(['region','cohort_id','observed_at'])
    group=counts.groupby(['region','cohort_id'])
    counts['previous_date']=group.observed_at.shift(1)
    counts['previous_count']=group.active_projects.shift(1)
    counts['previous_mw']=group.active_mw.shift(1)
    counts['days']=(counts.observed_at-counts.previous_date).dt.days
    counts['project_change']=counts.active_projects-counts.previous_count
    counts['mw_change']=counts.active_mw-counts.previous_mw
    return counts[counts.days.between(min_days,max_days)].copy()

def sample_common_shocks(projects,history,seed=42):
    """Draw one historical cohort shock per target cohort, shared by members."""
    if history.empty: raise ValueError('No documented cohort transitions are available')
    if projects.cohort_id.isna().any() or projects.cohort_id.astype(str).str.strip().eq('').any():
        raise ValueError('Cannot pool projects with missing cohort identities')
    rng=np.random.default_rng(seed); output=projects.copy()
    output['sampled_cohort_project_change']=np.nan; output['sampled_cohort_mw_change']=np.nan
    for (region,cohort),indices in output.groupby(['region','cohort_id']).groups.items():
        choices=history[history.region==region]
        if choices.empty: raise ValueError('No historical transitions for region '+str(region))
        chosen=choices.iloc[rng.integers(len(choices))]
        output.loc[indices,'sampled_cohort_project_change']=chosen.project_change
        output.loc[indices,'sampled_cohort_mw_change']=chosen.mw_change
    return output
