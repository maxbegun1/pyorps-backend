"""Simple competing-risk benchmarks using only earlier observed quarters."""
import json
import numpy as np
import pandas as pd
from train import ROOT,HERE,NUM,CAT,prepare,curve
from simulate_queue import metric

def age_bucket(age):
    return np.searchsorted([4,8,16,32],np.nan_to_num(np.asarray(age,dtype=float),nan=0),side='right')

class EmpiricalHazard:
    def __init__(self,data,use_age=True,prior=20):
        self.use_age=use_age
        labels=data.target.to_numpy(dtype=int)
        self.global_counts=np.bincount(labels,minlength=3).astype(float)
        self.global_probs=(self.global_counts+1)/(self.global_counts.sum()+3)
        self.probs={}
        buckets=age_bucket(data.age_quarters)
        for k in range(5):
            counts=np.bincount(labels[buckets==k],minlength=3).astype(float)
            self.probs[k]=(counts+prior*self.global_probs)/(counts.sum()+prior)
    def predict_proba(self,X):
        if not self.use_age: return np.tile(self.global_probs,(len(X),1))
        return np.array([self.probs[k] for k in age_bucket(X.age_quarters)])

def main():
    d,_=prepare(ROOT/'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    data=d[d.observed & (d.quarter>=pd.Period('2013Q1'))]; last=d.groupby('project_id').quarter.max()
    results={'warning':'Retrospective panel may contain later revisions; not an untouched final test. Pooled rates are quarterly competing-risk transitions, not a constant five-year rate.','origins':{}}
    for year in range(2016,2021):
        origin=pd.Period(f'{year}Q1'); prior=data[data.quarter<origin]; cohort=d[d.quarter==origin].copy()
        forecasts={kind:curve(EmpiricalHazard(prior,use_age=(kind=='age')),cohort) for kind in ['pooled','age']}
        result={}
        for q in (4,12,20):
            if origin+q-1>d.quarter.max(): continue
            end=(origin+q-1).end_time.normalize(); ia=cohort.ia_date_lbnl; wd=cohort.withdrawal_date_lbnl
            event=ia.notna() & (ia<=end) & (wd.isna()|(ia<wd))
            resolved=(ia.notna()&(ia<=end)) | (wd.notna()&(wd<=end))
            mature=resolved | (cohort.project_id.map(last)>=origin+q-1)
            mask=mature.to_numpy(); y=event[mature].astype(int).to_numpy()
            result[str(q//4)]={kind:metric(y,forecasts[kind][str(q)][mask,0]) for kind in forecasts}
        results['origins'][str(year)]=result
    (HERE/'baseline_results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results,indent=2))
if __name__=='__main__': main()
