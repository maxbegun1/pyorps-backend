"""Compare joint quarterly recalibration on a strictly earlier time window."""
import json
import numpy as np
import pandas as pd
from train import ROOT,HERE,NUM,CAT,prepare,model
from simulate_queue import transitions,simulate,metric
from joint_calibration import fit_joint

def main():
    d,_=prepare(ROOT/'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    data=d[d.observed & (d.quarter>=pd.Period('2013Q1'))]
    last=d.groupby('project_id').quarter.max()
    out={'warning':'Exploratory and not untouched: origin years have been inspected; source attributes can be retrospective. Base model is fitted before the calibration window and is not refitted afterward.',
         'paths_per_project':64,'origins':{}}
    for year in (2018,2019,2020):
        origin=pd.Period(f'{year}Q1'); cal_start=origin-8
        train=data[data.quarter<cal_start]
        cal=data[(data.quarter>=cal_start)&(data.quarter<origin)]
        m=model('gradient_boosting'); m.fit(train[NUM+CAT],train.target)
        adjusted=fit_joint(m,cal[NUM+CAT],cal.target,cal.project_id)
        cohort=d[d.quarter==origin].copy(); history=transitions(d,origin)
        raw=simulate(m,cohort,history,paths=64,seed=42)
        updated=simulate(adjusted,cohort,history,paths=64,seed=42)
        entry={'fit_rows':len(train),'calibration_rows':len(cal),'calibration_projects':cal.project_id.nunique(),
               'calibration_ia_events':int((cal.target==2).sum()),'calibration_withdrawals':int((cal.target==1).sum()),
               'logit_offsets':adjusted.offsets.tolist(),'horizons':{}}
        for q in (4,12,20):
            if origin+q-1>d.quarter.max(): continue
            end=(origin+q-1).end_time.normalize(); ia=cohort.ia_date_lbnl; wd=cohort.withdrawal_date_lbnl
            ia_event=ia.notna() & (ia<=end) & (wd.isna() | (ia<wd))
            wd_event=wd.notna() & (wd<=end) & (ia.isna() | (wd<ia))
            resolved=(ia.notna() & (ia<=end)) | (wd.notna() & (wd<=end))
            mature=resolved | (cohort.project_id.map(last)>=origin+q-1)
            mask=mature.to_numpy(); ia_y=ia_event[mature].astype(int).to_numpy(); wd_y=wd_event[mature].astype(int).to_numpy()
            entry['horizons'][str(q//4)]={'uncalibrated_ia':metric(ia_y,raw[str(q)][mask,0]),
                'calibrated_ia':metric(ia_y,updated[str(q)][mask,0]),
                'uncalibrated_withdrawal':metric(wd_y,raw[str(q)][mask,1],'withdrawal'),
                'calibrated_withdrawal':metric(wd_y,updated[str(q)][mask,1],'withdrawal')}
        for p in updated.values(): assert np.allclose(p.sum(axis=1),1)
        assert np.all(updated['4'][:,0]<=updated['12'][:,0]+1e-10)
        assert np.all(updated['12'][:,0]<=updated['20'][:,0]+1e-10)
        out['origins'][str(year)]=entry
        print(year,'finished',flush=True)
    (HERE/'joint_calibration_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
