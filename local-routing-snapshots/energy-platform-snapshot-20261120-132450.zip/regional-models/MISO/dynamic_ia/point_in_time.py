"""As-of project snapshots, cohort counts and dated policy information.

This module intentionally does not infer missing historical phases or costs.
"""
import json
from pathlib import Path
import pandas as pd

HERE = Path(__file__).resolve().parent

def snapshot_features(requests, snapshots):
    """Latest project and cohort data actually available by the request date.

    A snapshot is known only after both its observation and publication/retrieval
    dates. Cohort counts use the same-region latest available snapshot per peer;
    missing cohort IDs are never pooled. Counts reflect observed records, not
    necessarily all projects in an ISO queue.
    """
    required = {'region','project_id','observed_at','available_at','phase_raw','phase_clean','cohort_id','status','mw'}
    if not required.issubset(snapshots): raise ValueError('Snapshot schema incomplete')
    s = snapshots.copy()
    for c in ['observed_at','available_at']:
        s[c] = pd.to_datetime(s[c],errors='raise')
    s['known_at'] = s[['observed_at','available_at']].max(axis=1)
    if s.duplicated(['region','project_id','known_at','observed_at']).any():
        raise ValueError('Ambiguous snapshots for the same project and time')
    result = []
    for request in requests.to_dict('records'):
        at = pd.Timestamp(request['as_of']); iso = request['region']; pid = str(request['project_id'])
        eligible = s[(s.region == iso) & (s.known_at <= at)].sort_values(['known_at','observed_at'])
        latest = eligible.drop_duplicates(['region','project_id'],keep='last')
        own = latest[latest.project_id.astype(str) == pid]
        row = dict(request); row.update({'phase_raw':None,'phase_clean':None,'cohort_id':None,
                                         'snapshot_known_at':None,'cohort_active_peers':None,'cohort_active_mw_peers':None})
        if not own.empty:
            own = own.iloc[0]; row.update({k:own[k] for k in ['phase_raw','phase_clean','cohort_id']}); row['snapshot_known_at'] = own.known_at
            if pd.notna(own.cohort_id) and str(own.cohort_id).strip():
                peers = latest[(latest.cohort_id == own.cohort_id) &
                               (latest.project_id.astype(str) != pid) &
                               latest.status.astype(str).str.lower().isin(['active','pending transfer','pending revision approval'])]
                row['cohort_active_peers'] = len(peers)
                mw = pd.to_numeric(peers.mw,errors='coerce')
                row['cohort_active_mw_peers'] = float(mw.sum(min_count=1)) if len(peers) else 0.0
        result.append(row)
    return pd.DataFrame(result)

def policy_features(requests, events=None):
    """Calendar markers, not a legal applicability or causal-effect determination."""
    if events is None: events = json.loads((HERE/'policy_events.json').read_text(encoding='utf-8'))
    rows=[]
    for req in requests.to_dict('records'):
        at=pd.Timestamp(req['as_of']); row=dict(req)
        for event in events:
            if event['region'] not in ('ALL',req['region']): continue
            known=pd.Timestamp(event['known_at']); effective=pd.Timestamp(event['event_date'])
            started=max(known,effective)
            row[event['id']+'_known'] = int(at >= known)
            row[event['id']+'_active_known'] = int(at >= started)
            # Once known, duration measures time since the effective/event date,
            # including retroactive effective dates, without revealing them early.
            row[event['id']+'_days_since'] = (at-effective).days if at >= started else None
        rows.append(row)
    return pd.DataFrame(rows)
