"""Jointly recalibrate IA/withdrawal quarterly hazards using a past time window."""
import numpy as np
from scipy.optimize import minimize
from scipy.special import softmax

class JointCalibrator:
    def __init__(self, base, offsets):
        self.base = base
        self.offsets = np.asarray(offsets,dtype=float)

    def predict_proba(self, X):
        p = np.clip(self.base.predict_proba(X),1e-12,1)
        return softmax(np.log(p)+self.offsets,axis=1)

def fit_joint(base, X, y, groups, strength=.01):
    y = np.asarray(y,dtype=int)
    if (y==1).sum()<20 or (y==2).sum()<20:
        raise ValueError('Insufficient dated IA and withdrawal events for calibration')
    probabilities=np.clip(base.predict_proba(X),1e-12,1)
    _, inv, counts = np.unique(np.asarray(groups),return_inverse=True,return_counts=True)
    weights=1/counts[inv]; weights=weights/weights.sum()
    def loss(theta):
        p=softmax(np.log(probabilities)+np.array([0,theta[0],theta[1]]),axis=1)
        return float(-np.sum(weights*np.log(p[np.arange(len(y)),y]))+strength*np.sum(theta**2))
    fit=minimize(loss,[0.,0.],method='BFGS')
    if not fit.success and np.linalg.norm(fit.jac)>1e-4: raise RuntimeError('Calibration did not converge')
    return JointCalibrator(base,[0,fit.x[0],fit.x[1]])
