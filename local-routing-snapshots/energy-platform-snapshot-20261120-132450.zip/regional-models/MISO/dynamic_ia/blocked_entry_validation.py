"""Retrospective entry-year blocks. Future training data make this non-prospective."""
import json
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from train import ROOT,HERE,prepare
from simulate_queue import metric

NUM=['age_quarters','project_mw']; CAT=['state','type_clean','service']; FEATURES=NUM+CAT

def split_block(d, year):
    entry=pd.to_datetime(d.q_date,errors='coerce').dt.year
    # Embargo the projects entering in the target year and both adjacent years,
    # and also embargo all other project-quarters observed in those years.
    train=(~entry.between(year-1,year+1)) & (~d.quarter.dt.year.between(year-1,year+1)) & entry.notna()
    validation=entry.eq(year)
    return train,validation

def build_model(kind):
    prep=ColumnTransformer([('num',make_pipeline(SimpleImputer(strategy='median',add_indicator=True),StandardScaler()),NUM),('cat',OneHotEncoder(handle_unknown='ignore',sparse_output=False),CAT)])
    classifier=(LogisticRegression(max_iter=500) if kind=='logistic' else HistGradientBoostingClassifier(max_iter=80,max_leaf_nodes=10,l2_regularization=20,random_state=42))
    return make_pipeline(prep,classifier)

def predict_curves(m,origin):
    x=origin[FEATURES].copy(); n=len(x); s=np.ones(n); ia=np.zeros(n); wd=np.zeros(n); out={}
    for q in range(1,21):
        p=m.predict_proba(x); ia+=s*p[:,2];wd+=s*p[:,1];s*=p[:,0]
        if q in (4,12,20):out[q]=np.column_stack((ia.copy(),wd.copy(),s.copy()))
        x['age_quarters']+=1
    return out

def main():
    d,excluded=prepare(ROOT/'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    eligible=d[d.observed].copy(); last=d.groupby('project_id').quarter.max()
    result={'purpose':'Retrospective comparison, not a forecast historically available at entry. Model training includes observations after the test years.',
            'warning':'Historical features and eligibility may reflect later corrections. At entry only; excludes undated outcomes and projects without sufficient follow-up for evaluation. No cost inputs.',
            'excluded_undated_projects':excluded,'origins':{}}
    for year in [2005, *range(2016,2021)]:
        trainmask,valmask=split_block(eligible,year)
        train=eligible[trainmask]; valid=eligible[valmask].sort_values(['project_id','observation_date']).drop_duplicates('project_id')
        train_ids=set(train.project_id); assert not (train_ids & set(valid.project_id))
        assert not train.quarter.dt.year.between(year-1,year+1).any()
        entry={'training_rows':len(train),'training_projects':train.project_id.nunique(),'validation_projects':len(valid),'models':{}}
        for kind in ['logistic','gradient_boosting']:
            m=build_model(kind);m.fit(train[FEATURES],train.target)
            curves=predict_curves(m,valid); horizons={}
            for q in (4,12,20):
                end=valid.quarter+q-1
                mature=(end<=d.quarter.max()) & ((valid.project_id.map(last)>=end) | (valid.ia_date_lbnl.notna() & (valid.ia_date_lbnl<=end.dt.end_time.dt.normalize())) | (valid.withdrawal_date_lbnl.notna() & (valid.withdrawal_date_lbnl<=end.dt.end_time.dt.normalize())))
                cutoff=end.dt.end_time.dt.normalize(); actual=valid.ia_date_lbnl.notna() & (valid.ia_date_lbnl<=cutoff) & (valid.withdrawal_date_lbnl.isna() | (valid.ia_date_lbnl<valid.withdrawal_date_lbnl))
                if mature.sum(): horizons[str(q//4)]=metric(actual[mature].astype(int).to_numpy(),curves[q][mature.to_numpy(),0])
            entry['models'][kind]=horizons
        result['origins'][str(year)]=entry
        print(year,'complete',flush=True)
    (HERE/'blocked_entry_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
