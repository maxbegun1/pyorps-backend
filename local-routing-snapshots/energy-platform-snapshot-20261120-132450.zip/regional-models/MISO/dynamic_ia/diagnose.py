"""Rolling-origin research diagnostics. Retrospective updates are not deployable predictions."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss
from train import ROOT, HERE, NUM, CAT, curve, model, prepare

def logit(p):
    p = np.clip(p, .00001, .99999)
    return np.log(p / (1 - p)).reshape(-1, 1)

def main():
    d, _ = prepare(ROOT / 'regional_models/MISO/data/MISO_panel_operational_ready.csv')
    data = d[d.observed & (d.quarter >= pd.Period('2013Q1'))]
    last = d.groupby('project_id').quarter.max()
    runs = []
    annual = []
    for year in range(2015, 2021):
        origin = pd.Period(f'{year}Q1'); prior = data[data.quarter < origin]
        start = d[d.quarter == origin].copy()
        if not len(start): continue
        m = model('gradient_boosting'); m.fit(prior[NUM+CAT], prior.target)
        predictions = curve(m, start)
        for q in (4,12,20):
            end = origin + q - 1
            if end > d.quarter.max(): continue
            ia, wd = start.ia_date_lbnl, start.withdrawal_date_lbnl
            cutoff = end.end_time.normalize()
            outcome = ia.notna() & (ia <= cutoff) & (wd.isna() | (ia < wd))
            resolved = (ia.notna() & (ia <= cutoff)) | (wd.notna() & (wd <= cutoff))
            mature = resolved | (start.project_id.map(last) >= end)
            for i in np.flatnonzero(mature.to_numpy()):
                runs.append({'origin': year, 'horizon': q//4, 'id': str(start.iloc[i].project_id),
                             'prediction': float(predictions[str(q)][i,0]), 'outcome': int(outcome.iloc[i])})
        # Measure one-quarter predictions using the actual features available in each
        # subsequent quarter among that quarter's survivors. This is diagnostic only.
        if year == 2020:
            for offset in range(5):
                a, b = origin + offset*4, origin + offset*4 + 3
                subset = data[(data.project_id.isin(start.project_id)) & data.quarter.between(a,b)]
                p = m.predict_proba(subset[NUM+CAT])
                frozen = subset[['project_id', 'quarter']].merge(start[['project_id']+NUM+CAT], on='project_id', how='left')
                elapsed = (frozen.quarter.dt.year - year) * 4 + frozen.quarter.dt.quarter - 1
                frozen['age_quarters'] = frozen.age_quarters + elapsed
                frozen_p = m.predict_proba(frozen[NUM+CAT])
                annual.append({'year_after_origin': offset+1, 'quarters': len(subset),
                               'observed_ia_hazard': float((subset.target == 2).mean()),
                               'predicted_ia_hazard_using_observed_features': float(p[:,2].mean()),
                               'predicted_ia_hazard_using_frozen_features': float(frozen_p[:,2].mean()),
                               'observed_withdrawal_hazard': float((subset.target == 1).mean()),
                               'predicted_withdrawal_hazard_using_observed_features': float(p[:,1].mean()),
                               'predicted_withdrawal_hazard_using_frozen_features': float(frozen_p[:,1].mean()),
                               'mean_withdraw_rate_feature': float(subset.withdraw_rate.mean()),
                               'mean_mw_ahead': float(subset.mw_ahead.mean())})
    results = pd.DataFrame(runs)
    out = {'caveats': 'Exploratory; latest snapshots may leak information. Future features used in annual diagnostics are not known at the origin. Calibration fitted only to forecasts whose full horizon had elapsed before the target origin.',
           'yearly_survivor_diagnostics_2020': annual, 'calibration': []}
    for (year,horizon), test in results.groupby(['origin','horizon']):
        base = {'origin': int(year), 'horizon': int(horizon), 'n': len(test),
                'observed': float(test.outcome.mean()), 'predicted': float(test.prediction.mean()),
                'brier': float(brier_score_loss(test.outcome,test.prediction)),
                'log_loss': float(log_loss(test.outcome,test.prediction,labels=[0,1]))}
        calibration = results[(results.horizon == horizon) & (results.origin + horizon <= year)]
        if len(calibration) >= 100 and calibration.outcome.nunique() == 2:
            cal = LogisticRegression(C=1e6, max_iter=1000)
            cal.fit(logit(calibration.prediction.to_numpy()), calibration.outcome)
            p = cal.predict_proba(logit(test.prediction.to_numpy()))[:,1]
            base.update({'calibration_projects': len(calibration), 'calibrated_mean': float(p.mean()),
                         'calibrated_brier': float(brier_score_loss(test.outcome,p)),
                         'calibrated_log_loss': float(log_loss(test.outcome,p,labels=[0,1]))})
        out['calibration'].append(base)
    (HERE / 'diagnostics.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__ == '__main__': main()
