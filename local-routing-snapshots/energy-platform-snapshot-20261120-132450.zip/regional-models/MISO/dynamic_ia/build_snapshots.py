"""Build documented snapshot observations; dates are retrieval dates, not histories."""
import hashlib
import json
from pathlib import Path
import pandas as pd
import openpyxl
from train import ROOT, HERE

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    source = ROOT/'withdrawal_research/source_refresh'
    audit = json.loads((source/'miso_audit.json').read_text())
    path = source/'inputs/MISO_queue_2026-11-02.csv'
    if digest(path) != audit['sha256']: raise ValueError('MISO source checksum mismatch')
    data = pd.read_csv(path,low_memory=False,dtype={'Project #':str})
    s = pd.DataFrame({'region':'MISO','project_id':data['Project #'].str.strip(),
        'observed_at':audit['retrieved'],'available_at':audit['retrieved'],
        'phase_raw':data['Study Phase'],'phase_clean':None,
        'cohort_id':data['Study Cycle'].fillna('').str.strip()+' | '+data['Study Group'].fillna('').str.strip(),
        'status':data['Request Status'],'mw':pd.to_numeric(data['Summer MW'],errors='coerce'),
        'source':'MISO interactive queue snapshot 2026-11-02'})
    # Both study cycle and study group are needed for the precise cohort identity.
    s.loc[data['Study Cycle'].isna() | data['Study Group'].isna(),'cohort_id'] = None
    s = s[s.project_id.notna() & s.project_id.ne('') & ~s.project_id.duplicated(keep=False)].copy()
    # NYISO's study availability is not equivalent to a dated study phase.
    ny_audit = json.loads((source/'nyiso_audit.json').read_text())
    for filename, date in [('NYISO_queue_2024-01-31.xlsx','2024-01-31'),('NYISO_queue_snapshot.xlsx','2026-11-02')]:
        path = source/'inputs'/filename
        if digest(path) != ny_audit['source_sha256'][filename]: raise ValueError('NYISO source checksum mismatch')
        w=openpyxl.load_workbook(path,read_only=True,data_only=True)
        records=[]
        for sheet,status in [('Interconnection Queue','active'),(' Cluster Projects','active'),('Withdrawn','withdrawn'),('Cluster Projects-Withdrawn','withdrawn'),('In Service','in_service')]:
            if sheet not in w: continue
            it=w[sheet].values; header=next(it); names={str(x).strip():i for i,x in enumerate(header) if x is not None}
            if sheet=='In Service' and header[0]=='Queue':
                next(it); index=0
            else:
                if 'Queue Pos.' not in names:
                    header=next(it); names={str(x).strip():i for i,x in enumerate(header) if x is not None}
                if 'Queue Pos.' not in names: raise ValueError('Unrecognized NYISO snapshot layout')
                index=names['Queue Pos.']
            for row in it:
                q=row[index]
                if q is None: continue
                # We have not verified when this older extract was published; use
                # the documented source-refresh date, never assume availability.
                records.append({'region':'NYISO','project_id':str(q).strip(),'observed_at':date,'available_at':'2026-11-02',
                    'phase_raw':None,'phase_clean':None,
                    'cohort_id':'NYISO-C24' if 'Cluster Projects' in sheet and str(q).strip().upper().startswith('C24-') else None,
                    'status':status,'mw':None,'source':filename})
        n=pd.DataFrame(records)
        n=n[n.project_id.ne('') & ~n.project_id.duplicated(keep=False)]
        s=pd.concat([s,n],ignore_index=True)
    out=HERE/'documented_snapshots.csv'; s.to_csv(out,index=False)
    print(s.groupby(['region','observed_at']).size().to_string())
    print('MISO observed phase:',int(s.loc[s.region.eq('MISO'),'phase_raw'].notna().sum()))
    print('MISO cohort:',int(s.loc[s.region.eq('MISO'),'cohort_id'].notna().sum()))

if __name__=='__main__': main()
