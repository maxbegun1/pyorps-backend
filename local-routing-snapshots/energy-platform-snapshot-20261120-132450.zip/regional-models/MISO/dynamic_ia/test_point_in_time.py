import unittest
import numpy as np
import pandas as pd
from point_in_time import snapshot_features, policy_features
from joint_calibration import JointCalibrator
from cohort_process import cohort_transitions, sample_common_shocks

class FakeModel:
    def predict_proba(self,X): return np.tile([.7,.2,.1],(len(X),1))

class PointInTimeTests(unittest.TestCase):
    def test_snapshots_require_observation_and_availability(self):
        def row(pid,obs,available,phase,cohort):
            return dict(region='MISO',project_id=pid,observed_at=obs,available_at=available,
                        phase_raw=phase,phase_clean=phase,cohort_id=cohort,status='Active',mw=100)
        snapshots=pd.DataFrame([row('A','2020-01-01','2020-01-01','Study','C1'),
                                row('B','2020-01-01','2020-01-01','Study','C1'),
                                row('A','2020-02-01','2020-03-01','GIA','C1'),
                                row('C','2020-01-01','2020-01-01','Study',None)])
        requests=pd.DataFrame([dict(region='MISO',project_id='A',as_of='2020-02-15'),
                               dict(region='MISO',project_id='A',as_of='2020-03-02'),
                               dict(region='MISO',project_id='C',as_of='2020-03-02')])
        out=snapshot_features(requests,snapshots)
        self.assertEqual(out.phase_raw.tolist(),['Study','GIA','Study'])
        self.assertEqual(out.loc[0,'cohort_active_peers'],1)
        self.assertTrue(pd.isna(out.loc[2,'cohort_active_peers']))

    def test_later_retroactive_policy_is_not_visible_before_decision(self):
        req=pd.DataFrame([dict(region='NYISO',as_of='2024-06-01'),dict(region='NYISO',as_of='2025-04-18')])
        x=policy_features(req)
        self.assertEqual(x.loc[0,'nyiso_2023_transition_proposed_active_known'],1)
        self.assertEqual(x.loc[0,'nyiso_2023_accepted_effective_active_known'],0)
        self.assertEqual(x.loc[1,'nyiso_2023_accepted_effective_active_known'],1)
        self.assertEqual(x.loc[1,'nyiso_2023_accepted_effective_days_since'],351)

    def test_joint_adjustment_is_probability_distribution(self):
        p=JointCalibrator(FakeModel(),[0,.4,-.3]).predict_proba(pd.DataFrame({'x':[1,2]}))
        np.testing.assert_allclose(p.sum(axis=1),1)
        self.assertTrue((p>=0).all())

    def test_cohort_shock_is_shared_and_future_snapshot_excluded(self):
        rows=[]
        for date,status_b in [('2020-01-01','active'),('2020-04-01','withdrawn'),('2020-07-01','withdrawn')]:
            for pid,status in [('A','active'),('B',status_b)]:
                rows.append(dict(region='MISO',cohort_id='C1',project_id=pid,status=status,mw=100,
                                 observed_at=date,available_at=date,full_snapshot=True))
        history=cohort_transitions(pd.DataFrame(rows),'2020-05-01')
        self.assertEqual(len(history),1)
        self.assertEqual(history.iloc[0].project_change,-1)
        target=pd.DataFrame([dict(region='MISO',cohort_id='C2'),dict(region='MISO',cohort_id='C2')])
        shocks=sample_common_shocks(target,history)
        self.assertEqual(shocks.sampled_cohort_project_change.tolist(),[-1.,-1.])

if __name__=='__main__': unittest.main()
