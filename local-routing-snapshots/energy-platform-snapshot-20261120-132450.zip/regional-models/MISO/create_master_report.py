#!/usr/bin/env python3
"""Create the master MISO competing-risks analysis report as a polished DOCX."""

from __future__ import annotations

import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# The bundled document runtime supplies python-docx, while the host analytics
# runtime supplies pandas and matplotlib. Appending keeps the already imported
# analytics stack intact and makes the pure-Python document package available.
DOC_SITE_PACKAGES = Path(
    "/Users/patrickmori/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages"
)
if str(DOC_SITE_PACKAGES) not in sys.path:
    sys.path.append(str(DOC_SITE_PACKAGES))

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_ROW_HEIGHT_RULE, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parent
AUDIT = ROOT / "outputs" / "audit"
MODEL = ROOT / "outputs" / "model"
CHARTS = MODEL / "charts"
ASSETS = ROOT / "doc_assets"
OUTPUT = ROOT / "MISO_Master_Competing_Risks_Report.docx"

NAVY = "1F4E78"
BLUE = "5B9BD5"
PALE_BLUE = "EAF2F8"
LIGHT_BLUE = "D9EAF7"
PALE_GRAY = "F2F2F2"
MID_GRAY = "666666"
DARK = "1F1F1F"
RED = "C00000"
PALE_RED = "FCE4E4"
GREEN = "548235"


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def shade_cell(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=85, start=95, bottom=85, end=95) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for tag, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{tag}"))
        if node is None:
            node = OxmlElement(f"w:{tag}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table, color="D9E2F3", size="4") -> None:
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = borders.find(qn(f"w:{edge}"))
        if tag is None:
            tag = OxmlElement(f"w:{edge}")
            borders.append(tag)
        tag.set(qn("w:val"), "single")
        tag.set(qn("w:sz"), size)
        tag.set(qn("w:color"), color)


def set_fixed_layout(table) -> None:
    tbl_pr = table._tbl.tblPr
    layout = tbl_pr.first_child_found_in("w:tblLayout")
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")


def set_run_font(run, name="Aptos", size=None, bold=None, color=None, italic=None) -> None:
    run.font.name = name
    r_pr = run._element.get_or_add_rPr()
    r_fonts = r_pr.rFonts
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        r_pr.insert(0, r_fonts)
    r_fonts.set(qn("w:ascii"), name)
    r_fonts.set(qn("w:hAnsi"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)
    if italic is not None:
        run.italic = italic


def add_page_field(paragraph) -> None:
    run = paragraph.add_run()
    fld_char_1 = OxmlElement("w:fldChar")
    fld_char_1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char_2 = OxmlElement("w:fldChar")
    fld_char_2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char_1)
    run._r.append(instr_text)
    run._r.append(fld_char_2)


def add_hyperlink(paragraph, text: str, url: str) -> None:
    part = paragraph.part
    rel_id = part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", is_external=True)
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), rel_id)
    new_run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    color = OxmlElement("w:color")
    color.set(qn("w:val"), NAVY)
    underline = OxmlElement("w:u")
    underline.set(qn("w:val"), "single")
    r_pr.append(color)
    r_pr.append(underline)
    new_run.append(r_pr)
    text_node = OxmlElement("w:t")
    text_node.text = text
    new_run.append(text_node)
    hyperlink.append(new_run)
    paragraph._p.append(hyperlink)


def add_paragraph(doc, text="", style=None, bold_lead=None, keep=False, space_after=5):
    p = doc.add_paragraph(style=style)
    if bold_lead and text.startswith(bold_lead):
        r = p.add_run(bold_lead)
        set_run_font(r, bold=True)
        r = p.add_run(text[len(bold_lead):])
        set_run_font(r)
    else:
        r = p.add_run(text)
        set_run_font(r)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.keep_together = keep
    return p


def add_bullets(doc, items, level=0):
    for item in items:
        p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
        r = p.add_run(item)
        set_run_font(r)
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.keep_together = True


def add_numbered(doc, items):
    for number, item in enumerate(items, start=1):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.24)
        p.paragraph_format.first_line_indent = Inches(-0.24)
        r = p.add_run(f"{number}.   {item}")
        set_run_font(r)
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.keep_together = True


def add_note(doc, lead: str, text: str, fill=PALE_BLUE, color=DARK):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.columns[0].width = Inches(6.65)
    cell = table.cell(0, 0)
    shade_cell(cell, fill)
    set_cell_margins(cell, 130, 150, 130, 150)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(lead + " ")
    set_run_font(r, bold=True, color=color)
    r = p.add_run(text)
    set_run_font(r, color=color)
    prevent_row_split(table.rows[0])
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_table(doc, headers, rows, widths=None, aligns=None, font_size=8.5, source=None, cell_margin=85):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_fixed_layout(table)
    set_table_borders(table)
    if widths:
        for i, width in enumerate(widths):
            table.columns[i].width = Inches(width)
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    prevent_row_split(hdr)
    for i, header in enumerate(headers):
        cell = hdr.cells[i]
        shade_cell(cell, NAVY)
        set_cell_margins(cell, top=cell_margin, bottom=cell_margin)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if aligns is None else aligns[i]
        r = p.add_run(str(header))
        set_run_font(r, size=font_size, bold=True, color="FFFFFF")
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for row_idx, values in enumerate(rows):
        cells = table.add_row().cells
        prevent_row_split(table.rows[-1])
        for i, value in enumerate(values):
            cell = cells[i]
            shade_cell(cell, "FFFFFF" if row_idx % 2 == 0 else "F7FAFC")
            set_cell_margins(cell, top=cell_margin, bottom=cell_margin)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.alignment = (aligns[i] if aligns else (WD_ALIGN_PARAGRAPH.RIGHT if isinstance(value, (int, float, np.integer, np.floating)) else WD_ALIGN_PARAGRAPH.LEFT))
            r = p.add_run(str(value))
            set_run_font(r, size=font_size)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if source:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(source)
        set_run_font(r, size=8, italic=True, color=MID_GRAY)
    return table


def add_metric_strip(doc, items):
    table = doc.add_table(rows=1, cols=len(items))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_fixed_layout(table)
    for i, (value, label) in enumerate(items):
        cell = table.cell(0, i)
        shade_cell(cell, PALE_BLUE if i % 2 == 0 else "F4F8FB")
        set_cell_margins(cell, 160, 110, 150, 110)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(value)
        set_run_font(r, size=18, bold=True, color=NAVY)
        p2 = cell.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p2.paragraph_format.space_after = Pt(0)
        r2 = p2.add_run(label)
        set_run_font(r2, size=8.5, color=DARK)
        prevent_row_split(table.rows[0])
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def set_alt_text(inline_shape, title: str, description: str) -> None:
    doc_pr = inline_shape._inline.docPr
    doc_pr.set("title", title)
    doc_pr.set("descr", description)


def add_figure(doc, path: Path, caption: str, alt_text: str, width=6.45, source=None):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    shape = p.add_run().add_picture(str(path), width=Inches(width))
    set_alt_text(shape, caption, alt_text)
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.keep_together = True
    cap.paragraph_format.space_after = Pt(2)
    r = cap.add_run(caption)
    set_run_font(r, size=8.5, bold=True, color=MID_GRAY)
    if source:
        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p2.paragraph_format.space_after = Pt(5)
        r2 = p2.add_run(source)
        set_run_font(r2, size=7.5, italic=True, color=MID_GRAY)


def add_code_block(doc, code: str):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.columns[0].width = Inches(6.6)
    cell = table.cell(0, 0)
    shade_cell(cell, PALE_GRAY)
    set_cell_margins(cell, 110, 130, 110, 130)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    r = p.add_run(code)
    set_run_font(r, name="Consolas", size=7.5, color=DARK)
    prevent_row_split(table.rows[0])
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_before = Pt(8 if level == 1 else 5)
    p.paragraph_format.space_after = Pt(4)
    return p


def page_break(doc):
    doc.add_page_break()


def percent(x, digits=1):
    return f"{100 * float(x):.{digits}f}%"


def make_doc_charts() -> None:
    ASSETS.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.titlesize": 12,
        "axes.labelsize": 9,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "axes.edgecolor": "#666666",
        "grid.color": "#D9D9D9",
    })

    events = pd.read_csv(AUDIT / "events_by_panel_quarter.csv")
    x = np.arange(len(events))
    fig, ax = plt.subplots(figsize=(10.5, 4.6))
    ax.bar(x, events["withdrawals"], color="#5B9BD5", label="Withdrawals", width=0.9)
    ax.bar(x, events["ia_operational"], bottom=events["withdrawals"], color="#70AD47", label="IA or operational", width=0.9)
    spikes = events["spike_flag"].to_numpy(bool)
    ax.scatter(x[spikes], events.loc[spikes, "total_events"] + 12, color="#C00000", s=26, marker="v", label="Audit flagged spike")
    for idx in np.flatnonzero(spikes):
        q = events.iloc[idx]["panel_quarter"]
        if q in {"2003Q2", "2012Q3", "2017Q3", "2023Q1", "2025Q3", "2025Q4"}:
            ax.annotate(q, (idx, events.iloc[idx]["total_events"] + 15), xytext=(0, 7), textcoords="offset points", ha="center", fontsize=7, rotation=45)
    tick_idx = np.linspace(0, len(events) - 1, 10, dtype=int)
    ax.set_xticks(tick_idx, events.iloc[tick_idx]["panel_quarter"], rotation=45, ha="right")
    ax.set_ylabel("Terminal events in quarter")
    ax.set_title("Terminal event counts by panel quarter")
    ax.grid(axis="y", alpha=0.55)
    ax.legend(frameon=False, ncol=3, loc="upper left")
    fig.tight_layout()
    fig.savefig(ASSETS / "event_timeline.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    metrics = pd.read_csv(MODEL / "out_of_time_quarterly_metrics.csv")
    labels = ["Age-only\nbenchmark", "Multinomial\nlogit", "LightGBM"]
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.6))
    for ax, col, title in zip(axes, ["log_loss", "multiclass_brier"], ["Multiclass log loss", "Multiclass Brier score"]):
        vals = metrics[col].to_numpy()
        bars = ax.bar(labels, vals, color=["#A5A5A5", "#1F4E78", "#70AD47"], width=0.62)
        ax.set_title(title)
        ax.set_ylim(0, max(vals) * 1.28)
        ax.grid(axis="y", alpha=0.45)
        for bar, value in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, value + max(vals) * 0.035, f"{value:.3f}", ha="center", fontsize=9)
        ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Out of time predictive performance from 2023Q1 through 2025Q4", y=1.02, fontsize=12)
    fig.tight_layout()
    fig.savefig(ASSETS / "model_comparison.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    sens = pd.read_csv(MODEL / "active_score_sensitivity.csv")
    order = [
        "main_2013plus_all_available",
        "spike_quarters_excluded_all_available",
        "full_history_all_available",
        "prop_date_snapshot_all_available",
    ]
    short = ["Main", "Spikes\nexcluded", "Full\nhistory", "Proposed\ndate"]
    sens = sens.set_index("sensitivity").loc[order]
    h = [4, 8, 12]
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.1), sharex=True)
    colors = ["#1F4E78", "#5B9BD5", "#70AD47"]
    xx = np.arange(len(order))
    width = 0.23
    for ax, event, title in zip(axes, ["withdraw", "ia"], ["Mean withdrawal CIF", "Mean IA CIF"]):
        for j, horizon in enumerate(h):
            values = sens[f"mean_p_{event}_{horizon}q"].to_numpy()
            ax.bar(xx + (j - 1) * width, values, width, label=f"{horizon} quarters", color=colors[j])
        ax.set_xticks(xx, short)
        ax.set_ylim(0, 1.0 if event == "withdraw" else 0.14)
        ax.set_title(title)
        ax.set_ylabel("Cumulative incidence")
        ax.grid(axis="y", alpha=0.45)
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].legend(frameon=False, fontsize=8)
    fig.suptitle("Active project forecasts are highly sensitive to mass withdrawal quarters", y=1.02, fontsize=12)
    fig.tight_layout()
    fig.savefig(ASSETS / "active_sensitivity.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def configure_document(doc: Document) -> None:
    section = doc.sections[0]
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.68)
    section.left_margin = Inches(0.82)
    section.right_margin = Inches(0.82)
    section.header_distance = Inches(0.32)
    section.footer_distance = Inches(0.32)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(10.2)
    normal.element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
    normal.element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    normal.paragraph_format.line_spacing = 1.08

    for name, size, before, after in [("Title", 26, 0, 8), ("Subtitle", 14, 0, 8), ("Heading 1", 17, 10, 5), ("Heading 2", 13, 7, 4), ("Heading 3", 11, 5, 3)]:
        style = styles[name]
        style.font.name = "Aptos Display" if name in {"Title", "Heading 1", "Heading 2"} else "Aptos"
        style.element.rPr.rFonts.set(qn("w:ascii"), style.font.name)
        style.element.rPr.rFonts.set(qn("w:hAnsi"), style.font.name)
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string("000000")
        style.font.bold = name != "Subtitle"
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for list_style in ["List Bullet", "List Bullet 2", "List Number"]:
        styles[list_style].font.name = "Aptos"
        styles[list_style].font.size = Pt(10)
        styles[list_style].element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
        styles[list_style].element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")

    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p.add_run("MISO Interconnection Queue Competing Risks Model")
    set_run_font(r, size=8, color=MID_GRAY)
    footer = section.footer
    t = footer.add_table(rows=1, cols=2, width=Inches(6.8))
    t.columns[0].width = Inches(5.9)
    t.columns[1].width = Inches(0.9)
    p0 = t.cell(0, 0).paragraphs[0]
    r0 = p0.add_run("Prepared for Amplytico   |   October 2026")
    set_run_font(r0, size=7.5, color=MID_GRAY)
    p1 = t.cell(0, 1).paragraphs[0]
    p1.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r1 = p1.add_run("Page ")
    set_run_font(r1, size=7.5, color=MID_GRAY)
    add_page_field(p1)

    doc.core_properties.title = "MISO Interconnection Queue Competing Risks Model"
    doc.core_properties.subject = "Master analysis report for quarterly withdrawal and IA cumulative incidence modeling"
    doc.core_properties.keywords = "MISO, interconnection queue, competing risks, survival analysis, cumulative incidence"


def build_report() -> Path:
    make_doc_charts()
    doc = Document()
    configure_document(doc)

    quarterly = pd.read_csv(MODEL / "out_of_time_quarterly_metrics.csv").set_index("model")
    horizons = pd.read_csv(MODEL / "horizon_metrics.csv")
    cv = pd.read_csv(MODEL / "grouped_cv_summary.csv")
    sens = pd.read_csv(MODEL / "sensitivity_results.csv")
    active_sens = pd.read_csv(MODEL / "active_score_sensitivity.csv")
    scores = pd.read_csv(MODEL / "MISO_active_project_scores.csv")
    missing = pd.read_csv(AUDIT / "missingness.csv")
    spikes = pd.read_csv(AUDIT / "spike_quarters.csv")
    entry = pd.read_csv(AUDIT / "events_by_entry_year.csv")
    aj = pd.read_csv(MODEL / "aalen_johansen_horizons.csv")
    rr = pd.read_csv(MODEL / "logit_relative_risk_ratios.csv")
    shap_w = pd.read_csv(CHARTS / "shap_importance_withdraw.csv")
    shap_i = pd.read_csv(CHARTS / "shap_importance_ia.csv")

    # Cover
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(78)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p.add_run("MISO Interconnection Queue\nCompeting Risks Model")
    set_run_font(r, name="Aptos Display", size=28, bold=True, color="000000")
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(18)
    r = p.add_run("Master analysis report")
    set_run_font(r, name="Aptos Display", size=16, color=NAVY)
    add_metric_strip(doc, [("5,276", "projects audited"), ("52,211", "project quarter rows"), ("1,257", "active projects scored")])
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(35)
    r = p.add_run("Prepared for Amplytico")
    set_run_font(r, size=12, bold=True)
    p = doc.add_paragraph()
    r = p.add_run("MSBA consulting team")
    set_run_font(r, size=11, color=MID_GRAY)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    r = p.add_run("October 20 2026")
    set_run_font(r, size=10.5, color=MID_GRAY)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(65)
    r = p.add_run("Predictive planning analysis   |   Not a causal study")
    set_run_font(r, size=9.5, bold=True, color=RED)
    page_break(doc)

    # Executive summary
    heading(doc, "1 Executive summary", 1)
    add_note(doc, "Bottom line", "The multinomial logit is the preferred model because it beat the age-only benchmark and LightGBM on the genuinely future 2023Q1 to 2025Q4 test. It is useful for ranking and planning scenarios, but the final active-project probabilities are not stable enough for high-stakes decisions because 2025 mass withdrawals dominate the production refit.", fill=PALE_BLUE)
    add_metric_strip(doc, [("0.313", "test log loss"), ("0.150", "test Brier score"), ("0.922", "12 quarter IA concordance"), ("78.0 pp", "4 quarter withdrawal scenario swing")])
    heading(doc, "What decision makers should take away", 2)
    add_bullets(doc, [
        "Use the selected logit to prioritize projects for planner review and to compare risk across the portfolio. Do not interpret any coefficient or SHAP ranking as a causal effect.",
        "The model discriminates IA outcomes well: the 12-quarter IA concordance is 0.922. However, it predicts a 7.6% mean IA CIF where 14.8% was observed, so ranking is stronger than absolute probability calibration.",
        "Withdrawal prediction is most useful at short horizons. Concordance falls from 0.672 at four quarters to 0.574 at 12 quarters as administrative shocks overwhelm stable project characteristics.",
        "The live main refit assigns an 86.1% mean four-quarter withdrawal probability, but the same calculation falls to 8.1% when statistically flagged spike quarters are excluded. Present both as stress scenarios; do not present 86.1% as a precise base case.",
        "Queue-backlog features such as MW ahead and local active counts describe queue congestion. They do not measure physical transmission congestion.",
    ])
    heading(doc, "Recommended operating policy", 2)
    add_numbered(doc, [
        "Use risk bands or ranks for triage rather than hard yes or no decisions.",
        "Publish a main and spike-excluded scenario together until post-2025 behavior establishes a new baseline.",
        "Refresh features and scores quarterly; frozen congestion inputs are a forecast necessity, not a statement that the queue will remain unchanged.",
        "Recalibrate probabilities before any customer-facing, financial, or capacity-planning deployment.",
    ])
    page_break(doc)

    # Contents and document guide
    heading(doc, "2 Report guide", 1)
    add_paragraph(doc, "This report combines the data audit, modeling design, out-of-time validation, nonparametric reference analysis, feature interpretation, sensitivity tests, live scoring results, implementation details, and limitations. The complete reproducible code and machine-readable outputs accompany the report.")
    contents = [
        ("3", "Business question and scope"),
        ("4", "Data and audit findings"),
        ("5", "Target construction and leakage controls"),
        ("6", "Modeling and validation design"),
        ("7", "Predictive performance"),
        ("8", "Nonparametric reference results"),
        ("9", "What drives predicted outcomes"),
        ("10", "Sensitivity analysis"),
        ("11", "Active project scoring"),
        ("12", "Planner interpretation and deployment"),
        ("13", "Limitations and recommended enhancements"),
        ("14", "Reproducibility and code"),
        ("Appendix A", "Detailed audit tables"),
        ("Appendix B", "Feature inventory and definitions"),
        ("Appendix C", "References"),
    ]
    add_table(doc, ["Section", "Purpose"], contents, widths=[1.35, 5.2], aligns=[WD_ALIGN_PARAGRAPH.LEFT, WD_ALIGN_PARAGRAPH.LEFT], font_size=9.3)
    heading(doc, "How to read the probability outputs", 2)
    add_paragraph(doc, "A quarterly hazard is the probability of a particular transition during one quarter among projects still at risk at its start. A cumulative incidence function adds those hazards over time while respecting the competing event: a project that reaches IA first can no longer withdraw in this model, and vice versa. Withdrawal CIF plus IA CIF plus the probability of still being in queue equals one at every horizon.")
    add_note(doc, "Interpretation example", "A 20% four-quarter withdrawal CIF means that, under the model and its frozen future feature assumptions, the project has a 20% probability of withdrawing by the end of four quarters before reaching IA. It is not the sum of four independent quarterly probabilities.", fill="F4F8FB")
    page_break(doc)

    # Scope
    heading(doc, "3 Business question and scope", 1)
    heading(doc, "Decision objective", 2)
    add_paragraph(doc, "The model estimates, for every MISO project-quarter, the mutually exclusive probability of staying in queue, withdrawing, or reaching an interconnection agreement or operation during that quarter. Those hazards are converted to project-level withdrawal and IA cumulative incidence at 4, 8, 12, and 20 quarters.")
    heading(doc, "Intended uses", 2)
    add_bullets(doc, [
        "Portfolio triage and targeted planner review",
        "Scenario analysis for queue attrition and IA progression",
        "Identification of segments where predictions are unstable or poorly calibrated",
        "A repeatable baseline for future retraining as new quarters arrive",
    ])
    heading(doc, "Out of scope", 2)
    add_bullets(doc, [
        "Causal claims about FERC rules, queue position, technology, utility, or developer behavior",
        "Physical transmission congestion, deliverability, upgrade cost, or power-flow analysis",
        "A forecast of future queue entries or future local backlog conditions",
        "An independent reconstruction of projects that reached IA and later withdrew after the first recorded terminal event",
    ])
    heading(doc, "Region-specific design choices", 2)
    add_table(doc, ["Issue", "Modeling response", "Reason"], [
        ["Pre-2013 survivorship", "Main model uses entry year 2013 or later", "Older cohorts contain implausibly few withdrawals and bias IA upward"],
        ["IA followed by later withdrawal", "IA is terminal when it occurs first", "Matches the supplied first-event target definition"],
        ["Mass event quarters", "Audit flags spikes and reruns training without them", "Tests dependence on administrative or cycle-level shocks"],
        ["Cluster cycle dependence", "Robustness CV groups by parsed cycle", "Projects in a DPP cycle can resolve together"],
        ["Order 2023 timing", "Indicator begins May 16 2024", "Marks MISO compliance filing timing, not full implementation"],
    ], widths=[1.35, 2.55, 2.75], font_size=8.5)
    page_break(doc)

    # Audit
    heading(doc, "4 Data and audit findings", 1)
    heading(doc, "Audit outcome", 2)
    add_note(doc, "Audit passed", "No blocking structural problem was found, so modeling continued. The panel has consecutive project ages and calendar quarters, at most one terminal event per project, no post-event rows, no eligible censored outcomes, and no ineligible non-censored outcomes.", fill="E2F0D9", color=GREEN)
    add_metric_strip(doc, [("52,211", "all panel rows"), ("50,954", "model eligible rows"), ("2,223", "withdrawals"), ("1,796", "IA or operational events")])
    add_table(doc, ["Population", "Rows", "Projects", "Withdrawals", "IA or operational", "Active or censored"], [
        ["Full supplied panel", "52,211", "5,276", "2,223", "1,796", "1,257"],
        ["Main 2013 plus eligible sample", "37,433", "3,978", "2,182", "668", "Not used as outcome rows"],
        ["Pre-2023 training period", "18,372", "2,907", "907", "417", "Not applicable"],
        ["2023Q1 to 2025Q4 test period", "19,061", "2,654", "1,275", "251", "Not applicable"],
    ], widths=[1.55, .8, .8, 1.0, 1.2, 1.25], font_size=8.2, source="Source: audit_summary.json and model evaluation outputs. Project counts can overlap between time periods because projects span quarters.")
    heading(doc, "Missingness and usability", 2)
    key_missing = missing[missing["column"].isin(["prop_date", "state", "county", "fips_code", "poi_name", "utility", "cluster", "service", "type_2", "project_mw"])]
    rows = [[r.column, f"{int(r.missing_rows):,}", percent(r.missing_pct), ("Sensitivity only" if r.column == "prop_date" else "Usable with explicit missing handling")] for r in key_missing.itertuples()]
    add_table(doc, ["Field", "Missing rows", "Missing", "Treatment"], rows, widths=[1.35, 1.1, .85, 3.25], font_size=8.4)
    add_paragraph(doc, "Utility and service are each about one-third missing and are retained with an explicit Missing category. Cluster is 19.4% missing and is parsed into DPP cycle year and subregion where possible. Type 2 is 90.7% missing, so it contributes only through a conservative hybrid or storage flag. Developer is not present in the supplied MISO file.")
    page_break(doc)

    heading(doc, "Event timing and spikes", 2)
    add_figure(doc, ASSETS / "event_timeline.png", "Figure 1  Terminal event counts and audit flagged spike quarters", "Stacked quarterly bars show withdrawal and IA terminal event counts from 1998Q4 through 2025Q4. Red triangles mark audit-flagged event spikes, including 2017Q3, 2023Q1, 2025Q3, and 2025Q4.", width=6.5, source="Source: events_by_panel_quarter.csv")
    add_paragraph(doc, "The two largest withdrawal spikes occur at the end of the sample: 429 withdrawals in 2025Q3 and 422 in 2025Q4. Together they account for 38.3% of all withdrawals in the full file. This concentration is the central reason the final active-project probabilities are unstable.")
    spike_rows = []
    for r in spikes.itertuples():
        spike_rows.append([r.panel_quarter, f"{r.at_risk_rows:,}", f"{r.withdrawals:,}", f"{r.ia_operational:,}", percent(r.event_rate)])
    add_table(doc, ["Quarter", "At risk", "Withdrawals", "IA or operational", "Total event rate"], spike_rows, widths=[1.0, 1.0, 1.25, 1.55, 1.35], font_size=8.1, source="Flagging uses robust deviations in event counts or event rates. A spike is a diagnostic signal, not proof of a particular administrative cause.")
    heading(doc, "Age pattern", 2)
    add_paragraph(doc, "Terminal events are not evenly distributed across queue age. The largest raw event counts occur at ages 13, 6, 7, 14, and 3 quarters. That nonlinearity motivates splines in the logit and the raw age variable in LightGBM rather than a single linear age coefficient.")
    page_break(doc)

    # Target and leakage
    heading(doc, "5 Target construction and leakage controls", 1)
    heading(doc, "Target and estimation sample", 2)
    add_table(doc, ["Code", "Outcome", "Meaning in a project quarter"], [
        ["0", "Stay", "Project remains at risk after the quarter"],
        ["1", "Withdraw", "Withdrawal is the first terminal transition"],
        ["2", "IA or operational", "IA or operation is the first terminal transition"],
    ], widths=[.7, 1.65, 4.0], font_size=9)
    add_paragraph(doc, "Only rows with model_eligible equal to TRUE enter estimation. The one final censored row for each currently active project is held out and used only as the scoring origin. The main model also requires q_year of 2013 or later.")
    heading(doc, "Strict leakage exclusions", 2)
    add_bullets(doc, [
        "Never used as predictors: project_id, transition_outcome, model_eligible, and audit_wd_date_proxy_flag.",
        "panel_quarter is not one-hot encoded in the predictive model because future quarters would be unseen categories. Calendar time is used only to construct the train-test split, lagged aggregates, and the explanatory regime label.",
        "Proposed online date is excluded from the baseline because it is a 2025 snapshot that developers revise. It appears only in a labeled sensitivity model.",
        "POI and county active-project counts are measured immediately before the quarter begins, so an event in the target quarter cannot change its own predictor.",
        "The regional withdrawal rate uses only the prior four completed quarters and is shifted at least one quarter.",
    ])
    heading(doc, "Feature construction", 2)
    add_table(doc, ["Feature family", "Examples", "Treatment"], [
        ["Baseline hazard", "Age in quarters", "Natural spline for logit and raw age for LightGBM"],
        ["Project scale", "log project MW", "Log transform with missing indicator through preprocessing"],
        ["Technology", "type_clean plus hybrid and storage flags", "Rare categories below 2% grouped as Other"],
        ["Queue backlog", "log MW ahead and MW ahead per project MW", "Known at the row observation date"],
        ["Local active set", "POI and county project count and MW", "One-quarter lagged active-set aggregates"],
        ["Recent environment", "prior four-quarter MISO withdrawal rate", "Lagged by one quarter"],
        ["Cluster", "DPP cycle year and subregion", "Parsed from cluster string with Missing retained"],
    ], widths=[1.25, 2.55, 2.75], font_size=8.4)
    add_note(doc, "Snapshot limitation", "Project MW, technology, POI, utility, and related static fields are end-of-period snapshots. They may not equal the information recorded when a project originally entered the queue.", fill=PALE_RED, color=RED)
    page_break(doc)

    # Model design
    heading(doc, "6 Modeling and validation design", 1)
    heading(doc, "Models", 2)
    add_table(doc, ["Model", "Role", "Key details"], [
        ["Age-only hazard", "Naive benchmark", "Training-period event rates by queue age"],
        ["Multinomial logit", "Baseline and selected production model", "L2 regularization, age splines, same leakage-safe predictors"],
        ["LightGBM multiclass", "Nonlinear challenger", "Temperature calibrated from project-grouped out-of-fold predictions"],
        ["Aalen-Johansen", "Nonparametric reference", "Overall and technology-specific cumulative incidence"],
        ["Statsmodels companion", "Inference only", "Compact unpenalized specification with project-clustered standard errors"],
    ], widths=[1.4, 2.0, 3.2], font_size=8.5)
    add_paragraph(doc, "No oversampling or class weighting is used. Either can help classification recall, but it changes the apparent class prevalence and therefore distorts probabilities unless carefully corrected. Probability quality is the primary requirement for hazard-to-CIF conversion.")
    heading(doc, "Validation structure", 2)
    add_numbered(doc, [
        "Primary test: train through 2022Q4 and evaluate only on 2023Q1 through 2025Q4.",
        "Hyperparameter tuning: use grouped folds inside the pre-2023 training period only.",
        "Stability check: five-fold GroupKFold by project so all quarters from a project remain in one fold.",
        "Cluster-cycle robustness: place every project in a parsed DPP cycle in the same fold.",
        "Model selection: LightGBM must improve both out-of-time log loss and Brier score by at least 2%; otherwise prefer logit.",
    ])
    heading(doc, "Chosen hyperparameters", 2)
    add_table(doc, ["Model", "Selected setting"], [
        ["Logit", "Regularization C = 0.1"],
        ["LightGBM", "350 trees, 31 leaves, learning rate 0.04, minimum child size 60"],
        ["LightGBM calibration", "Temperature 1.092 on the pre-2023 fit"],
        ["Random seed", "20261020"],
    ], widths=[1.8, 4.7], font_size=9)
    page_break(doc)

    # Performance
    heading(doc, "7 Predictive performance", 1)
    heading(doc, "Per-quarter out-of-time results", 2)
    add_figure(doc, ASSETS / "model_comparison.png", "Figure 2  Out of time quarterly performance", "Two bar charts compare multiclass log loss and Brier score for the age-only benchmark, multinomial logit, and LightGBM. Lower values are better, and logit is best on both metrics.", width=6.4, source="Source: out_of_time_quarterly_metrics.csv")
    perf_rows = []
    for name, label in [("naive_age", "Age-only benchmark"), ("logit", "Multinomial logit"), ("lightgbm", "LightGBM")]:
        r = quarterly.loc[name]
        perf_rows.append([label, f"{r.log_loss:.3f}", f"{r.multiclass_brier:.3f}", percent(r.mean_pred_withdraw), percent(r.observed_withdraw), percent(r.mean_pred_ia), percent(r.observed_ia)])
    add_table(doc, ["Model", "Log loss", "Brier", "Pred wd", "Obs wd", "Pred IA", "Obs IA"], perf_rows, widths=[1.45, .8, .75, .85, .85, .85, .85], font_size=8.0)
    add_paragraph(doc, "The logit reduces test log loss by 7.0% and Brier score by 4.8% relative to the age-only benchmark. LightGBM performs strongly in pre-2023 grouped cross-validation but does not transport to the later period, where it underpredicts withdrawals severely. This is evidence of distribution shift and favors the more stable logit.")
    heading(doc, "Grouped cross-validation", 2)
    cv_rows = []
    for r in cv.sort_values(["grouping", "model"]).itertuples():
        cv_rows.append(["Cluster cycle" if r.grouping == "cluster_cycle" else "Project", "LightGBM" if r.model == "lightgbm" else "Logit", f"{r.mean_log_loss:.3f}", f"{r.sd_log_loss:.3f}", f"{r.mean_brier:.3f}"])
    add_table(doc, ["Grouping", "Model", "Mean log loss", "SD", "Mean Brier"], cv_rows, widths=[1.3, 1.2, 1.35, .85, 1.25], font_size=8.6)
    add_note(doc, "Interpretation", "Project-grouped CV makes LightGBM look substantially better, but holding out entire cluster cycles removes much of that advantage and increases fold-to-fold variability. Cluster cycles carry shared resolution patterns that ordinary project grouping does not fully isolate.", fill="F4F8FB")
    page_break(doc)

    heading(doc, "Fixed-horizon discrimination and calibration", 2)
    logit_h = horizons[horizons["model"].eq("logit")]
    horizon_rows = []
    for h in [4, 8, 12]:
        for event, short in [("withdraw", "Withdrawal"), ("IA/operational", "IA or operational")]:
            r = logit_h[(logit_h.horizon_quarters == h) & (logit_h.event == event)].iloc[0]
            horizon_rows.append([f"{h} quarters", short, f"{int(r.projects):,}", f"{r.time_dependent_c_index:.3f}", percent(r.mean_predicted_cif), percent(r.observed_cif), f"{100*(r.mean_predicted_cif-r.observed_cif):+.1f} pp"])
    add_table(doc, ["Horizon", "Event", "Projects", "C-index", "Predicted CIF", "Observed CIF", "Error"], horizon_rows, widths=[1.0, 1.5, .8, .8, 1.0, 1.0, .8], font_size=8.1)
    add_bullets(doc, [
        "IA discrimination is consistently strong: C-index ranges from 0.913 to 0.922. The model ranks projects well by IA likelihood.",
        "IA calibration is too low and worsens with horizon: the mean prediction is 7.6% at 12 quarters versus 14.8% observed.",
        "Withdrawal discrimination declines materially with horizon, from 0.672 at four quarters to 0.574 at 12 quarters.",
        "Withdrawal calibration changes direction: the model overpredicts at eight quarters by 6.5 points but underpredicts at 12 quarters by 8.3 points. This pattern is consistent with timing shifts and concentrated later shocks.",
    ])
    add_figure(doc, CHARTS / "calibration_by_decile.png", "Figure 3  Calibration by predicted risk decile", "Calibration panels compare average predicted cumulative incidence with observed incidence by risk decile for withdrawal and IA at 4, 8, and 12 quarters. The 45-degree line represents perfect calibration.", width=6.45, source="Source: calibration_by_decile.csv")
    page_break(doc)

    heading(doc, "Hazard behavior by queue age", 2)
    add_figure(doc, CHARTS / "hazard_by_age.png", "Figure 4  Observed and predicted quarterly hazard by queue age", "Lines compare observed and model-predicted withdrawal and IA hazards across project age in quarters in the 2023Q1 through 2025Q4 test period.", width=6.4, source="Source: model test predictions aggregated by age_quarters")
    add_paragraph(doc, "The age profile is visibly nonlinear and different for the two terminal events. Logit splines allow the baseline hazard to bend across the queue lifecycle without creating a separate coefficient for every age. Remaining deviations at particular ages reflect both limited sample sizes at old ages and cycle-level resolution behavior.")
    add_note(doc, "Practical implication", "A single annualized hazard is not an adequate summary. Project risk changes with queue age, and planners should use horizon-specific CIFs rather than extrapolating a one-quarter probability.", fill="F4F8FB")
    page_break(doc)

    # AJ reference
    heading(doc, "8 Nonparametric reference results", 1)
    add_paragraph(doc, "Aalen-Johansen estimates provide a model-free reference for competing risks. They use observed first terminal events and censoring without conditioning on project characteristics. The reference includes 4,087 projects from entry year 2013 onward, including newly active projects that do not contribute an eligible estimation row.")
    add_figure(doc, CHARTS / "aalen_johansen_cif.png", "Figure 5  Aalen-Johansen cumulative incidence overall and by technology", "Cumulative incidence curves show withdrawal and IA or operational outcomes by queue age for the overall 2013-plus population and the five largest technology groups.", width=6.45, source="Source: aalen_johansen_curves.csv")
    h20 = aj[aj.horizon_quarters.eq(20)]
    rows = [[r.technology, f"{int(r.projects):,}", percent(r.aj_cif_withdraw), percent(r.aj_cif_ia), percent(1-r.aj_cif_withdraw-r.aj_cif_ia)] for r in h20.itertuples()]
    add_table(doc, ["Technology", "Projects", "Withdrawal by 20q", "IA by 20q", "Still at risk by 20q"], rows, widths=[1.5, .85, 1.45, 1.15, 1.45], font_size=8.4)
    add_bullets(doc, [
        "Overall observed cumulative incidence by 20 quarters is 67.3% withdrawal and 23.7% IA.",
        "Battery projects have the highest 20-quarter withdrawal incidence at 82.0% and the lowest IA incidence at 6.5% among the displayed standalone technologies.",
        "Gas has the highest 20-quarter IA incidence at 35.8% and a lower withdrawal incidence than the other displayed groups at 56.4%.",
        "Technology curves are descriptive and can reflect cohort, geography, cycle, service type, and administrative timing. They are not technology treatment effects.",
    ])
    page_break(doc)

    # Drivers
    heading(doc, "9 What drives predicted outcomes", 1)
    add_note(doc, "Interpretation boundary", "Feature importance and relative-risk ratios describe associations used for prediction. They do not show what would happen if a developer, utility, or regulator changed a feature.", fill=PALE_RED, color=RED)
    heading(doc, "Withdrawal model", 2)
    add_figure(doc, CHARTS / "shap_summary_withdraw.png", "Figure 6  LightGBM feature importance for withdrawal", "Horizontal bars rank withdrawal predictors by mean absolute SHAP value in the out-of-time test. Cluster cycle year, queued MW ahead, entry cohort, recent withdrawal rate, and queue age rank highest.", width=6.25, source="Source: shap_importance_withdraw.csv")
    w_rows = [[str(i+1), r.feature.replace("num__", "").replace("cat__", "").replace("_", " "), f"{r.mean_abs_shap:.3f}"] for i, r in enumerate(shap_w.head(8).itertuples())]
    add_table(doc, ["Rank", "Predictor", "Mean absolute SHAP"], w_rows, widths=[.7, 4.5, 1.3], font_size=8.6)
    add_paragraph(doc, "Withdrawal prediction is dominated by cluster timing, backlog, cohort, and the recent regional withdrawal environment. The high importance of lagged withdrawal rate supports a regime-sensitive interpretation: projects are exposed to a shared administrative and market environment that can change quickly.")
    page_break(doc)

    heading(doc, "IA model", 2)
    add_figure(doc, CHARTS / "shap_summary_ia.png", "Figure 7  LightGBM feature importance for IA or operation", "Horizontal bars rank IA predictors by mean absolute SHAP value in the out-of-time test. Queued MW ahead is the largest predictive contributor, followed by queue age and the recent regional withdrawal rate.", width=6.25, source="Source: shap_importance_ia.csv")
    i_rows = [[str(i+1), r.feature.replace("num__", "").replace("cat__", "").replace("_", " "), f"{r.mean_abs_shap:.3f}"] for i, r in enumerate(shap_i.head(8).itertuples())]
    add_table(doc, ["Rank", "Predictor", "Mean absolute SHAP"], i_rows, widths=[.7, 4.5, 1.3], font_size=8.6)
    add_paragraph(doc, "The IA model relies heavily on queue context and age rather than one static project attribute. That helps ranking but also exposes the score to regime drift when backlog and cluster processing change. Missing service designation is predictive, but missingness can encode data-collection practices rather than project fundamentals.")
    page_break(doc)

    heading(doc, "Relative-risk ratios from the logit companion", 2)
    selected_features = [
        "num__lag4_regional_withdraw_rate",
        "num__post_ferc_order_2023",
        "num__cluster_cycle_year",
        "num__log1p_poi_active_mw_lag1q",
        "num__log1p_county_active_mw_lag1q",
        "cat__service_cat_Missing",
        "num__hybrid_flag",
        "num__log1p_poi_active_projects_lag1q",
        "cat__type_group_Solar+Battery",
    ]
    nice = {
        "num__lag4_regional_withdraw_rate": "Prior 4q regional withdrawal rate",
        "num__post_ferc_order_2023": "On or after May 16 2024",
        "num__cluster_cycle_year": "Cluster cycle year",
        "num__log1p_poi_active_mw_lag1q": "POI active MW lagged",
        "num__log1p_county_active_mw_lag1q": "County active MW lagged",
        "cat__service_cat_Missing": "Service missing category",
        "num__hybrid_flag": "Hybrid flag",
        "num__log1p_poi_active_projects_lag1q": "POI active project count lagged",
        "cat__type_group_Solar+Battery": "Solar plus battery category",
    }
    rr_rows = []
    for outcome in ["withdraw", "IA/operational"]:
        for feat in selected_features:
            m = rr[(rr.outcome_vs_stay == outcome) & (rr.feature == feat)]
            if not m.empty and float(m.iloc[0].p_value) < .05:
                r = m.iloc[0]
                rr_rows.append(["Withdrawal" if outcome == "withdraw" else "IA or operational", nice[feat], f"{r.relative_risk_ratio:.2f}", f"{r.ci_95_low:.2f} to {r.ci_95_high:.2f}"])
    add_table(doc, ["Outcome versus stay", "Predictor", "Relative-risk ratio", "95% confidence interval"], rr_rows, widths=[1.35, 2.75, 1.25, 1.35], font_size=8.1)
    add_paragraph(doc, "Numeric terms are standardized, so their ratios represent a one-standard-deviation change. Categorical ratios compare with an omitted reference level. The compact inference model is not identical to the full predictive logit. Wide intervals, such as the Solar plus Battery IA ratio, signal sparse or unstable comparisons and should not drive policy.")
    add_note(doc, "FERC indicator caution", "The post-May 16 2024 indicator is correlated with time, 2025 mass withdrawals, implementation activity, and other market changes. Its relative-risk ratio is not a causal estimate of Order 2023.", fill=PALE_RED, color=RED)
    page_break(doc)

    # Sensitivity
    heading(doc, "10 Sensitivity analysis", 1)
    sens_rows = []
    labels = {
        "main_window": "Main 2013 plus window",
        "prop_date_snapshot": "Add proposed date snapshot",
        "full_history_pre2013_included": "Include pre-2013 history",
        "spike_quarters_excluded": "Exclude flagged spike quarters",
    }
    base = sens[sens.sensitivity.eq("main_window")].iloc[0]
    for r in sens.itertuples():
        sens_rows.append([labels[r.sensitivity], f"{r.test_log_loss:.3f}", f"{r.test_brier:.3f}", f"{100*(r.test_log_loss/base.test_log_loss-1):+.1f}%", percent(r.mean_pred_withdraw), percent(r.mean_pred_ia)])
    add_table(doc, ["Training sensitivity", "Test log loss", "Test Brier", "Log loss change", "Mean wd hazard", "Mean IA hazard"], sens_rows, widths=[2.1, .95, .85, 1.0, 1.0, .95], font_size=8.0)
    heading(doc, "Proposed online date", 2)
    add_paragraph(doc, "Adding the 2025 proposed online date snapshot worsens out-of-time log loss by 10.7%. It does not create suspicious performance inflation. The field remains excluded because a revised end-of-period snapshot can still leak later developer knowledge into earlier rows.")
    heading(doc, "Full history", 2)
    add_paragraph(doc, "Including pre-2013 cohorts worsens test log loss by 10.9% and raises the mean IA hazard from 0.91% to 1.17%, a 28.5% increase. This direction matches the expected survivorship bias: older records disproportionately show successful IA outcomes and very few withdrawals.")
    heading(doc, "Spike exclusion", 2)
    add_paragraph(doc, "Removing audit-flagged spike quarters also worsens the later test score because some spikes are part of the test environment the model must face. That does not make the spikes structurally stable. Their decisive effect on live forecasts is examined in the next section.")
    add_note(doc, "What sensitivity results mean", "The model is asked two different questions: predict the historical 2023 to 2025 test as observed, and forecast beyond an extreme end-of-sample regime. A feature or quarter can improve retrospective fit while reducing the stability of forward-looking point probabilities.", fill="F4F8FB")
    page_break(doc)

    # Active scoring
    heading(doc, "11 Active project scoring", 1)
    heading(doc, "Main production refit", 2)
    add_paragraph(doc, "The selected logit is refit on all model-eligible 2013-plus rows and applied to 1,257 currently active project origins. Future queue age advances each quarter, while current backlog and recent-withdrawal features are frozen because future queue conditions are unknown.")
    active_rows = []
    for h in [4, 8, 12, 20]:
        active_rows.append([f"{h} quarters", percent(scores[f"p_withdraw_within_{h}q"].mean()), percent(scores[f"p_withdraw_within_{h}q"].median()), percent(scores[f"p_ia_within_{h}q"].mean()), percent(scores[f"p_ia_within_{h}q"].median())])
    add_table(doc, ["Horizon", "Mean withdrawal CIF", "Median withdrawal CIF", "Mean IA CIF", "Median IA CIF"], active_rows, widths=[1.15, 1.45, 1.45, 1.25, 1.25], font_size=8.5)
    add_metric_strip(doc, [("1,038", "projects at or above 80% wd risk by 4q"), ("97", "projects at or above 10% IA chance by 4q"), ("2.58", "mean conditional quarters to IA within 20q")])
    add_paragraph(doc, "Expected quarters to IA is conditional on IA occurring within the 20-quarter window. It is not an unconditional project completion time. Projects with very little IA probability can still have a short conditional expectation because the calculation considers only the small probability mass in paths that reach IA.")
    heading(doc, "Scenario instability", 2)
    add_figure(doc, ASSETS / "active_sensitivity.png", "Figure 8  Active project score sensitivity", "Grouped bars compare mean withdrawal and IA cumulative incidence at 4, 8, and 12 quarters across the main fit, spike-excluded fit, full-history fit, and proposed-date sensitivity.", width=6.45, source="Source: active_score_sensitivity.csv")
    page_break(doc)

    main_a = active_sens[active_sens.sensitivity.eq("main_2013plus_all_available")].iloc[0]
    no_spike = active_sens[active_sens.sensitivity.eq("spike_quarters_excluded_all_available")].iloc[0]
    add_note(doc, "Critical deployment warning", f"The mean four-quarter withdrawal CIF is {percent(main_a.mean_p_withdraw_4q)} in the main refit and {percent(no_spike.mean_p_withdraw_4q)} with spike quarters excluded, a {100*(main_a.mean_p_withdraw_4q-no_spike.mean_p_withdraw_4q):.1f}-percentage-point difference. The main active scores are therefore scenario and triage outputs, not reliable high-stakes point probabilities.", fill=PALE_RED, color=RED)
    scenario_rows = []
    scenario_labels = {
        "main_2013plus_all_available": "Main 2013 plus fit",
        "spike_quarters_excluded_all_available": "Flagged spikes excluded",
        "full_history_all_available": "Full history",
        "prop_date_snapshot_all_available": "Proposed date included",
    }
    for r in active_sens.itertuples():
        scenario_rows.append([scenario_labels[r.sensitivity], percent(r.mean_p_withdraw_4q), percent(r.mean_p_ia_4q), percent(r.mean_p_withdraw_12q), percent(r.mean_p_ia_12q)])
    add_table(doc, ["Production scenario", "Mean wd 4q", "Mean IA 4q", "Mean wd 12q", "Mean IA 12q"], scenario_rows, widths=[2.25, 1.0, 1.0, 1.0, 1.0], font_size=8.3)
    heading(doc, "Recommended score presentation", 2)
    add_bullets(doc, [
        "Show project percentile or risk band in addition to the raw probability.",
        "Display the main and spike-excluded withdrawal scenarios side by side.",
        "Suppress automated action for projects whose recommendation changes across scenarios.",
        "Refresh after each new quarter and monitor portfolio-level predicted versus observed incidence.",
        "Retain human review for unusual technologies, missing service or cluster information, and projects near cluster decision points.",
    ])
    heading(doc, "Delivered score fields", 2)
    add_paragraph(doc, "The CSV includes project identifiers and origin characteristics; withdrawal and IA CIFs within 4, 8, 12, and 20 quarters; expected quarters to IA conditional on IA within 20 quarters; and the IA probability mass used in that conditional expectation.")
    page_break(doc)

    # Planner implications
    heading(doc, "12 Planner interpretation and deployment", 1)
    heading(doc, "What drives withdrawal versus IA", 2)
    add_table(doc, ["Planning lens", "Withdrawal", "IA or operational"], [
        ["Short-horizon reliability", "Moderate ranking and close aggregate calibration at 4q", "Strong ranking and modest aggregate underprediction at 4q"],
        ["Long-horizon reliability", "Ranking weakens materially by 12q", "Ranking stays strong but probabilities are too low"],
        ["Dominant signals", "Cluster timing, backlog, recent withdrawals, age, cohort", "Backlog, age, recent withdrawals, local active set, cluster timing"],
        ["Main operational risk", "Mass administrative or cycle shocks", "Sparse events and changing completion regime"],
        ["Best use", "Stress testing and review prioritization", "Relative ranking plus recalibrated portfolio planning"],
    ], widths=[1.4, 2.6, 2.6], font_size=8.3)
    heading(doc, "Suggested governance dashboard", 2)
    add_bullets(doc, [
        "Quarterly log loss and Brier score against the frozen prior model",
        "Predicted versus observed withdrawal and IA incidence at 4, 8, and 12 quarters",
        "Population stability for age, entry cohort, technology, backlog, cluster cycle, and service missingness",
        "Share of projects whose risk band changes between the main and spike-excluded scenario",
        "Separate performance for large technology groups and cluster cycles",
    ])
    heading(doc, "Decision rules", 2)
    add_numbered(doc, [
        "Do not use the score as the sole basis for queue, contracting, staffing, or financial decisions.",
        "Use the logit as the default because its future-period performance is better and its structure is easier to audit.",
        "Treat LightGBM SHAP results as a diagnostic of nonlinear signal, not as the production decision rule.",
        "Require probability recalibration and an explicit risk appetite before converting scores to operational thresholds.",
        "Document exceptions and review outcome drift after each cluster milestone or rule change.",
    ])
    page_break(doc)

    # Limitations
    heading(doc, "13 Limitations and recommended enhancements", 1)
    heading(doc, "Known limitations", 2)
    add_bullets(doc, [
        "Predictive rather than causal: correlated queue and calendar features cannot isolate policy or behavioral mechanisms.",
        "End-of-period snapshots: project MW, technology, POI, utility, and proposed date may differ from values known at entry.",
        "First-event endpoint: the panel cannot independently count the roughly 850 IA-first projects later reported to withdraw.",
        "Temporal regime shift: the 2025 withdrawal spikes dominate the final production refit and create severe scenario instability.",
        "Frozen future covariates: active scoring holds backlog and recent withdrawal conditions fixed across future quarters.",
        "Missing developer field: MISO developer effects cannot be evaluated with this file.",
        "Limited IA events in the main window: 668 events support modeling, but subgroup estimates and wide-horizon calibration remain fragile.",
        "No physical grid information: queue congestion variables are not transmission congestion measures.",
    ])
    heading(doc, "Recommended external enhancements", 2)
    add_table(doc, ["Enhancement", "Potential value", "Required source"], [
        ["Historical queue snapshots", "Remove end-of-period snapshot ambiguity and model feature revisions", "Archived MISO queue releases"],
        ["Milestone and study-stage dates", "Represent where a project is in the interconnection process", "MISO process and project records"],
        ["Upgrade costs and study findings", "Capture major economic barriers to continuation", "Facilities or system impact studies"],
        ["Transmission constraints and deliverability", "Measure physical network conditions separately from queue backlog", "Power-flow and transmission planning data"],
        ["Developer and parent company history", "Measure sponsor track record without target leakage", "Entity resolution across historical projects"],
        ["Market and policy covariates", "Characterize external regimes explicitly", "Interest rates, equipment costs, tax policy, state procurement"],
    ], widths=[1.55, 3.0, 2.05], font_size=8.2)
    add_note(doc, "Priority", "The highest-value improvement is a true historical snapshot panel with milestone status. Better temporal data is more likely to improve trustworthiness than a more complex algorithm applied to the same snapshots.", fill=PALE_BLUE)
    page_break(doc)

    # Reproducibility
    heading(doc, "14 Reproducibility and code", 1)
    add_paragraph(doc, "The analysis is reproducible from the supplied CSV. The audit runs first and the pipeline refuses to fit unless the structural audit passes. All stochastic components use seed 20261020. The saved model artifact contains the feature definitions and preprocessing required for scoring.")
    heading(doc, "Run sequence", 2)
    add_code_block(doc, "python audit_miso_panel.py /path/to/MISO_panel_model_ready.csv outputs/audit\npython miso_pipeline.py /path/to/MISO_panel_model_ready.csv outputs/model --audit-dir outputs/audit\npython verify_outputs.py outputs/model\npython score_active.py /path/to/refreshed_panel.csv outputs/model/MISO_competing_risks_model.joblib refreshed_scores.csv")
    heading(doc, "Core hazard to CIF logic", 2)
    add_code_block(doc, "survival = 1.0\ncif_withdraw = 0.0\ncif_ia = 0.0\nfor quarter in forecast_horizon:\n    p_stay, p_withdraw, p_ia = model.predict_proba(row_for_quarter)\n    cif_withdraw += survival * p_withdraw\n    cif_ia += survival * p_ia\n    survival *= p_stay")
    add_paragraph(doc, "The update multiplies each event hazard by the probability of remaining event-free at the start of that quarter. This prevents double counting and preserves the competing-risks identity.")
    heading(doc, "Leakage-safe lag example", 2)
    add_code_block(doc, "quarterly_withdraw_rate = events.groupby('panel_quarter').mean()\nlag4_rate = quarterly_withdraw_rate.rolling(4).mean().shift(1)\n# shift(1) ensures the current quarter outcome cannot enter its own predictor")
    heading(doc, "Delivered artifacts", 2)
    add_table(doc, ["Artifact", "Purpose"], [
        ["audit_miso_panel.py", "Structural audit and feature usability tables"],
        ["miso_pipeline.py", "Feature engineering, validation, fitting, evaluation, sensitivity analysis, charts, scoring, and serialization"],
        ["score_active.py", "Reusable command-line scorer"],
        ["verify_outputs.py", "Independent integrity checks for score bounds, CIF monotonicity, intervals, charts, and model loading"],
        ["MISO_competing_risks_model.joblib", "Serialized selected model and scoring metadata"],
        ["MISO_active_project_scores.csv", "Project-level active scores"],
    ], widths=[2.65, 3.85], font_size=8.4)
    page_break(doc)

    # Appendix A
    heading(doc, "Appendix A Detailed audit tables", 1)
    heading(doc, "Entry cohort outcomes", 2)
    entry_rows = [[str(int(r.q_year)), f"{int(r.projects):,}", f"{int(r.rows):,}", f"{int(r.withdrawals):,}", f"{int(r.ia_operational):,}", f"{int(r.censored):,}"] for r in entry.itertuples()]
    add_table(doc, ["Entry year", "Projects", "Rows", "Withdrawals", "IA or operational", "Censored"], entry_rows, widths=[.85, .9, .9, 1.05, 1.35, .9], font_size=7.7, source="The 2006 cohort has 110 IA outcomes and only 5 withdrawals, illustrating the early-history survivorship problem.")
    page_break(doc)
    heading(doc, "Structural integrity checks", 2)
    integrity_rows = [
        ["Missing project identifiers", "0", "Pass"],
        ["Duplicate project-quarter rows", "0", "Pass"],
        ["Nonconsecutive age sequences", "0", "Pass"],
        ["Nonconsecutive calendar sequences", "0", "Pass"],
        ["Projects with multiple terminal events", "0", "Pass"],
        ["Rows after a terminal event", "0", "Pass"],
        ["Eligible censored rows", "0", "Pass"],
        ["Ineligible non-censored rows", "0", "Pass"],
        ["Ineligible rows before project end", "0", "Pass"],
    ]
    add_table(doc, ["Check", "Violations", "Status"], integrity_rows, widths=[4.3, 1.0, 1.0], font_size=8.7)
    heading(doc, "Flagged spike quarters", 2)
    add_table(doc, ["Quarter", "At risk", "Withdrawals", "IA", "Event rate"], spike_rows, widths=[1.1, 1.1, 1.25, .9, 1.2], font_size=8.2)
    add_paragraph(doc, "The audit flag uses robust standardized deviations across multiple count and rate measures. It is intentionally broad: early IA waves and later withdrawal waves can both be flagged.")
    page_break(doc)

    # Appendix B
    heading(doc, "Appendix B Feature inventory and definitions", 1)
    feature_rows = [
        ["age_quarters", "Queue age at the row", "Known", "Spline in logit and raw in tree"],
        ["q_year and entry cohort", "Queue entry year and grouped cohort", "Known", "Main sample starts in 2013"],
        ["post_ferc_order_2023", "Row on or after May 16 2024", "Known", "Regime label only"],
        ["log_project_mw", "Log of project capacity", "Snapshot", "Static field caveat"],
        ["type_group", "Rare-grouped technology", "Snapshot", "Categories under 2% become Other"],
        ["hybrid_flag and storage_flag", "Flags from type_1 and type_2", "Snapshot", "Conservative missing handling"],
        ["service and utility", "Interconnection service and utility", "Snapshot", "Missing retained as category"],
        ["state", "Project state", "Snapshot", "Missing retained"],
        ["cluster cycle year", "Year parsed from DPP cluster", "Snapshot", "Also used for robust CV grouping"],
        ["cluster subregion", "Central, South, West, East, or other", "Snapshot", "Missing retained"],
        ["log1p_mw_ahead", "Earlier-entered active MW in MISO", "Time varying", "Queue congestion measure"],
        ["mw_ahead_per_mw", "MW ahead divided by project MW", "Time varying", "Protected against zero or missing MW"],
        ["POI active project count", "Active projects at the same POI", "Lagged", "Measured just before quarter start"],
        ["POI active MW", "Active MW at the same POI", "Lagged", "Measured just before quarter start"],
        ["County active project count", "Active projects in same county", "Lagged", "Measured just before quarter start"],
        ["County active MW", "Active MW in same county", "Lagged", "Measured just before quarter start"],
        ["lag4 withdrawal rate", "Regional withdrawal rate in prior four quarters", "Lagged", "Shifted one quarter"],
        ["prop_date features", "Proposed date timing", "2025 snapshot", "Sensitivity only"],
    ]
    add_table(doc, ["Feature", "Definition", "Timing", "Use or caveat"], feature_rows, widths=[1.55, 2.35, 1.05, 1.6], font_size=7.4, cell_margin=48)
    heading(doc, "Never used as predictive features", 2)
    add_bullets(doc, [
        "project_id because it is an identifier",
        "transition_outcome because it is the target",
        "model_eligible because it reveals sample or active status",
        "audit_wd_date_proxy_flag because it is true only for withdrawals",
        "panel_quarter one-hot effects because future categories are unseen and calendar shocks should not masquerade as stable predictive structure",
    ])
    page_break(doc)

    # References
    heading(doc, "Appendix C References", 1)
    add_paragraph(doc, "Lawrence Berkeley National Laboratory Queued Up interconnection queue data, supplied as MISO_panel_model_ready.csv with stated cutoff December 31 2025.")
    p = doc.add_paragraph()
    p.add_run("Federal Energy Regulatory Commission  ")
    add_hyperlink(p, "Explainer on the Improvements to Generator Interconnection Procedures and Agreements Final Rule", "https://www.ferc.gov/explainer-interconnection-final-rule")
    p.add_run("  Used to document the May 16 2024 MISO compliance filing deadline.")
    p = doc.add_paragraph()
    p.add_run("Midcontinent Independent System Operator  ")
    add_hyperlink(p, "FERC status report July 2025", "https://cdn.misoenergy.org/20250722%20IPWG%20Item%2003a%20FERC%20Status%20Report708027.pdf")
    p.add_run("  Used as context for later compliance and implementation timing.")
    add_paragraph(doc, "Internal analysis outputs generated by audit_miso_panel.py and miso_pipeline.py, including all CSV tables and PNG figures cited in this report.")
    heading(doc, "Final interpretation statement", 2)
    add_note(doc, "Use with judgment", "This model estimates associations in historical queue records. It should support, not replace, engineering review, commercial diligence, regulatory context, and direct communication with project stakeholders.", fill=PALE_BLUE)

    doc.save(OUTPUT)
    return OUTPUT


if __name__ == "__main__":
    path = build_report()
    print(path)
