#!/usr/bin/env python3
"""Reusable command-line scorer for a refreshed MISO model-ready panel."""

from __future__ import annotations

import argparse
from pathlib import Path

from miso_pipeline import score_from_saved_bundle


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("model_joblib", type=Path)
    parser.add_argument("output_csv", type=Path)
    args = parser.parse_args()
    score_from_saved_bundle(args.input_csv, args.model_joblib, args.output_csv)


if __name__ == "__main__":
    main()
