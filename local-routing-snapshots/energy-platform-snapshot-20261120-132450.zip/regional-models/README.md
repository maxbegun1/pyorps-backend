# Amplytico Individual Competing-Risks Models

This folder is the clean, team-shareable package for the NYISO and MISO interconnection queue models. It intentionally excludes local Python environments, caches, temporary files, and duplicated working directories.

## Folder contents

- `NYISO/`: NYISO model-ready data, master report, complete result tables and charts, trained model, modeling script, and reusable scoring script.
- `MISO/`: MISO model-ready data, master report, result package, model outputs, modeling scripts, and reusable scoring script.
- `Data Workbooks/`: combined NYISO/MISO/SPP dynamic-modeling Excel workbooks.

## Important interpretation notes

- These models are predictive, not causal.
- Queue-backlog variables do not measure physical transmission congestion.
- The NYISO active-project probabilities are experimental because the strict out-of-time test showed weak calibration and did not outperform the age-only benchmark.
- The NYISO IA class is especially thin and should be interpreted descriptively.

## Reproducing the models

Create a fresh Python environment and install the packages in the relevant `requirements.txt` file. Do not add a local environment or `site-packages` directory back to this shared folder.


## Model 2 availability

The NYISO Model 2 code, input panel, fitted model, and instructions are included in `NYISO/`; see `NYISO/README_queue_time_v2.md`. The MISO Model 2 report is included, but its matching training code and inputs were not found in the supplied project archive. The existing MISO scripts describe the earlier model.
