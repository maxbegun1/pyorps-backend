export default { worker: { name: 'energy-platform-predictor-preview', entrypoint: './worker.mjs', compatibilityDate: '2026-11-18' } };
