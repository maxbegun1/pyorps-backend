# Interconnection planning preview

This preview combines the existing local PYORPS routing application with age-based competing-risk historical scenarios. It is not a production-calibrated forecast. The public preview is separate from the existing Queue Atlas site.

## Run and test

From this directory, run `python -m uvicorn app:app --host 127.0.0.1 --port 8769` in the existing `pyorps-env`, with the GIS bundle in `~/Downloads/PYORPS_MISO_NYISO_Data` or `PYORPS_DATA_DIR`. Run `npm test` for JavaScript syntax and probability invariants. `python prepare_dashboard.py` generates the Cloudflare preview bundle; run `cf deploy --prebuilt --dry-run` and `cf deploy --prebuilt` from `dashboard-deployment`.

## Timeline models

`build_baselines.py` reconstructs the age-only quarterly benchmarks from the existing research panel, using observations through 2022. MISO uses `dynamic_ia/baselines.py` and its IA-specific `prepare` definition. NYISO uses the age bins and smoothing prior in `nyiso_competing_risks.py`; its endpoint is IA or operation. `baseline-hazards.json` records the resulting rates and training row counts. The browser advances age each quarter and accumulates competing risks, starting at entry for new projects or conditional on remaining queued at the evaluation date for existing ones.

MISO's historical origin checks are in `regional_models/MISO/dynamic_ia/age_forecast_validation.json`: errors vary substantially by cohort and horizon, and the panel has uncertain point-in-time provenance and selection issues. The age baseline is exploratory, not a validated decision-grade new-project forecast. NYISO's 2023–2025 holdout log loss and multiclass Brier were 0.586 and 0.316; the model underpredicted the reform-related withdrawal shock. The reported horizon validation extends to three years; five-year curves are extrapolations. Both scenarios use a historical training cutoff and exclude project size, technology, POI and cost; no causal drivers, COD, or POI-specific forecast are claimed. See the regional model READMEs and validation reports for details.

## Routing and data

The POI coordinates come from the existing MISO mapped POI file; they do not establish electrical feasibility or interconnection availability. The NYISO planning boundary is a state proxy, and no verified NYISO POI layer is supplied. NYISO supports a manually selected route endpoint and a user-supplied per-mile rate. Route geometry comes from PYORPS over the local GIS cost surface; the line estimate multiplies route length by MISO MTEP24 state/voltage rates or the entered rate. It excludes separate substations and network upgrades. Routing preferences are not dollars. The search buffer and source coverage limit route quality.

The public preview proxies routing requests to `pyorps-backend.onrender.com`. The service can take time to wake and may fail while starting. It is not an independently tested high-availability production deployment. OSM tiles are requested from OpenStreetMap and the browser displays their attribution.
