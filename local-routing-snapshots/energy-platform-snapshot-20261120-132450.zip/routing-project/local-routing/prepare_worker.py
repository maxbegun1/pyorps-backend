"""Add the routing page to a copy of the exact downloaded live Worker."""
import json
from pathlib import Path

here=Path(__file__).resolve().parent
workspace=here.parent.parent
source=workspace/'tmp'/'queue-atlas-live-worker.mjs'
destination=workspace/'tmp'/'queue-routing-staged'
destination.mkdir(parents=True,exist_ok=True)
s=source.read_text(encoding='utf-8')
start=s.index('const ASSETS=')+len('const ASSETS=')
assets,end=json.JSONDecoder().raw_decode(s[start:])
for key,filename,content_type in [('/routing','routing-map.html','text/html; charset=utf-8'),('/routing-map.js','routing-map.js','application/javascript; charset=utf-8'),('/routing-map.css','routing-map.css','text/css; charset=utf-8')]:
    if key in assets: raise ValueError(f'Asset path already exists: {key}')
    assets[key]=[content_type,(here/filename).read_text(encoding='utf-8')]
assets['/routing-integrated.js']=['application/javascript; charset=utf-8',(here.parent/'website-integration'/'routing-integrated.js').read_text(encoding='utf-8-sig')]
assets['/routing-integrated.css']=['text/css; charset=utf-8',(here.parent/'website-integration'/'routing-integrated.css').read_text(encoding='utf-8-sig')]
assets['/routing-config.js']=['application/javascript; charset=utf-8',"window.ROUTING_API_BASE = 'https://pyorps-backend.onrender.com';"]
for key in ('/','/index.html'):
    page=assets[key][1]
    marker='<a class="poi-tree-link" href="/poi-tree">POI Project Tree</a>'
    if page.count(marker)!=1: raise ValueError('Cannot safely add the routing link')
    page=page.replace(marker,marker+'<a class="poi-tree-link" href="/routing">Routing details</a>')
    page=page.replace('</head>','<link rel="stylesheet" href="/routing-integrated.css"></head>')
    page=page.replace('</body>','<script src="/routing-integrated.js"></script></body>')
    assets[key][1]=page
out=s[:start]+json.dumps(assets,ensure_ascii=True,separators=(',',':'))+s[start+end:]
(destination/'deploy-worker.mjs').write_text(out,encoding='utf-8')
(destination/'cloudflare.config.ts').write_text("export default { worker: { name: 'queue-atlas-research-preview', entrypoint: './deploy-worker.mjs', compatibilityDate: '2026-11-01', env: { INFRA: { type: 'kv', id: '2cb0b48dda53438a983bea0ea24f3e7e' } } } };\n",encoding='utf-8')
root=destination/'.cloudflare'/'output'/'v0'
worker=root/'workers'/'default'
(worker/'bundle').mkdir(parents=True,exist_ok=True)
(worker/'bundle'/'worker.mjs').write_text(out,encoding='utf-8')
(root/'config.json').write_text(json.dumps({'buildContext':{'isPreview':False}}),encoding='utf-8')
(worker/'worker.config.json').write_text(json.dumps({'name':'queue-atlas-research-preview','compatibilityDate':'2026-11-01','env':{'INFRA':{'type':'kv','id':'2cb0b48dda53438a983bea0ea24f3e7e'}},'manifest':{'type':'complete','mainModule':'worker.mjs','modules':{'worker.mjs':{'type':'esm'}}}}),encoding='utf-8')
print('Prepared Worker copy; baseline version 6a680ac9-76b4-4ea3-b56f-b092004606fc')
