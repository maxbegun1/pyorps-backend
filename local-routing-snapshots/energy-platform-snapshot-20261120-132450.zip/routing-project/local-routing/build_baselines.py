from pathlib import Path
import sys, json
import pandas as pd
base=Path(__file__).resolve().parents[2]/'miso-prediction-fix'/'regional_models'
sys.path.insert(0,str(base/'MISO'/'dynamic_ia'))
from train import prepare
from baselines import EmpiricalHazard
m,excluded=prepare(base/'MISO'/'data'/'MISO_panel_operational_ready.csv')
m=m[m.observed & (m.quarter>=pd.Period('2013Q1')) & (m.quarter<pd.Period('2023Q1'))]
model=EmpiricalHazard(m)
n=pd.read_csv(base/'NYISO'/'data'/'NYISO_panel_model_ready.csv',low_memory=False)
n=n[(n.model_eligible.astype(str).str.lower()=='true') & (pd.to_datetime(n.quarter_start)<pd.Timestamp('2023-01-01'))].copy()
n['y']=n.transition_outcome.map({'stay':0,'withdraw':1,'IA/operational':2})
n=n[n.y.notna()]
labels=['1','2','3','4','5-8','9-12','13-20','21+']
n['bucket']=pd.cut(n.age_quarters,bins=[0,1,2,3,4,8,12,20,float('inf')],labels=labels)
ny=[]
for label in labels:
 counts=[int(((n.bucket==label)&(n.y==j)).sum()) for j in range(3)]
 weighted=[counts[0]+1,counts[1]+.5,counts[2]+.5]
 ny.append([x/sum(weighted) for x in weighted])
out={'MISO':{'rates':[v.tolist() for v in model.probs.values()],'train_end':'2022-12-31','training_rows':len(m),'excluded_undated_projects':excluded,'outcome':'IA','bucket_limits':[4,8,16,32]},'NYISO':{'rates':ny,'train_end':'2022-12-31','training_rows':len(n),'outcome':'IA or operation','bucket_limits':[1,2,3,4,8,12,20]}}
Path(__file__).with_name('baseline-hazards.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:{'training_rows':v['training_rows'],'rates':v['rates']} for k,v in out.items()})
